/**
 * RSA Key Generator.
 * Command Line Usage:
 * keygen [-o <pub> <priv>] [p q | -c]
 * Where <pub> and <priv> are filenames for the public and private key files.
 * Default filenames are pubkey.xml and privkey.xml.
 * Where p and q are prime numbers whose product is > 127.
 * The option -c indicates that the program will generate pseudorandom values
 * for p and q.
 * If -c and p and q are not specified then the user will be prompted to enter
 * values for p and q.
 * 
 * Class: CS 340, Fall 2005
 * System: jdk-1.5.0.4, Windows XP
 * @author Michael Leonhard
 * @version 5 Sep 2005
 */

import java.util.*;
import java.io.*;

public class KeyGen
{
	// fields
	private String M_pubkeyFilename = null;
	private String M_privkeyFilename = null;
	private int M_p = -1, M_q = -1;
	private int M_n, M_phi, M_e, M_d;
	
	/**
	 * Constructor for objects of class KeyGen
	 */
	public KeyGen()
	{
	}
	
	/**
	 * Print the command line usage.
	 */
	public void printUsage()
	{
		System.out.println( "Command Line Usage: keygen [-o <pubkey> <privkey>] [-c | <p> <q>]" );
		System.out.println( " <pubkey> is the name of file to write public key in XML format" );
		System.out.println( " <privkey> is the name of file to write private key in XML format" );
		System.out.println( " -c requests that prime numbers be generated automatically" );
		System.out.println( " <p> and <q> are unique prime numbers used to generate the keys" );
		System.out.println( "   p * q must be larger than 127" );
		System.out.println( "Example command line: keygen -o pubkey.xml privkey.xml -c" );
	}
	
	/**
	 * Test the number for primeness, return true or false
	 */
	boolean isPrime( int n )
	{
		// prime numbers are all positive and greater than zero
		if( n <= 0 ) return false;
		// one is a prime number
		if( n == 1 ) return true;
		// search for possible factors
		for( int j = 2; j < n / 2; j++ )
		{
			// is j a factor?
			if( n % j == 0 )
			{
				printDebug( "isPrime/1 " + Integer.toString(n) + " is divisible by " + Integer.toString(j) );
				return false;
			}
		}
		printDebug( "isPrime/1 " + Integer.toString(n) + " is prime!" );
		return true;
	}
	
	/**
	 * Return the smallest prime number that is larger than n
	 */
	int findPrime( int n )
	{
		printDebug( "findPrime/1 checking for prime number larger than " + Integer.toString(n) );
		// if n is even then make it odd
		if( n % 2 == 0 ) n = n + 1;
		// loop to find a prime number
		while( !isPrime(n) )
		{
			printDebug( "findPrime/1 " + Integer.toString(n) + " is not prime" );
			n = n + 2;
		}
		printDebug( "findPrime/1 returning " + Integer.toString(n) );
		return n;
	}
	
	private class KeyGenException extends Exception
	{
		// fields
		private String M_text;
		/**
		 * Default constructor.  Default description is "Unspecified exception."
		*/
		public KeyGenException()
		{
			M_text = "Unspecified exception.";
		}
		/**
		 * Constructor.  Description may be specified.
		 */
		public KeyGenException( String description )
		{
			M_text = description;
		}
		// accessor
		public String toString() { return M_text; }
		/**
		 * Prints exception description on the console
		 */
		public void print()
		{
			System.out.println( M_text );
		}
	}
	
	/**
	 * Prints debugging messages to the console
	 */
	static public void printDebug( String message )
	{
		//System.out.println( message );
	}
	
	/**
	 * Configures default values that were not specified by the user
	 */
	private void useNeededDefaults()
	{
		if( M_pubkeyFilename == null ) // use default filenames
		{
			M_pubkeyFilename = "pubkey.xml";
			M_privkeyFilename = "privkey.xml";
			// inform user
			System.out.println( "Filenames not specified.  Using defaults: pubkey.xml privkey.xml" );
		}
	}
	
	/**
	 * Try one time to get the second prime number from the user
	 */
	public int getSecondPrimeFromUser( BufferedReader consoleReader ) throws KeyGenException,IOException
	{
		int q = -1;

		// prompt the user and read the first number
		System.out.print( "Please enter prime number q:" );
		String qString = consoleReader.readLine().trim();
		
		if( qString.length() == 0 ) return -1; // nothing was entered
		
		try { // convert parameter to integer
			q = Integer.valueOf( qString ).intValue();
		} catch( NumberFormatException e ) {
			throw new KeyGenException( "You must type a positive integer that is prime." );
		}
		
		if( !isPrime( q ) ) // integer must be prime
		{
			throw new KeyGenException( Integer.toString(q) + " is not prime.  You must type a prime number." );
		}
		
		return q;
	}
	
	/**
	 * Try one time to get the prime numbers from the user
	 */
	private void getPrimeNumbersFromUser( BufferedReader consoleReader ) throws KeyGenException,IOException
	{
		int p = -1, q = -1;
		
		// prompt the user and read the first number
		System.out.print( "Please enter prime number p:" );
		String pString = consoleReader.readLine().trim();
		
		if( pString.length() == 0 ) return; // nothing was entered
		
		try { // convert parameter to integer
			p = Integer.valueOf( pString ).intValue();
		} catch( NumberFormatException e ) {
			throw new KeyGenException( "You must type a positive integer that is prime." );
		}
		
		if( !isPrime( p ) ) // integer must be prime
		{
			throw new KeyGenException( Integer.toString(p) + " is not prime.  You must type a prime number." );
		}
		
		// need second prime number, loop until user enters it correctly
		while( q == -1 )
		{
			try
			{
				q = getSecondPrimeFromUser(consoleReader);
			} catch( KeyGenException e ) {
				e.print();
			}
		}
		
		if( p == q ) // the numbers must not be equal
		{
			throw new KeyGenException( "You may not enter the same number twice." );
		}
		
		if(p * q < 128 ) // the numbers must have a product larger than 127
		{
			throw new KeyGenException( "The product of the numbers must be greater than 127." );
		}
		
		M_p = p; // save the values
		M_q = q;
	}
	
	/**
	 * Gets required data from the user
	 */
	private void getDataFromUser() throws IOException
	{
		// create a console reader object
		BufferedReader consoleReader = new BufferedReader( new InputStreamReader( System.in ) );
		// need prime numbers, loop until the user enters them correctly
		while( M_p == -1 )
		{
			try
			{
				getPrimeNumbersFromUser(consoleReader);
			} catch( KeyGenException e ) {
				e.print();
			}
		}
	}
	
	/**
	 * Processes the command line arguments
	 */
	private void processCommandLine( String[] argv ) throws KeyGenException
	{
		// loop through command line arguments
		int argc = argv.length;
		printDebug( "Number of parameters is " + Integer.toString(argc) );
		for( int i = 0; i < argc; i++ )
		{
			printDebug( "PARM: " + argv[i] );
			if( argv[i].equals("-o") )
			{
				if( M_pubkeyFilename != null ) // -o option may not be specified twice
				{
					throw new KeyGenException( "Malformed Commandline: the -o option may be specified only once" );
				}
				if( i + 2 >= argc ) // there must be two more parameters
				{
					throw new KeyGenException( "Malformed Commandline: please specify two filenames after the -o option" );
				}
				
				printDebug( "PARMS: " + argv[i+1] + " " + argv[i+2] );
				if( argv[i+1].equals(argv[i+2]) ) // the filenames must not be equal
				{
					throw new KeyGenException( "Malformed Commandline: the pubkey and privkey filenames may not be the same." );
				}
				
				// store filenames
				M_pubkeyFilename = argv[i+1];
				M_privkeyFilename = argv[i+2];
				// two extra parameters processed
				i = i + 2;
			}
			else if( argv[i].equals("-c") )
			{
				// initialize the pseudo random number generator
				Random randomizer = new Random();
				// choose p to be a random prime number in [16,116)
				M_p = findPrime(randomizer.nextInt(100) + 16);
				// choose q to be a random prime number in [16,116) that is not p
				M_q = M_p;
				while( M_q == M_p ) M_q = findPrime(randomizer.nextInt(100) + 16);
			}
			else // look for primes
			{
				if( M_p != -1 ) // primes may not be specified twice
				{
					throw new KeyGenException( "Malformed Commandline: unexpected parameter: \"" + argv[i] + "\"" );
				}
				
				try { // convert parameter to integer
					M_p = Integer.valueOf( argv[i] ).intValue();
				} catch( NumberFormatException e ) {
					throw new KeyGenException( "Malformed Commandline: expected integer but found \"" + argv[i] + "\"" );
				}
				
				if( !isPrime( M_p ) ) // integer must be prime
				{
					throw new KeyGenException( "Malformed Commandline: expected prime number but found " + Integer.toString(M_p) );
				}
				
				if( i + 1 >= argc ) // there must one more parameter
				{
					throw new KeyGenException( "Malformed Commandline: missing second prime number" );
				}
				
				printDebug( "PARM: " + argv[i+1] );
				try { // convert next parameter to integer
					M_q = Integer.valueOf( argv[i+1] ).intValue();
				} catch( NumberFormatException e ) {
					throw new KeyGenException( "Malformed Commandline: expected integer but found \"" + argv[i+1] + "\"" );
				}
				
				if( !isPrime( M_q ) ) // integer must be prime
				{
					throw new KeyGenException( "Malformed Commandline: expected prime number but found " + Integer.toString(M_q) );
				}
				
				if( M_p == M_q ) // the numbers must not be equal
				{
					throw new KeyGenException( "Malformed Commandline: the prime numbers may not be the same" );
				}
				
				if( M_p * M_q < 128 ) // the numbers must have a product larger than 127
				{
					throw new KeyGenException( "Malformed Commandline: the product of the primes must be >127" );
				}
				
				// one extra parameter processed
				i = i + 1;
			}
			}
		}
	
	/**
	 * Test the a and b for a common denominator larger than 1
	 */
	boolean areRelativelyPrime( int a, int b )
	{
		String text = Integer.toString(a)+" and "+Integer.toString(b);
		printDebug( "areRelativelyPrime/2 testing " + text);
		while( b != 0 )
		{
			int t = b;
			b = a % b;
			a = t;
		}
		if( a == 1 ) printDebug( "areRelativelyPrime/2 " + text + " are relatively prime" );
		else printDebug( "areRelativelyPrime/2 " + text + " are not relatively prime" );
		return a == 1;
	}
	
	/**
	 * Generate n, phi, etc.
	 */
	private void generateKeys() throws KeyGenException
	{
		printDebug( "p is " + Integer.toString(M_p) );
		printDebug( "q is " + Integer.toString(M_q) );
		M_n = M_p * M_q;
		printDebug( "n is " + Integer.toString(M_n) );
		
		M_phi = (M_p - 1) * (M_q - 1);
		printDebug( "phi is " + Integer.toString(M_phi) );
		
		// find largest suitable e
		int e = M_n - 1;
		while( e == M_phi || !areRelativelyPrime(e, M_phi) )
		{
			// TODO: Try to find out if this can ever happen
			if( e == 1 ) throw new KeyGenException( "Unable to find valid value for e" );
			e--;
		}
		M_e = e;
		printDebug( "e is " + Integer.toString(M_e) );
		
		// search (inefficiently) for d
		int d = 3;
		while( (M_e*d) % M_phi != 1 )
		{
			// TODO: Try to find out if this can ever happen
			if( d == M_n || d == M_phi ) throw new KeyGenException( "Unable to find valid value for d" );
			d++;
		}
		M_d = d;
		printDebug( "d is " + Integer.toString(M_d) );
	}
	
	/**
	 * Write the private and public key files in XML format
	 */
	private void writeKeys() throws IOException
	{
		System.out.println( "Writing public key to file: " + M_pubkeyFilename );
		FileWriter pubKeyFile = new FileWriter( M_pubkeyFilename );
		pubKeyFile.write( 
			"<rsakey>\r\n" +
			"\t<evalue>"+Integer.toString(M_e)+"</evalue>\r\n" +
			"\t<nvalue>"+Integer.toString(M_n)+"</nvalue>\r\n" +
			"</rsakey>");
		pubKeyFile.close();
		
		System.out.println( "Writing private key to file: " + M_privkeyFilename );
		FileWriter privKeyFile = new FileWriter( M_privkeyFilename );
		privKeyFile.write( 
			"<rsakey>\r\n" +
			"\t<dvalue>"+Integer.toString(M_d)+"</dvalue>\r\n" +
			"\t<nvalue>"+Integer.toString(M_n)+"</nvalue>\r\n" +
			"</rsakey>");
		privKeyFile.close();
		printDebug( "done." );
	}
	
	/**
	 * Obtain (p,q) and generate the keys
	 */
	public void doJob( String[] argv ) throws IOException
	{
		// print program information
		System.out.println
		(
		"CS 340 Project 1 program 1 (KeyGen).\n" +
		"Michael Leonhard, 2005/09/05\n" +
		"Java 1.5.0.4 on Windows XP\n"
		);
		
		try
		{
			processCommandLine( argv );
			useNeededDefaults();
			getDataFromUser();
			generateKeys();
			writeKeys();
		} catch( KeyGenException e )
		{
			e.print();
			return;
		}

		// prompt the user
		//System.out.println( "Enter string:" );
		
		// wait for the user to type something and hit enter
		//String response = M_consoleReader.readLine();
		}
		
		/**
		* This method is called when the class is loaded from the command line
		*/
		public static void main( String[] argv ) throws IOException
		{
		// make an instance of the class
		KeyGen instance = new KeyGen();
		// generate the keys
		instance.doJob(argv);
	}
}