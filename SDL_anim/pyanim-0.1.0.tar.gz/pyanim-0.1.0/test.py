#!/usr/bin/env python

import pygame, pyanim
from pygame.locals import *

pygame.init()
ship = pyanim.Anim( "planet.anim" )
screen = pygame.display.set_mode( (ship.w, ship.h), HWPALETTE, 16 )
pygame.display.set_caption( 'pyanim test' )
ship.displayformat()

pygame.time.set_timer( USEREVENT, 33 )
badevents = [NOEVENT, ACTIVEEVENT, KEYUP, MOUSEMOTION, MOUSEBUTTONDOWN, MOUSEBUTTONUP, JOYAXISMOTION, JOYBALLMOTION, JOYHATMOTION, JOYBUTTONDOWN ,JOYBUTTONUP, VIDEORESIZE, SYSWMEVENT, NUMEVENTS]
goodevents = [KEYDOWN, QUIT, USEREVENT ]
pygame.event.set_blocked( badevents )

# Main loop
running = 1
start = pygame.time.get_ticks()

while running:
	event = pygame.event.wait()
	if event.type == QUIT: running = 0
	ship.blitframe( start, pygame.time.get_ticks(), screen, (0, 0 ) )
	pygame.display.flip()

print 'bye bye'
