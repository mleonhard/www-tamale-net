#include <Python.h>
#include <SDL_anim.h>
#include <pygame/pygame.h>

/* test anim initialization */
#define ANIM_INIT_CHECK() \
	if(!(*(int*)PyANIM_C_API[2])) \
		return RAISE(PyExc_SDLError, "pyanim system not initialized")

typedef struct {
  PyObject_HEAD
  SDL_Animation *anim;
} PyAnimObject;
#define PyAnim_AsAnim(x) (((PyAnimObject*)x)->anim)

/* platform specific compiler stuff */
#if defined(macintosh) && defined(__MWERKS__)
#define PYANIM_EXPORT __declspec(export)
#else
#define PYANIM_EXPORT
#endif
