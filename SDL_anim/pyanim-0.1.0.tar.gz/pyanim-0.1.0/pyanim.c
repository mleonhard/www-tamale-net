/*
    pyanim - Python module for SDL_anim
    Copyright (C) 2001, 2002  Michael Leonhard

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Library General Public
    License as published by the Free Software Foundation; either
    version 2 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Library General Public License for more details.

    You should have received a copy of the GNU Library General Public
    License along with this library; if not, write to the Free
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Michael Leonhard
    mike@tamale.net
*/

#define PYANIM_INTERNAL
#include <string.h>
#include "pyanim.h"

staticforward PyTypeObject PyAnim_Type;
static PyObject* PyAnim_New( SDL_Animation* );
#define PyAnim_Check(x) ((x)->ob_type == &PyAnim_Type)
static int pyanim_initialized = 0;

/* pyanim module internals */

static char doc_PyAnim_getframenum[] =
	"Anim.getframenum( start, now ) -> int\n"
	"number of frame at specified time\n"
	"\n"
	"Get the number of the frame at the specified time.\n";
static PyObject* PyAnim_getframenum( PyObject* self, PyObject* args ) {
	int start, now;
	SDL_Animation* anim;
	anim = PyAnim_AsAnim( self );
	if( !PyArg_ParseTuple( args, "ii", &start, &now ) ) return NULL;

	return PyInt_FromLong( Anim_GetFrameNum( anim, (Uint32)start, (Uint32)now ) );
	}

static char doc_PyAnim_blitframe[] =
	"Anim.blitframe( start, now, dest, rect ) -> None\n"
	"blit the frame for specified time to dest surface and rect\n"
	"\n"
	"Blit the frame for the specified time to the dest surface and rect.\n";
static PyObject *PyAnim_blitframe( PyObject* self, PyObject* args ) {
	int start, now, x, y, w = 0, h = 0;
	SDL_Surface *dest;
	SDL_Animation* anim;
	SDL_Rect rect;
	PyObject *destobject, *object;

	anim = PyAnim_AsAnim( self );
	if( !PyArg_ParseTuple( args, "iiOO", &start, &now, &destobject, &object ) ) return NULL;
	dest = PySurface_AsSurface( destobject );

	if( strcmp( object->ob_type->tp_name, "Rect" ) == 0 ) {
		PyRectObject *g;
		g = (PyRectObject *)object;
		rect.x = g->r.x;
		rect.y = g->r.y;
		rect.w = g->r.w;
		rect.h = g->r.h;
		}
	else if( object->ob_type == &PyTuple_Type ) {
		if( !PyArg_ParseTuple( object, "ii|ii", &x, &y, &w, &h ) ) return NULL;
		rect.x = x;
		rect.y = y;
		rect.w = w;
		rect.h = h;
		}
	else return RAISE(PyExc_TypeError, "invalid destination position for blit");

	return PyInt_FromLong( Anim_BlitFrame( anim, (Uint32)start, (Uint32)now, dest, &rect ) );
	}

static char doc_PyAnim_blitframenum[] =
	"Anim.blitframenum( frame, dest, rect ) -> None\n"
	"blit the frame to dest surface and rect\n"
	"\n"
	"Blit the frame to the dest surface and rect.\n";
static PyObject *PyAnim_blitframenum( PyObject* self, PyObject* args ) {
	int frame, x, y, w = 0, h = 0;
	SDL_Surface *dest;
	SDL_Animation* anim;
	SDL_Rect rect;
	PyObject *destobject, *object;

	anim = PyAnim_AsAnim( self );
	if( !PyArg_ParseTuple( args, "iOO", &frame, &destobject, &object ) ) return NULL;
	dest = PySurface_AsSurface( destobject );

	if( strcmp( object->ob_type->tp_name, "Rect" ) == 0 ) {
		PyRectObject *g;
		g = (PyRectObject *)object;
		rect.x = g->r.x;
		rect.y = g->r.y;
		rect.w = g->r.w;
		rect.h = g->r.h;
		}
	else if( object->ob_type == &PyTuple_Type ) {
		if( !PyArg_ParseTuple( object, "ii|ii", &x, &y, &w, &h ) ) return NULL;
		rect.x = x;
		rect.y = y;
		rect.w = w;
		rect.h = h;
		}
	else return RAISE(PyExc_TypeError, "invalid destination position for blit");

	return PyInt_FromLong( Anim_BlitFrameNum( anim, frame, dest, &rect ) );
	}

static char doc_PyAnim_displayformat[] =
	"Anim.displayformat() -> None\n"
	"convert the anim to optimize blitting\n"
	"\n"
	"Convert the animation to the color type of the screen.\n"
	"This can greatly enhance the performance of the blitter.\n";
static PyObject *PyAnim_displayformat( PyObject* self, PyObject* args ) {
	SDL_Animation *anim = PyAnim_AsAnim( self );
	return PyInt_FromLong( Anim_DisplayFormat( anim ) );
	}

static PyMethodDef PyAnimobj_builtins[] = {
	{ "getframenum", PyAnim_getframenum, 1, doc_PyAnim_getframenum },
	{ "blitframe", PyAnim_blitframe, 1, doc_PyAnim_blitframe },
	{ "blitframenum", PyAnim_blitframenum, 1, doc_PyAnim_blitframenum },
	{ "displayformat", PyAnim_displayformat, 1, doc_PyAnim_displayformat },
	{ NULL, NULL }
	};

static PyObject* PyAnim_getattr( PyObject* self, char* attrname ) {
	SDL_Animation* anim = PyAnim_AsAnim(self);

	if( !pyanim_initialized ) return RAISE( PyExc_SDLError, "anim not initialized" );

	if( strcmp( attrname, "frames" ) == 0 ) return PyInt_FromLong( anim->frames );
	if( strcmp( attrname, "w" ) == 0 ) return PyInt_FromLong( anim->w );
	if( strcmp( attrname, "h" ) == 0 ) return PyInt_FromLong( anim->h );
	if( strcmp( attrname, "duration" ) == 0 ) return PyInt_FromLong( anim->duration );
	
	return Py_FindMethod( PyAnimobj_builtins, self, attrname );
	}

static void PyAnim_dealloc( PyObject* self ) {
	SDL_Animation *anim;
	anim = PyAnim_AsAnim( self );
	if( pyanim_initialized ) Anim_Free( anim );
	PyMem_DEL( self );
	}

static char doc_PyAnim_OBJECT[] =
	"The Anim object is created only from anim.Anim(). An Anim\n"
	"object has several data members: surface, frames, w, h, and\n"
	"duration.  The Anim object also has several member functions:\n"
	"GetFrameNum, BlitFrame, GetFrameRect, BlitFrameNum, and Convert.\n"
	"An Anim object's duration is the number of milliseconds from the\n"
	"first frame to the last.  The blit functions take start and now\n"
	"parameters.  This makes it easy to display an animation at the\n"
	"right speed.  Simply record the time when the game object is\n"
	"created.  Then call the blit function with the current time.\n";

static PyTypeObject PyAnim_Type = {
	PyObject_HEAD_INIT( NULL )
	0,
	"Anim",
	sizeof( PyAnimObject ),
	0,
	PyAnim_dealloc,	
	0,
	PyAnim_getattr,
	0,
	0,
	0,
	0,
	NULL,
	0, 
	(hashfunc)NULL,
	(ternaryfunc)NULL,
	(reprfunc)NULL,
	0L,0L,0L,0L,
	doc_PyAnim_OBJECT /* Documentation string */
	};

/* anim module methods */

static char doc_PyAnim[] =
	"pyanim.Anim( filename ) -> Anim\n"
	"create a new anim object\n"
	"\n"
	"Load an anim file and return an Anim object. The filename must be of\n"
	"an anim file that was created by the makeanim utility.  The makeanim \n"
	"utility may be found as part of the SDL_anim library.\n";
static PyObject* PyAnim( PyObject* self, PyObject* args ) {
	PyObject* animobj;
	SDL_Animation* anim;
	char* filename;
	
	if( !PyArg_ParseTuple( args, "s", &filename ) ) return RAISE( PyExc_SDLError, "no filename specified" );
	if( !pyanim_initialized ) return RAISE( PyExc_SDLError, "anim not initialized" );

	anim = Anim_Load( filename );
	if( !anim ) return RAISE( PyExc_RuntimeError, Anim_GetError() );
	animobj = PyAnim_New( anim );
	if( !animobj ) return RAISE( PyExc_SDLError, "PyAnim_New() failed" );
	return animobj;
	}

static PyMethodDef PyAnim_builtins[] = {
	{ "Anim", PyAnim, 1, doc_PyAnim },
	{ NULL, NULL }
	};

static PyObject* PyAnim_New( SDL_Animation* anim ) {
	PyAnimObject* animobj;
	if( !anim ) return RAISE( PyExc_RuntimeError, "unable to load pyanim." );

	animobj = PyObject_NEW( PyAnimObject, &PyAnim_Type );
	if( !animobj ) return NULL;
	animobj->anim = anim;
	return (PyObject*)animobj;
	}

static char doc_PyAnim_MODULE[] =
   "The pyanim module facilitates the loading and blitting of animations.\n"
   "Animations are stored as two files: a text definition file and an\n"
   "image file.  The text definition file contains the filename of the\n"
   "image file, the number of frames, and the transparent color key.\n"
   "The image file is loaded with the SDL_image library.\n"
   "\n"
   "This module is optional and requires SDL_anim and SDL_image as\n"
   "dependencies.  You must import anim before attempting to\n"
   "use the module.\n"
   "\n"
   "Most of the work done with anims are done by using the actual\n"
   "Anim objects. The module by itself only has routines to\n"
   "initialize the module and create Anim objects with anim.Anim().\n";

PYANIM_EXPORT void initpyanim( void ) {
	PyObject *module, *dict;

	PyType_Init( PyAnim_Type );
	pyanim_initialized = 1;
	
	/* create the module */
	module = Py_InitModule3( "pyanim", PyAnim_builtins, doc_PyAnim_MODULE );
	dict = PyModule_GetDict( module );

	PyDict_SetItemString( dict, "AnimType", (PyObject *)&PyAnim_Type );
	}
