#!/usr/bin/env python

from os import popen
from distutils.core import setup, Extension

compile_args = popen('sdl-config --cflags').readlines()
link_args = popen('sdl-config --libs').readlines()

setup(	name="pyanim",
	version="0.1.0",
	description="SDL_anim for Python",
	author="Michael Leonhard",
	author_email="SDL_anim@tamale.net",
	url="http://tamale.net/SDL_anim/",
	ext_modules=[Extension( "pyanim", ["pyanim.c"], libraries=["SDL_anim"],include_dirs=["/usr/local/include/SDL"])
			],
	data_files=[ ('', ['setup.py', 'test.py', 'planet.anim']) ],
	)
