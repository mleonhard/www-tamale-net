#!/usr/bin/env python
#
# This is the distutils setup script for pyanim. (modified from pygame)
# To configure, compile, install, just run this script.

DESCRIPTION = """pyanim is a Python module for SDL_anim"""
NAME = 'pyanim'
METADATA = {
    "name":             NAME,
    "version":          "0.1.1",
    "license":          "LGPL",
    "url":              "http://tamale.net/SDL_anim/",
    "author":           "Michael Leonhard",
    "author_email":     "mike@tamale.net",
    "description":      "simple animation library",
    "long_description": DESCRIPTION,
}

try:
    import distutils
except ImportError:
    raise SystemExit, "requires distutils to build and install."



#get us to the correct directory
import os, sys
path = os.path.split(os.path.abspath(sys.argv[0]))[0]
os.chdir(path)



import os.path, glob
import distutils.sysconfig 
from distutils.core import setup, Extension
from distutils.extension import read_setup_file
from distutils.ccompiler import new_compiler
from distutils.command.install_data import install_data



#sanity check for any arguments
if len(sys.argv) == 1:
    reply = raw_input('\nNo Arguments Given, Perform Default Install? [Y/n]')
    if not reply or reply[0].lower() != 'n':
        sys.argv.append('install')


#make sure there is a Setup file
if not os.path.isfile('Setup'):
    print '\n\nWARNING, No "Setup" File Exists, Running "config.py"'
    import config
    config.main()
    print '\nContinuing With "setup.py"'



#get compile info for all extensions
try:
    extensions = read_setup_file('Setup')
except:
    raise SystemExit, """Error with the "Setup" file,
perhaps make a clean copy from "Setup.in"."""




#finally, 
#call distutils with all needed info
PACKAGEDATA = {
       "ext_modules": extensions,
}
PACKAGEDATA.update(METADATA)
apply(setup, [], PACKAGEDATA)

