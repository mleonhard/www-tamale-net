/*
 *  anim module for pygame
 */
#define PYGAMEAPI_ANIM_INTERNAL
#include <string.h>
#include "pygame.h"
#include "anim.h"
#include <SDL/SDL_image.h>

staticforward PyTypeObject PyAnim_Type;
static PyObject* PyAnim_New(SDL_Animation*);
#define PyAnim_Check(x) ((x)->ob_type == &PyAnim_Type)

static int anim_initialized = 0;

static void anim_autoquit( void ) {
	if( anim_initialized ) anim_initialized = 0;
	}

static PyObject* anim_autoinit( PyObject* self, PyObject* arg ) {
	if( !PyArg_ParseTuple( arg, "" ) ) return NULL;
	if( !anim_initialized ) anim_initialized = 1;
	return PyInt_FromLong(1);
	}

static char doc_quit[] =
   "pygame.anim.quit() -> none\n"
   "uninitialize the anim module\n"
   "\n"
   "Manually uninitialize the anim subsystem. It is safe to call\n"
   "this if anim is currently not initialized.\n";
static PyObject* anim_quit( PyObject* self, PyObject* arg ) {
	if( !PyArg_ParseTuple( arg, "" ) ) return NULL;
	anim_autoquit();
	RETURN_NONE
	}

static char doc_init[] =
   "pygame.anim.init() -> None\n"
   "initialize the anim module\n"
   "\n"
   "Manually initialize the anim module. Will raise an exception if\n"
   "it cannot be initialized. It is safe to call this function if\n"
   "anim is currently initialized.\n";
static PyObject* anim_init( PyObject* self, PyObject* arg ) {
	PyObject* result;
	int istrue;
	if( !PyArg_ParseTuple( arg, "" ) ) return NULL;

	result = anim_autoinit( self, arg );
	istrue = PyObject_IsTrue( result );
	Py_DECREF( result );
	if( !istrue ) return RAISE( PyExc_SDLError, SDL_GetError() );

	RETURN_NONE
	}

static char doc_get_init[] =
   "pygame.anim.get_init() -> bool\n"
   "get status of anim module initialization\n"
   "\n"
   "Returns true if the anim module is currently intialized.\n";
static PyObject* get_init( PyObject* self, PyObject* arg ) {
	if(!PyArg_ParseTuple( arg, "" ) ) return NULL;
	return PyInt_FromLong( anim_initialized );
	}

/* anim object methods 

static char doc_anim_get_underline[] =
   "Anim.get_underline() -> bool\n"
   "status of the underline attribute\n"
   "\n"
   "Get the current status of the anim's underline attribute\n";

static PyObject* anim_get_underline(PyObject* self, PyObject* args)
{
	SDL_Animation* anim = PyAnim_AsAnim(self);

	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	return PyInt_FromLong((TTF_GetAnimStyle(anim)&TTF_STYLE_UNDERLINE) != 0);
}



static char doc_anim_set_underline[] =
   "Anim.set_underline(bool) -> None\n"
   "assign the underline attribute\n"
   "\n"
   "Enables or disables the underline attribute for the anim.\n"
;

static PyObject* anim_set_underline(PyObject* self, PyObject* args)
{
	SDL_Animation* anim = PyAnim_AsAnim(self);
	int style, val;

	if(!PyArg_ParseTuple(args, "i", &val))
		return NULL;

	style = TTF_GetAnimStyle(anim);
	if(val)
		style |= TTF_STYLE_UNDERLINE;
	else
		style &= ~TTF_STYLE_UNDERLINE;
	TTF_SetAnimStyle(anim, style);

	RETURN_NONE
}



static char doc_anim_render[] =
   "Anim.render(text, antialias, fore_RGBA, [back_RGBA]) -> Surface\n"
   "render text to a new image\n"
   "\n"
   "Render the given text onto a new image surface. The given text\n"
   "can be standard python text or unicode. Antialiasing will smooth\n"
   "the edges of the anim for a much cleaner look. The foreground\n"
   "and background color are both RGBA, the alpha component is ignored\n"
	/*ODC/    "if given. If the background color is omitted, the text will have a\n"
   "a transparent background.\n"
;

static PyObject* anim_render(PyObject* self, PyObject* args)
{
	SDL_Animation* anim = PyAnim_AsAnim(self);
	int aa;
	PyObject* text;
	PyObject* fg_rgba_obj, *bg_rgba_obj = NULL;
	Uint8 rgba[4];
	SDL_Surface* surf;
	SDL_Color foreg, backg;

	if(!PyArg_ParseTuple(args, "OiO|O", &text, &aa, &fg_rgba_obj, &bg_rgba_obj))
		return NULL;

	if(!RGBAFromObj(fg_rgba_obj, rgba))
		return RAISE(PyExc_TypeError, "Invalid foreground RGBA argument");
	foreg.r = rgba[0]; foreg.g = rgba[1]; foreg.b = rgba[2];
	if(bg_rgba_obj)
	{
		if(!RGBAFromObj(bg_rgba_obj, rgba))
			return RAISE(PyExc_TypeError, "Invalid background RGBA argument");
		backg.r = rgba[0]; backg.g = rgba[1]; backg.b = rgba[2];
	}	

	if(PyUnicode_Check(text))
	{
		Py_UNICODE* string = PyUnicode_AsUnicode(text);
		if(aa)
		{
			if(!bg_rgba_obj)
				surf = TTF_RenderUNICODE_Blended(anim, string, foreg);
			else
				surf = TTF_RenderUNICODE_Shaded(anim, string, foreg, backg);
		}
		else
			surf = TTF_RenderUNICODE_Solid(anim, string, foreg);
	}
	else if(PyString_Check(text))
	{
		char* string = PyString_AsString(text);
		if(aa)
		{
			if(!bg_rgba_obj)
				surf = TTF_RenderText_Blended(anim, string, foreg);
			else
				surf = TTF_RenderText_Shaded(anim, string, foreg, backg);
		}
		else
			surf = TTF_RenderText_Solid(anim, string, foreg);
	}
	else
		return RAISE(PyExc_TypeError, "text must be a string or unicode");

	if(!surf)
		return RAISE(PyExc_SDLError, SDL_GetError());

	if(!aa && bg_rgba_obj) /*turn off transparancy
	{			
		SDL_SetColorKey(surf, 0, 0);
		surf->format->palette->colors[0].r = backg.r;
		surf->format->palette->colors[0].g = backg.g;
		surf->format->palette->colors[0].b = backg.b;
	}

	return PySurface_New(surf);
}



static char doc_anim_size[] =
   "Anim.size(text) -> width, height\n"
   "size of rendered text\n"
   "\n"
   "Computes the rendered size of the given text. The text can be\n"
   "standard python text or unicode. Changing the bold and italic\n"
   "attributes can change the size of the rendered text.\n"
;

static PyObject* anim_size(PyObject* self, PyObject* args)
{
	SDL_Animation* anim = PyAnim_AsAnim(self);
	int w, h;
	PyObject* text;

	if(!PyArg_ParseTuple(args, "O", &text))
		return NULL;

	if(PyUnicode_Check(text))
	{
		Py_UNICODE* string = PyUnicode_AsUnicode(text);
		TTF_SizeUNICODE(anim, string, &w, &h);
	}
	else if(PyString_Check(text))
	{
		char* string = PyString_AsString(text);
		TTF_SizeText(anim, string, &w, &h);
	}
	else
		return RAISE(PyExc_TypeError, "text must be a string or unicode");

	return Py_BuildValue("(ii)", w, h);
}



/*anim object internals */

static char doc_anim_getframenum[] =
   "Anim.getframenum( start, now ) -> integer\n"
   "number of frame at specified time\n"
   "\n"
   "Get the number of the frame at the specified time.\n";
static PyObject* anim_getframenum( PyObject* self, PyObject* args ) {
	int start, now;
	SDL_Animation* anim;
	anim = PyAnim_AsAnim( self );
	if( !PyArg_ParseTuple( args, "ii", &start, &now ) ) return NULL;

	return PyInt_FromLong( ANIM_GetFrameNum( anim, (Uint32)start, (Uint32)now ) );
	}

static char doc_anim_blitframe[] =
   "Anim.blitframe( start, now, dest, rect ) -> None\n"
   "blit the frame for specified time to dest surface and rect\n"
   "\n"
   "Blit the frame for the specified time to the dest surface and rect.\n";
static PyObject *anim_blitframe( PyObject* self, PyObject* args ) {
	int start, now, x, y, w = 0, h = 0;
	SDL_Surface *dest;
	SDL_Animation* anim;
	SDL_Rect rect;
	PyObject *destobject, *object;

	anim = PyAnim_AsAnim( self );
	if( !PyArg_ParseTuple( args, "iiOO", &start, &now, &destobject, &object ) ) return NULL;
	dest = PySurface_AsSurface( destobject );

	if( strcmp( object->ob_type->tp_name, "Rect" ) == 0 ) {
		PyRectObject *g;
		g = (PyRectObject *)object;
		rect.x = g->r.x;
		rect.y = g->r.y;
		rect.w = g->r.w;
		rect.h = g->r.h;
		}
	else if( object->ob_type == &PyTuple_Type ) {
		if( !PyArg_ParseTuple( object, "ii|ii", &x, &y, &w, &h ) ) return NULL;
		rect.x = x;
		rect.y = y;
		rect.w = w;
		rect.h = h;
		}
	else return RAISE(PyExc_TypeError, "invalid destination position for blit");

	return PyInt_FromLong( ANIM_BlitFrame( anim, (Uint32)start, (Uint32)now, dest, &rect ) );
	}

static char doc_anim_blitframenum[] =
   "Anim.blitframenum( frame, dest, rect ) -> None\n"
   "blit the frame to dest surface and rect\n"
   "\n"
   "Blit the frame to the dest surface and rect.\n";
static PyObject *anim_blitframenum( PyObject* self, PyObject* args ) {
	int frame, x, y, w = 0, h = 0;
	SDL_Surface *dest;
	SDL_Animation* anim;
	SDL_Rect rect;
	PyObject *destobject, *object;

	anim = PyAnim_AsAnim( self );
	if( !PyArg_ParseTuple( args, "iOO", &frame, &destobject, &object ) ) return NULL;
	dest = PySurface_AsSurface( destobject );

	if( strcmp( object->ob_type->tp_name, "Rect" ) == 0 ) {
		PyRectObject *g;
		g = (PyRectObject *)object;
		rect.x = g->r.x;
		rect.y = g->r.y;
		rect.w = g->r.w;
		rect.h = g->r.h;
		}
	else if( object->ob_type == &PyTuple_Type ) {
		if( !PyArg_ParseTuple( object, "ii|ii", &x, &y, &w, &h ) ) return NULL;
		rect.x = x;
		rect.y = y;
		rect.w = w;
		rect.h = h;
		}
	else return RAISE(PyExc_TypeError, "invalid destination position for blit");

	return PyInt_FromLong( ANIM_BlitFrameNum( anim, frame, dest, &rect ) );
	}

static char doc_anim_displayformat[] =
   "Anim.displayformat() -> None\n"
   "convert the anim to optimize blitting\n"
   "\n"
   "Convert the animation to the color type of the screen.\n"
   "This can greatly enhance the performance of the blitter.\n";
static PyObject *anim_displayformat( PyObject* self, PyObject* args ) {
	SDL_Animation *anim = PyAnim_AsAnim( self );
	return PyInt_FromLong( ANIM_DisplayFormat( anim ) );
	}

static PyMethodDef animobj_builtins[] = {
	{ "getframenum", anim_getframenum, 1, doc_anim_getframenum },
	{ "blitframe", anim_blitframe, 1, doc_anim_blitframe },
	{ "blitframenum", anim_blitframenum, 1, doc_anim_blitframenum },
	{ "displayformat", anim_displayformat, 1, doc_anim_displayformat },
	{ NULL, NULL }
	};

static PyObject* anim_getattr( PyObject* self, char* attrname ) {
	SDL_Animation* anim = PyAnim_AsAnim(self);

	if( anim_initialized ) {
		if( strcmp( attrname, "frames" ) == 0 ) return PyInt_FromLong( anim->frames );
		if( strcmp( attrname, "w" ) == 0 ) return PyInt_FromLong( anim->w );
		if( strcmp( attrname, "h" ) == 0 ) return PyInt_FromLong( anim->h );
		if( strcmp( attrname, "duration" ) == 0 ) return PyInt_FromLong( anim->duration );
		else return Py_FindMethod( animobj_builtins, self, attrname );
		}
	PyErr_SetString( PyExc_NameError, attrname );
	return NULL;
	}

static void anim_dealloc( PyObject* self ) {
	SDL_Animation *anim;
	printf( "anim_dealloc()\n" );
	anim = PyAnim_AsAnim( self );
	if( anim_initialized ) ANIM_Free( anim );
	PyMem_DEL( self );
	}

static char doc_Anim_MODULE[] =
   "The Anim object is created only from pygame.anim.Anim(). An Anim\n"
   "object has several data members: surface, frames, w, h, and\n"
   "duration.  The Anim object also has several member functions:\n"
   "GetFrameNum, BlitFrame, GetFrameRect, BlitFrameNum, and Convert.\n"
   "An Anim object's duration is the number of milliseconds from the\n"
   "first frame to the last.  The blit functions take start and now\n"
   "parameters.  This makes it easy to display an animation at the\n"
   "right speed.  Simply record the time when the game object is\n"
   "created.  Then call the blit function with the current time.\n"
   "-----This documentation really sucks... must fix------\n";

static PyTypeObject PyAnim_Type = {
	PyObject_HEAD_INIT( NULL )
	0,
	"Anim",
	sizeof( PyAnimObject ),
	0,
	anim_dealloc,	
	0,
	anim_getattr,
	0,
	0,
	0,
	0,
	NULL,
	0, 
	(hashfunc)NULL,
	(ternaryfunc)NULL,
	(reprfunc)NULL,
	0L,0L,0L,0L,
	doc_Anim_MODULE /* Documentation string */
	};

/*anim module methods*/

static char doc_Anim[] =
   "pygame.anim.Anim( filename ) -> Anim\n"
   "create a new anim object\n"
   "\n"
   "This will create a new anim object. The given filename must be of a \n"
   "text animation definition.  The anim loader does not work with python\n"
   "file-like objects. The animation definition will contain the name of an\n"
   "image file.  This image file will be loaded form the same directory as\n"
   "the animation definition.  The image file is loaded by the SDL_image\n"
   "library.\n";
static PyObject* Anim( PyObject* self, PyObject* args ) {
	PyObject* animobj;
	SDL_Animation* anim;
	char* filename;

	if( !PyArg_ParseTuple( args, "s", &filename ) ) return NULL;
	if( !anim_initialized ) return RAISE( PyExc_SDLError, "anim not initialized" );

	anim = ANIM_Load( filename, IMG_Load );
	if(!anim) return RAISE(PyExc_RuntimeError, ANIM_GetError() );
	animobj = PyAnim_New( anim );
	return animobj;
	}

static PyMethodDef anim_builtins[] = {
	{ "__PYGAMEinit__", anim_autoinit, 1, doc_init },
	{ "init", anim_init, 1, doc_init },
	{ "quit", anim_quit, 1, doc_quit },
	{ "get_init", get_init, 1, doc_get_init },

	{ "Anim", Anim, 1, doc_Anim },

	{ NULL, NULL }
	};

static PyObject* PyAnim_New( SDL_Animation* anim ) {
	PyAnimObject* animobj;
	if(!anim) return RAISE( PyExc_RuntimeError, "unable to load anim." );

	animobj = PyObject_NEW( PyAnimObject, &PyAnim_Type );
	if(!animobj) return NULL;
	animobj->anim = anim;
	return (PyObject*)animobj;
	}

static char doc_pygame_anim_MODULE[] =
   "The anim module facilitates the loading and blitting of animations.\n"
   "Animations are stored as two files: a text definition file and an\n"
   "image file.  The text definition file contains the filename of the\n"
   "image file, the number of frames, and the transparent color key.\n"
   "The image file is loaded with the SDL_image library.\n"
   "\n"
   "This module is optional and requires SDL_anim and SDL_image as\n"
   "dependencies.  You must import pygame.anim before attempting to\n"
   "use the module.\n"
   "\n"
   "Most of the work done with anims are done by using the actual\n"
   "Anim objects. The module by itself only has routines to\n"
   "initialize the module and create Anim objects with\n"
   "pygame.anim.Anim().\n";

void initanim() {
	PyObject *module, *dict, *apiobj;
	static void* c_api[PYGAMEAPI_ANIM_NUMSLOTS];

	PyANIM_C_API[0] = PyANIM_C_API[0]; /*clean an unused warning*/

	PyType_Init(PyAnim_Type);

    /* create the module */
	module = Py_InitModule3( "anim", anim_builtins, doc_pygame_anim_MODULE );
	dict = PyModule_GetDict( module );

	PyDict_SetItemString( dict, "AnimType", (PyObject *)&PyAnim_Type );

	/* export the c api */
	c_api[0] = &PyAnim_Type;
	c_api[1] = PyAnim_New;
	c_api[2] = &anim_initialized;
	apiobj = PyCObject_FromVoidPtr( c_api, NULL );
	PyDict_SetItemString( dict, PYGAMEAPI_LOCAL_ENTRY, apiobj );

	/*imported needed apis*/
	import_pygame_base();
	import_pygame_surface();
	}

