#include <Python.h>
#include <SDL/SDL_anim.h>


/* test anim initialization */
#define ANIM_INIT_CHECK() \
	if(!(*(int*)PyANIM_C_API[2])) \
		return RAISE(PyExc_SDLError, "anim system not initialized")



#define PYGAMEAPI_ANIM_NUMSLOTS 3
typedef struct {
  PyObject_HEAD
  SDL_Animation *anim;
} PyAnimObject;
#define PyAnim_AsAnim(x) (((PyAnimObject*)x)->anim)
#ifndef PYGAMEAPI_ANIM_INTERNAL
#define PyAnim_Check(x) ((x)->ob_type == (PyTypeObject*)PyANIM_C_API[0])
#define PyAnim_Type (*(PyTypeObject*)PyANIM_C_API[0])
#define PyAnim_New (*(PyObject*(*)(SDL_Animation*))PyANIM_C_API[1])
/*slot 2 taken by ANIM_INIT_CHECK*/
#define import_pygame_anim() { \
	PyObject *module = PyImport_ImportModule("pygame.anim"); \
	if (module != NULL) { \
		PyObject *dict = PyModule_GetDict(module); \
		PyObject *c_api = PyDict_GetItemString(dict, PYGAMEAPI_LOCAL_ENTRY); \
		if(PyCObject_Check(c_api)) {\
			void** localptr = (void*)PyCObject_AsVoidPtr(c_api); \
			memcpy(PyANIM_C_API, localptr, sizeof(void*)*PYGAMEAPI_ANIM_NUMSLOTS); \
} } }
#endif




static void* PyANIM_C_API[PYGAMEAPI_ANIM_NUMSLOTS] = {NULL};
