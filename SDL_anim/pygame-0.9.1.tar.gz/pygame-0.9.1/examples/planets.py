#! /usr/bin/env python

import pygame, pygame.anim, pygame.time, pygame.font, whrandom
from pygame.locals import *

class FPS:
    def __init__( self ):
        self.next = pygame.time.get_ticks()
        self.frames = 0
        self.font = pygame.font.Font( None, 25 )
    def draw( self, screen ):
        self.frames = self.frames + 1
        now = pygame.time.get_ticks()
        if now >= self.next:
            self.text = self.font.render( 'fps ' + `self.frames`, 0, (64, 192, 128, 0) )
            self.text.convert()
            self.x = screen.get_width() - self.text.get_width() - 5
            self.next = now + 1000
            self.frames = 0
        screen.blit( self.text, (self.x, 0) )

pygame.init()
SCREENRECT = Rect(0, 0, 640, 480)
flags = HWSURFACE | HWPALETTE | DOUBLEBUF# | FULLSCREEN
bestdepth = pygame.display.mode_ok( SCREENRECT.size, flags, 8 )
screen = pygame.display.set_mode( SCREENRECT.size, flags, bestdepth )
pygame.display.set_caption( 'planets' )
pygame.mouse.set_visible(1)

anim = pygame.anim.Anim( 'data/planet.anim' )
anim.displayformat()

fps = FPS();

whrandom.seed()
class Planet: pass
Planets = []
for i in range( 0, 50 ):
    planet = Planet()
    planet.x = whrandom.randint( 0, 639 - anim.h )
    planet.y = whrandom.randint( 0, 479 - anim.w )
    planet.ix = whrandom.randint( -4, 4 )
    planet.iy = whrandom.randint( -4, 4 )
    planet.now = whrandom.randint( 0, anim.duration )
    planet.spin = whrandom.randint( -anim.duration / 30, anim.duration / 30 )
    Planets.append( planet )

pygame.time.set_timer( USEREVENT, 30 )

# Main loop
done = 0
dest = Rect(200, 200, 0, 0)
start = pygame.time.get_ticks()
while not done:
    while pygame.event.peek():
        event = pygame.event.poll()
        if event.type == QUIT: done = 1
        if event.type == KEYDOWN: done = 1
        if event.type == USEREVENT:
            for planet in Planets:
                planet.x += planet.ix
                planet.y += planet.iy
                if planet.x < 0 or planet.x > 639 - anim.w:
                    planet.x -= planet.ix
                    planet.ix = 0 - planet.ix
                if planet.y < 0 or planet.y > 479 - anim.h:
                    planet.y -= planet.iy
                    planet.iy = 0 - planet.iy
                planet.now += planet.spin
                planet.now = planet.now % anim.duration
    
    screen.fill( (0, 0, 0, 0), SCREENRECT )
    now = pygame.time.get_ticks()
    anim.blitframe( start, now, screen, dest )
    for planet in Planets:
        frame = anim.getframenum( 0, planet.now )
        anim.blitframenum( frame, screen, (planet.x, planet.y) )

    fps.draw( screen )
    pygame.display.flip()

print 'bye bye'
