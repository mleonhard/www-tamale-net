/*
	SDL_anim:  an animation library for SDL
	Copyright (C) 2001  Michael Leonhard

	This library is under the GNU Library General Public License.
	See the file "COPYING" for details.

	Michael Leonhard
	mike@tamale.net
*/

#ifndef _SDL_anim_h
#define _SDL_anim_h

#include "SDL.h"
#include "begin_code.h"

/* Set up for C function definitions, even when using C++ */
#ifdef __cplusplus
extern "C" {
#endif

struct SDL_Animation {
	SDL_Surface *surface;
	int frames, w, h;
	float duration;
	}

extern DECLSPEC SDL_Animation *Anim_Load( const char *file );
extern DECLSPEC int Anim_Free( SDL_Animation *anim );
extern DECLSPEC int Anim_GetFrameNum( float start, float now );
extern DECLSPEC int Anim_GetFrameRect( int frame, SDL_Rect *rect );
extern DECLSPEC int Anim_BlitFrame( SDL_Surface dest, float start, float now );
extern DECLSPEC int Anim_BlitFrameNum( SDL_Surface dest, int frame );
extern DECLSPEC int Anim_DisplayFormat( SDL_Animation *anim );
	
/* We'll use SDL for reporting errors */
#define Anim_SetError	SDL_SetError
#define Anim_GetError	SDL_GetError

/* Ends C function definitions when using C++ */
#ifdef __cplusplus
};
#endif
#include "close_code.h"

#endif /* _SDL_anim_h */
