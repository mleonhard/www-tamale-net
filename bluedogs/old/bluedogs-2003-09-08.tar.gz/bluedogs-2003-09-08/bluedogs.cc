/*
bluedogs.cc

Copyright (C) 2003
Michael Leonhard
http://tamale.net/
*/

#include <assert.h>
#include <SDL.h>
#include <stdlib.h>
#include <time.h>

#include "bluedogs.hh"

#define DRAW_ALWAYS 0
#define DRAW_SLOW 1
#define DRAW_STATSONLY 2

void Simulation::drawStats( bool update ) {
	/* draw stats */
	M_rateCounter->draw();
	M_critterCounter->draw();
	
	/* update the region of the screen */
	if( update ) SDL_UpdateRect( M_display->getSurface(), statsRect.x, statsRect.y, statsRect.w, statsRect.h );/**/
	}

void Simulation::drawSim() {
	/* blank the screen */
	M_display->blankScreen();
	
	/* draw the simulation elements */
	M_field->draw();
	M_population->draw();
	
	/* draw the stats without updating their region */
	drawStats( false );
	
	/* update the screen */
	M_display->updateScreen();/**/
	}

void Simulation::loop() {
	int c;
	
	/* loop until DisplayQuit */
	while( 1 ) {
		/*printf( "." );
		fflush( stdout );/**/
		
		/* keep the population above minimum */
		for( c = M_population->getItemCount(); c < M_minCritters; c++ ) {
			/* choose randomly between bacteria and mammal */
			if( RANDINT( 3 ) ) {
				/* make a new mammal */
				(new Mammal( *M_field, M_genotypeLength, M_initialEnergy ) )->joinQuad( M_population );
				}
			else {
				/* make a new bacteria */
				(new Bacteria( *M_field, M_genotypeLength, M_initialEnergy ) )->joinQuad( M_population );
				}
			}
		
		/* update the simulation */
		M_field->update();/**/
		M_population->update();/**/
		
		/* process events from the user */
		userEvents();
		
		/* drawing mode */
		switch( M_mode ) {
			case DRAW_ALWAYS:
				/* regular drawing */
				drawSim();
				break;
			case DRAW_SLOW:
				/* one second has passed */
				if( M_lastSecond != time( NULL ) ) {
					M_lastSecond = time( NULL );
					drawSim();
					}
				break;
			case DRAW_STATSONLY:
				/* just draw stats */
				drawStats( true );
				break;
			default:
				/* invalid mode */
				assert( 0 );
			}
		}
	}

Simulation::Simulation( Display& display, Field& field, Population& population, int minCritters, int genotypeLength, int initialEnergy ) {
	M_lastSecond = time( NULL );
	M_mode = DRAW_ALWAYS;
	M_display = &display;
	M_field = &field;
	M_population = &population;
	M_minCritters = minCritters;
	M_genotypeLength = genotypeLength;
	M_initialEnergy = initialEnergy;
	
	/* region of screen occupied by stats displays */
	statsRect.x = display.getWidth() - 50;
	statsRect.y = 10;
	statsRect.w = 50;
	statsRect.h = 0;
	
	/* Frames Per Second counter */
	M_rateCounter = new RateCounter( display, statsRect.x, statsRect.y, field );
	statsRect.h += M_rateCounter->getHeight();
	
	/* Critter count display */
	M_critterCounter = new CritterCounter( display, statsRect.x, statsRect.y + statsRect.h, population );
	statsRect.h += M_critterCounter->getHeight();
	}

Simulation::~Simulation() {
	printf( "\n~Simulation\n" );
	/*M_population->printGenotypes();/**/
	}

void Simulation::userEvents() {
	SDL_Event event;
	
	/* process all events on queue */
	while( SDL_PollEvent( &event ) ) {
		switch( event.type ) {
			case SDL_QUIT: throw DisplayQuit();
			/* key is pressed */
			case SDL_KEYDOWN:
				printf( "KEYDOWN " );
				M_mode = DRAW_SLOW;
				fflush( stdout );
				break;
			/* key is released */
			case SDL_KEYUP:
				printf( "KEYUP " );
				M_mode = DRAW_ALWAYS;
				fflush( stdout );
				break;
			case SDL_MOUSEBUTTONDOWN:
				printf( "BUTTONDOWN " );
				/* mouse click toggles between DRAW_ALWAYS and DRAW_STATSONLY */
				if( M_mode == DRAW_STATSONLY ) M_mode = DRAW_ALWAYS;
				else M_mode = DRAW_STATSONLY;
				fflush( stdout );
				break;
			}
		}
	}

#define USAGE "bluedogs - Mike Leonhard http://tamale.net\n"
#define FIELDW 80
#define FIELDH 60
#define MINIMUMCRITTERS 50
#define INITIALFOOD (FIELDW*FIELDH*32)
#define GROWTHRATE 200
#define GENOTYPELENGTH 64
#define INITIALENERGY 64

int main( int argc, char *argv[] ) {
	/* check command line */
	if( argc != 1 ) {
		/* print usage */
		fprintf( stderr, USAGE );
		return 1;
		}
	
	/* initialize */
	try {
		Display display( 800, 600, 16, "bluedogs" );
		/* seed the random number generator */
		srand( (unsigned int)time( NULL ) );
		
		/* prepare the field */
		Field field( display, FIELDW, FIELDH, INITIALFOOD, GROWTHRATE );
		
		/* prepare the initial critters */
		Population population( display );
		
		/* the simulation */
		Simulation simulation( display, field, population, MINIMUMCRITTERS, GENOTYPELENGTH, INITIALENERGY );
		
		/* run it */
		simulation.loop();/**/
		}
	
	/* graphics system failed to initialize */
	catch (DisplayInitFailure) { return 2; }
	/* video mode unavailable */
	catch (DisplayVideoModeFailure) { return 3; }
	/* normal exit */
	catch (DisplayQuit) { return 0; }
	
	/* program should never reach here */
	assert( 0 );
	return 0;
	}
