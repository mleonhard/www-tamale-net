/*
bluedogs.hh

Copyright (C) 2003
Michael Leonhard
http://tamale.net/
*/

#ifndef TREES_HH

/* class declarations */
class ListNode;
class QuadNode;

class ListNode {
	private:
		ListNode * M_next, * M_prev;
		QuadNode *M_quadTree;
		ListNode* getPrev();
		void verifyBackward();
		void verifyForward();
		void setNext( ListNode* next );
		void setPrev( ListNode* prev );
		int M_x, M_y;
	protected:
		QuadNode* getQuad();
		ListNode* location( int x, int y );
		void move( int x, int y );
	public:
		void joinQuad( QuadNode *quadTree );
		ListNode();
		ListNode( int x, int y );
		ListNode* getNext();
		int getX();
		int getY();
		void linkNext( ListNode* next );
		void linkPrev( ListNode* prev );
		virtual bool persist();
		void unlink();
		void verify();
	};

class QuadNode {
	private:
		/* list of ListNode items (will be NULL for branch nodes) */
		ListNode* M_itemList;
		/* edges of region */
		int M_left, M_right, M_top, M_bottom, M_centerX, M_centerY;
	protected:
		/* number of ListNode items in this node or all sub-nodes */
		int M_itemCount;
		
		/* sub nodes (will be NULL for leaf node) */
		QuadNode * M_i, * M_ii, * M_iii, * M_iv;

		/* private procedures */
		int in( int x, int y );
		QuadNode* leafNode( int x, int y );
		void split();
		void verify();
	public:
		virtual void add( ListNode* item );
		void cleanup();
		QuadNode* getI();
		QuadNode* getII();
		QuadNode* getIII();
		QuadNode* getIV();
		int getItemCount();
		ListNode* getList();
		ListNode* location( int x, int y );
		QuadNode( int left, int right, int top, int bottom );
		void relocation( ListNode* item, int oldx, int oldy );
		virtual void remove( ListNode* item );
	};


#define TREES_HH
#endif
