/*
treestest.cc

Copyright (C) 2003
Michael Leonhard
http://tamale.net/
*/

#include <assert.h>
#include <stdio.h>

#include "trees.hh"
class Nose;
class Bugger;

class Bugger : public ListNode {
	private: int M_id;
	public:
		Bugger( int x, int y ) : ListNode( x, y ) { M_id = -1; };
		Bugger() : ListNode() { M_id = -1; };
		~Bugger() { print(); }
		void print() { printf( "~Bugger(%d)\n", M_id ); }
		void setId( int id ) { M_id = id; }
		
	};

class Nose : public QuadNode {
	private: int M_idCount;
	public:
		Nose( int left, int right, int top, int bottom )
			 : QuadNode( left, right, top, bottom ) {
			M_idCount = 1;
			}
		void add( ListNode* item ) {
			Bugger* bugger = (Bugger *)item;
			bugger->setId( M_idCount++ );
			QuadNode::add( bugger );
			}
		void printNode( QuadNode *node ) {
			assert( node );
			
			/* this is a branch node */
			if( node->getI() ) {
				assert( 0 );
				printNode( node->getI() );
				printNode( node->getII() );
				printNode( node->getIII() );
				printNode( node->getIV() );
				return;
				}
			
			/* this is a leaf node */
			Bugger *bugger = (Bugger *)node->getList();
			while( bugger ) {
				bugger->print();
				bugger = (Bugger *)bugger->getNext();
				}
			}
		void print() { printNode( this ); }
	
	};

int main( int argc, char *argv[] ) {
	Bugger *list, *bugger;
	
	list = new Bugger();
	list->setId( 0 );
	
	/* make buggers */
	for( int n = 1; n < 5; n++ ) {
		bugger = new Bugger();
		bugger->setId( n );
		
		list->linkNext( bugger );
		}
		
	list->verify();
	list->getNext()->getNext()->getNext()->unlink();
	bugger = list;
	while( bugger ) {
		bugger->print();
		bugger = (Bugger *)bugger->getNext();
		}
	list->verify();
	return 0;
	}
