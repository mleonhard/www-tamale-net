/*
bluedogs.hh

Copyright (C) 2003
Michael Leonhard
http://tamale.net/
*/

#ifndef BLUEDOGS_H

#include <time.h>
#include "graphics.h"

/* tweakable program settings */
#define SCREENW 800
#define SCREENH 600
#define SCREEND 16

#define FIELDW 80
#define FIELDH 60
#define INITIALFOOD (FIELDW*FIELDH*32)
#define GROWTHRATE 50
#define SPROUTRATE 2

#define MINIMUMCRITTERS 50
#define GENOTYPELENGTH 256
#define INITIALENERGY 64
#define MAXENERGY 255 /* Because energy is an 8-bit register */
#define THINKCYCLES 32
#define FOODPOTENCY 4

/* macros */
#define RANDINT( n ) ((int)((float)(n) * rand() / (RAND_MAX + 1.0)))

#define EAST 0
#define NORTH 1
#define WEST 2
#define SOUTH 3

/* class declarations */
class Bacteria;
class Critter;
class Display;
class Field;
class RateCounter;
class CritterCounter;
class Mammal;
class NumberDisplay;

class Critter {
	friend class Field;
	protected:
		/* environment */
		Field* M_field;
		/* characteristics */
		int M_x, M_y, M_direction, M_energy;
		/* metadata */
		int M_id, M_birth, M_generation;
		/* VM variables */
		int M_p, M_genotypeLength, M_wait;
		unsigned char M_result, M_A, M_B, M_C;
		unsigned char* M_genotype;
		
		/* procedures */
		unsigned char getReg( int reg );
		void setReg( int reg, unsigned char val );
	
	public:
		/* procedures */
		Critter();
		Critter( Field &field, int genotypeLength, int initialEnergy );
		~Critter();
		virtual void draw( SDL_Surface* surface );
		int getAge();
		virtual unsigned char getAppearance();
		int getDirection();
		int getEnergy();
		int getGeneration();
		int getId();
		void printGenotype();
		void printState();
		void randomGenes();
		virtual void reproduce( int reg );
		void setId( int id );
		void update();
	};

class Bacteria : public Critter {
	private: int data;
	public:
		Bacteria( Field& field, int genotypeLength, int initialEnergy );
		Bacteria( Field& field, int x, int y, int direction, int energy, int generation, int genotypeLength, unsigned char *genotype );
		void reproduce( int reg );
	};

class Mammal : public Critter {
	private:
		int M_gender, M_partner;
	public:
		void draw( SDL_Surface* surface );
		unsigned char* getEgg();
		int getEggLength();
		int getGender();
		int getPartnerId();
		unsigned char* getSperm();
		int getSpermLength();
		Mammal( Field& field, int genotypeLength, int initialEnergy );
		Mammal( Field& field, int x, int y, int initialEnergy, Mammal& mother, Mammal& father );
		void mate( Mammal& partner );
		void orgasm();
		void reproduce( int reg );
	};

class Field : public Displayable {
	private:
		int M_idCount, M_maxAge, M_critterCount;
		int M_width, M_height, M_date, M_growthRate, M_growCounter, M_sproutRate, M_sproutCounter;
		unsigned char* M_field;
		bool M_drawSlow;
		Uint32 M_nextDraw;
		bool M_needsOptimize;
		Critter* * M_lookupTable;
	public:
		void add( Critter* critter );
		void addFood( int amount );
		void drawCell( SDL_Surface* surface, int x, int y, int red, int green, int blue, int direction );
		SDL_Rect const* draw( SDL_Surface* surface );
		void event( SDL_Event& event, Display& display );
		Field( int newWidth, int newHeight, int intialFood, int growthRate, int sproutRate );
		int food( int x, int y );
		void foodEaten( int x, int y );
		int getCritterCount() { return M_critterCount; };
		int getDate();
		void growFood();
		bool inRegion( int x, int y ) { return true; };
		int in( int x, int y );
		Critter* location( int x, int y );
		int look( int x, int y );
		void optimize( SDL_Surface* surface );
		void printGenotypes();
		int randX();
		int randY();
		void relocate( Critter* critter, int newX, int newY );
		void remove( Critter* criter );
		void update();
	};

#define BLUEDOGS_H
#endif
