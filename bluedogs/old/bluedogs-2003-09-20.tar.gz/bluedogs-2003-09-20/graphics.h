/*
 * graphics.h
 * 
 * Copyright (C) 2003
 * Michael Leonhard
 * http://tamale.net/
*/

#ifndef GRAPHICS_H

#include <SDL.h>

/* classes */
class Display;
class Displayable;
class Background;
class Text;
class Number;
class Rectangle;

/* instantiate this class to handle the display */
class Display {
	protected:
		SDL_Surface* M_surface;
		Displayable** M_widgetList;
		int M_widgetListLength, M_numWidgets;
		Displayable* M_focusedWidget;
	public:
		void addWidget( Displayable* widget );
		void dispatch( SDL_Event& event );
		void dispatch( SDL_Event& event, int x, int y );
		Display( int width, int height, int depth, const char* caption );
		~Display();
		void draw();
		int getHeight() { return M_surface->h; };
		SDL_Surface* getSurface() { return M_surface; };
		int getWidth() { return M_surface->w; };
		void setCaption( const char* caption ) { SDL_WM_SetCaption( caption, NULL ); };
		void setFocus( Displayable* widget );
		void updateRegion( SDL_Rect &rect );
	};
class DisplayError {};
class DisplayInitFailure : public DisplayError {};
class DisplayQuit : public DisplayError {};
class DisplayVideoModeFailure : public DisplayError {};

/* Make your widgets inherit from this class */
class Displayable {
	protected:
		SDL_Rect M_rect;
		bool M_visible;
	public:
		Displayable();
		Displayable( unsigned int x, unsigned int y );
		Displayable( unsigned int x, unsigned int y, unsigned int w, unsigned int h );
		virtual SDL_Rect const* draw( SDL_Surface* surface ) { return NULL; };
		virtual void event( SDL_Event& event, Display& display ) {};
		virtual SDL_Rect const* getRect() { return &M_rect; };
		virtual bool inRegion( int x, int y ) { return false; };
		bool isVisible() { return M_visible; };
		virtual void move( unsigned int x, unsigned int y ) { M_rect.x = x; M_rect.y = y; };
		virtual void optimize( SDL_Surface* surface ) {};
		virtual void resize( unsigned int w, unsigned int h ) { M_rect.w = w; M_rect.h = h; };
	};
class DisplayableInitFailure {};


/*************** Widgets ****************/

class Background : public Displayable {
	protected:
		Uint32 M_color;
		int M_red, M_green, M_blue;
		bool M_needsOptimize;
	public:
		Background( int red, int green, int blue );
		virtual SDL_Rect const* draw( SDL_Surface* screen );
		int getBlue() { return M_blue; };
		int getGreen() { return M_green; };
		int getRed() { return M_red; };
		void optimize( SDL_Surface* surface );
		void setColor( int red, int green, int blue );
	};
class BackgroundInitFailure : public DisplayableInitFailure {};

class Text : public Displayable {
	protected:
		int M_charWidth;
		SDL_Surface* M_unoptimizedFont;
		SDL_Surface* M_font;
		bool M_needsOptimize;
		char* M_text;
	public:
		virtual SDL_Rect const* draw( SDL_Surface* screen );
		const SDL_Rect* getRect() { return &M_rect; };
		const char* getText() { return M_text; };
		void optimize( SDL_Surface* surface );
		virtual void setText( const char* text );
		Text( int left, int top, const char* text );
	};
class TextInitFailure : public DisplayableInitFailure {};

class Number : public Text {
	protected:
		char* M_label;
		int M_number;
	public:
		void dec() { M_number--; render(); };
		void inc() { M_number++; render(); };
		Number( int left, int top, int number );
		Number( int left, int top, int number, const char* label );
		int getNumber() { return M_number; };
		const char* getLabel() { return M_label; }
		void render();
		void setLabel( const char* label );
		void setNumber( int number );
	};
class NumberInitFailure : public TextInitFailure {};

class Rectangle : public Background {
	public:
		Rectangle( int left, int right, int top, int bottom, int red, int green, int blue );
		SDL_Rect const* draw( SDL_Surface* screen );
		void optimize( SDL_Surface* screen );
	};
class RectangleInitFailure : public DisplayableInitFailure {};

#define GRAPHICS_H
#endif
