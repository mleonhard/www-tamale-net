/*
field.cc

Copyright (C) 2003
Michael Leonhard
http://tamale.net/
*/

#include <assert.h>
#include <SDL.h>
#include <stdlib.h>
#include <string.h>

#include "bluedogs.h"

#define CRITTER( x, y ) M_lookupTable[y*M_width + x]
#define FIELD( x, y ) M_field[ y*M_width + x ]

/* TODO: consolidate SDL_MapRGB() calls for field drawing */

void Field::add( Critter* critter ) {
	assert( critter );
	
	/* give the new critter an ID */
	critter->setId( M_idCount++ );
	M_critterCount++;
	
	/* add it to the lookup table */
	int x = critter->M_x, y = critter->M_y;
	assert( in( x, y ) );
	assert( CRITTER( x, y ) == NULL );
	CRITTER( x, y ) = critter;
	}

void Field::addFood( int amount ) {
	int x, y;
	
	assert( amount > 0);
	assert( M_field );
	assert( M_width > 0 );
	assert( M_height > 0 );
	
	/* for the whole amount specified */
	for(; amount > 0; amount-- ) {
		/* position of new food growth */
		x = RANDINT( M_width );
		y = RANDINT( M_height );
		assert( in( x, y ) );
		
		/* this point not yet full grown */
		if( FIELD( x, y ) < 255 ) {
			/* grow the food */
			FIELD( x, y ) ++;
			}
		}
	}

void Field::drawCell( SDL_Surface* surface, int x, int y, int red, int green, int blue, int direction ) {
	assert( in( x, y ) );
	
	SDL_Rect rect;
	int hMargin = M_cellWidth / 4;
	int vMargin = M_cellHeight / 4;
	
	/* critter is drawn centered in the cell */
	int left = M_rect.x + (M_cellWidth * x);
	int top = M_rect.y + (M_cellHeight * y);
	int right = left + M_cellWidth;
	int bottom = top + M_cellHeight;
	rect.x = left + hMargin;
	rect.y = top + vMargin;
	rect.w = M_cellWidth - 2*hMargin;
	rect.h = M_cellHeight - 2*vMargin;
	
	/* draw the cell */
	SDL_FillRect( surface, &rect, SDL_MapRGB( surface->format, (unsigned char)red, (unsigned char)green, (unsigned char)blue ) );
	
	/* don't draw head if cell is too small */
	if( rect.w < 2 || rect.h < 2 ) return;
	if( rect.w == 3 ) hMargin = 0;
	if( rect.h == 3 ) vMargin = 0;
	int hEdge = hMargin / 3;
	int vEdge = vMargin / 3;
	
	/* construct the "head" pointing in right direction */
	switch( direction ) {
		case NORTH:
			rect.x += hEdge;
			rect.w -= hEdge * 2;
			rect.y += vEdge;
			rect.h = (vEdge)?vEdge:1;
			break;
		case SOUTH:
			rect.x += hEdge;
			rect.w -= hEdge * 2;
			rect.y += rect.h;
			rect.h = (vEdge)?vEdge:1;
			rect.y -= rect.h;
			rect.y -= vEdge;
			break;
		case EAST:
			rect.y += vEdge;
			rect.h -= vEdge * 2;
			rect.x += rect.w;
			rect.w = (hEdge)?hEdge:1;
			rect.x -= rect.w;
			rect.x -= hEdge;
			break;
		case WEST:
			rect.y += vEdge;
			rect.h -= vEdge * 2;
			rect.x += hEdge;
			rect.w = (hEdge)?hEdge:1;
			break;
		}
	
	/* get the max intensity */
	int clr = red;
	if( blue > clr ) clr = blue;
	if( green > clr ) clr = green;
	
	/* calculate the head color */
	if( clr < 64 ) clr = 64 + (3 * clr);
	else if( clr < 128 ) clr = 447 - (3 * clr);
	else clr = 107 - (clr / 3);
	
	/* draw the head */
	unsigned char clr8 = (unsigned char)clr;
	SDL_FillRect( surface, &rect, SDL_MapRGB( surface->format, clr8, clr8, clr8 ) );
	}

SDL_Rect const* Field::draw( SDL_Surface* surface ) {
	/* is not visible */
	if( !M_visible ) return NULL;

	/* window is too small */
	if( M_width >= surface->w || M_height >= surface->h ) {
		SDL_FillRect( surface, NULL, SDL_MapRGB( surface->format, 0, 0, 0xFF ) );
		return &M_rect;
		}

	/* drawing slow */
	if( M_drawSlow ) {
		assert( M_nextDraw <= SDL_GetTicks() + 1000 );
		/* not yet time to draw */
		if( SDL_GetTicks() < M_nextDraw ) return NULL;
		/* the next draw will happen at */
		M_nextDraw = SDL_GetTicks() + 1000;
		}
	
	/* needs optimization */
	if( M_needsOptimize ) optimize( surface );
	
	assert( surface );
	assert( M_field );
	assert( M_width > 0 );
	assert( M_height > 0 );
	
	SDL_Rect rect;
	int x, y, intensity;
	
	rect.w = (unsigned short)M_cellWidth;
	rect.h = (unsigned short)M_cellHeight;
	
	/* rows */
	rect.y = M_rect.y;
	for( y = 0; y < M_height; y++ ) {
		/* columns */
		rect.x = M_rect.x;
		for( x = 0; x < M_width; x++ ) {
			/* strength of plant growth */
			intensity = FIELD( x, y );
			/* draw the space as a shade of green */
			SDL_FillRect( surface, &rect, SDL_MapRGB( surface->format, (unsigned char)(intensity >> 2), (unsigned char)(intensity), (unsigned char)(intensity >> 2) ) );
			/* next block */
			rect.x += rect.w;
			}
		/* move down one row */
		rect.y += rect.h;
		}
	
	/* draw the critters */
	Critter* critter;
	for( y = 0; y < M_height; y++ ) {
		for( x = 0; x < M_width; x++ ) {
			critter = CRITTER( x, y );
			if( critter ) critter->draw( surface );
			}
		}
	/* return update region */
	return &M_rect;
	}

void Field::event( SDL_Event& event, Display& display ) {
	switch( event.type ) {
		case SDL_MOUSEBUTTONDOWN:
			printf( "BUTTONDOWN " );
			assert( M_nextDraw <= SDL_GetTicks() + 1000 );
			/* mouse click toggles slow mode */
			if( M_drawSlow ) M_drawSlow = false;
			else {
				M_drawSlow = true;
				/* the next draw will happen at */
				M_nextDraw = SDL_GetTicks() + 1000; 
				}
			fflush( stdout );
			break;
		}
	}

Field::Field( int newWidth, int newHeight, int initialFood, int growthRate, int sproutRate ) {
	
	/* initialize data */
	M_visible = true;
	move( 0, 0 );
	resize( 0, 0 );
	M_idCount = 1;
	M_maxAge = 0;
	assert( newWidth );
	assert( newHeight );
	assert( initialFood );
	assert( growthRate >= 0 );
	
	M_critterCount = 0;
	M_drawSlow = false;
	M_nextDraw = 0;
	M_width = newWidth;
	M_height = newHeight;
	M_cellWidth = 0; /* cell width and height are set by optimize() */
	M_cellHeight = 0;
	M_date = 1;
	M_growthRate = growthRate;
	M_growCounter = 0;
	M_sproutRate = sproutRate;
	M_sproutCounter = 0;
	
	/* allocate memory */
	M_field = (unsigned char *)malloc( M_width * M_height * sizeof( unsigned char ) );
	assert( M_field );
	
	/* clear field of food */
	memset( M_field, 0, M_width * M_height * sizeof( unsigned char ) );
	
	/* add the initial random food growth */
	addFood( initialFood );
	
	/* set up lookup table */
	M_lookupTable = (Critter* *)malloc( sizeof( Critter* ) * newWidth * newHeight );
	assert( M_lookupTable );
	for( int i = 0; i < newWidth * newHeight; i++ ) M_lookupTable[i] = NULL;
	}

Field::~Field() {
	Critter* critter;
	for( int y = 0; y < M_height; y++ ) {
		for( int x = 0; x < M_width; x++ ) {
			critter = CRITTER( x, y );
			if( critter ) {
				assert( critter->getId() );
				assert( critter->getId() < M_idCount );
				assert( critter->M_x == x );
				assert( critter->M_y == y );
				assert( critter->M_energy > 0 );
				remove( critter );
				}
			}
		}
	assert( M_critterCount == 0 );
	}

int Field::food( int x, int y ) {
	assert( M_field );
	assert( M_width > 0 );
	assert( M_height > 0 );
	
	/* coordinates are outside of field */
	if( x < 0 || x >= M_width || y < 0 || y >= M_height ) return 128;
	/* return value of plant growth */
	return (FIELD( x, y ) + 15)>> 4; /* to keep inside 0-15 */
	}

void Field::foodEaten( int x, int y ) {
	assert( in( x, y ) );
	assert( M_field[ y*M_width + x ] );
	FIELD( x, y ) --;
	};

int Field::getDate() {
	return M_date;
	}

void Field::growFood() {
	assert( M_field );
	assert( M_width > 0 );
	assert( M_height > 0 );
	
	/* start at upper left corner */
	int max = M_width * M_height;
	int cell = RANDINT( M_growthRate );
	int sprout = 0;
	
	while( cell < max ) {
		/* this point has plants */
		if( M_field[cell] ) {
			 /* plants are not yet full grown */
			 if( M_field[cell] < 255 ) M_field[cell] ++;
			 /* plant is adult (>64) but not old (>=250) */
			 if( M_field[cell] > 64 && M_field[cell] < 250 ) {
				/* sprout once every M_sproutRate */
				if( M_sproutCounter == M_sproutRate ) {
				 	/* sprout in adjacent cell*/
					sprout = cell + (RANDINT( 3 ) - 1)*M_width + RANDINT( 3 ) - 1;
					/* spot is inside field and empty */
					if( sprout < max && M_field[sprout] == 0 ) {
						/* new plant growth at spot */
						M_field[sprout] = 1;
						}
					/* reset counter */
					M_sproutCounter = 0;
					}
				else if( M_sproutCounter <= M_sproutRate ) M_sproutCounter++;
				else assert( 0 );
				}
			}
				
		
		/* move on */
		cell += RANDINT( M_growthRate );
		}
	}

int Field::in( int x, int y ) {
	assert( M_field );
	assert( M_width > 0 );
	assert( M_height > 0 );
	
	/* coordinates are outside of field */
	if( x < 0 || x >= M_width || y < 0 || y >= M_height ) return 0;
	/* inside */
	else return 1;
	}

bool Field::inRegion( int x, int y ) {
	if( x < M_rect.x || x >= M_rect.x + M_rect.w ) return false;
	if( y < M_rect.y || y >= M_rect.y + M_rect.h ) return false;
	return true;
	}

Critter* Field::location( int x, int y ) {
	/* coordinates are not in this field */
	if( !in( x, y ) ) return NULL;
	return CRITTER( x, y );
	}

int Field::look( int x, int y ) {
	assert( M_field );
	assert( M_width > 0 );
	assert( M_height > 0 );
	
	/* coordinates are outside of field */
	if( x < 0 || x >= M_width || y < 0 || y >= M_height ) return 128;
	/* critter is at that spot */
	if( CRITTER( x, y ) != NULL ) return 64;
	/* return value of plant growth */
	return (FIELD( x, y ) + 15)>> 4; /* to keep inside 0-15 */
	}

void Field::moveCritter( Critter* critter, int newx, int newy ) {
	assert( critter );
	int oldx = critter->M_x, oldy = critter->M_y;
	assert( in( oldx, oldy ) );
	assert( CRITTER( oldx, oldy ) == critter );
	CRITTER( oldx, oldy ) = NULL;
	
	/* move the critter */
	critter->M_x = newx;
	critter->M_y = newy;
	
	/* add it to the lookup table */
	assert( in( newx, newy ) );
	assert( CRITTER( newx, newy ) == NULL );
	CRITTER( newx, newy ) = critter;
	}

void Field::optimize( SDL_Surface* surface ) {
	assert( surface );
	
	/* window is too small */
	if( M_width >= surface->w || M_height >= surface->h ) {
		move( 0, 0 );
		resize( surface->w, surface->h );
		M_needsOptimize = false;
		return;
		}
	
	M_cellWidth = surface->w / M_width;
	M_cellHeight = surface->h / M_height;
	
	int M_leftEdge = (surface->w - (M_cellWidth * M_width)) / 2;
	int M_topEdge = (surface->h - (M_cellHeight * M_height)) / 2;
	
	move( M_leftEdge, M_topEdge );
	resize( M_cellWidth * M_width, M_cellHeight * M_height );
	M_needsOptimize = false;
	}

void Field::printGenotypes() {
	for( int y = 0; y < M_height; y++ ) {
		for( int x = 0; x < M_width; x++ ) {
			if( CRITTER( x, y ) ) CRITTER( x, y )->printGenotype();
			}
		}
	}

int Field::randX() { return RANDINT( M_width ); };
int Field::randY() { return RANDINT( M_height ); };

void Field::remove( Critter* critter ) {
	assert( critter );
	assert( critter->getId() );
	assert( critter->getId() < M_idCount );
	
	int x = critter->M_x, y = critter->M_y;
	assert( in( x, y ) );
	assert( CRITTER( x, y ) == critter );
	CRITTER( x, y ) = NULL;
	delete critter;
	assert( M_critterCount >= 0 );
	M_critterCount--;
	}

void Field::update() {
	/* time passes */
	M_date++;
	
	/* grow the food */
	growFood();
	
	verify();

	/* let the critters move */
	Critter* critter;
	for( int y = 0; y < M_height; y++ ) {
		for( int x = 0; x < M_width; x++ ) {
			critter = CRITTER( x, y );
			if( critter ) {
				assert( critter->getId() );
				assert( critter->getId() < M_idCount );
				assert( critter->M_x == x );
				assert( critter->M_y == y );
				if( critter->M_energy ) critter->update();
				if( critter->M_energy < 1 ) remove( critter );
				}
			}
		}
	verify();
	}

void Field::verify() {
	Critter* critter;
	int cCount = 0;
	for( int y = 0; y < M_height; y++ ) {
		for( int x = 0; x < M_width; x++ ) {
			critter = CRITTER( x, y );
			if( critter ) {
				cCount++;
				assert( critter->getId() );
				assert( critter->getId() < M_idCount );
				assert( critter->M_x == x );
				assert( critter->M_y == y );
				assert( critter->M_energy > 0 );
				}
			}
		}
	assert( cCount == M_critterCount );
	}
