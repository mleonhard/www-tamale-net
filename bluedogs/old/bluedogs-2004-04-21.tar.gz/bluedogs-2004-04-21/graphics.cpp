/*
graphics.cpp

Copyright (C) 2003
Michael Leonhard
http://tamale.net/
*/

#include <assert.h>
#include <malloc.h>
#include <stdio.h>
#include <string.h>
#include <SDL.h>
#include <SDL_image.h>

#include "graphics.h"

#define FONT "white.big.png"

/* TODO:
 *	return descriptive text with exceptions
 *	implement Display::raise( Displayable &widget )
 *	implement inRegion() for all widgets
 *	pass unhandled messages to widget below
*/

/******************************************************************************
 * Display
 ******************************************************************************
*/
 
void Display::addWidget( Displayable* widget ) {
	assert( widget );
	assert( M_widgetList );
	assert( M_numWidgets < M_widgetListLength );
	
	int i;
	
	/* make sure that the widget isn't already in the list */
	for( i = 0; i < M_widgetListLength; i++ ) {
		if( M_widgetList[i] == widget ) {
			assert( 0 ); /* widget cannot be added to a that list it is already in */
			return; /* non-debug builds will ignore this problem */
			}
		}
	
	/* no extra spaces in list */
	if( M_numWidgets + 1 == M_widgetListLength ) {
		/* make a bigger list */
		int newListLength = M_widgetListLength + 8;
		Displayable** newList = (Displayable* *)malloc( sizeof( Displayable* ) * newListLength );
		assert( newList );
		
		/* copy the entries from the old list */
		for( i = 0; i < M_numWidgets; i++ ) newList[i] = M_widgetList[i];
		
		/* zero the empty spaces */
		for( ; i < newListLength; i++ ) newList[i] = NULL;
		
		/* switch to new list */
		delete M_widgetList;
		M_widgetList = newList;
		M_widgetListLength = newListLength;
		}
	
	/* save widget as next entry in list */
	assert( M_widgetList[M_numWidgets] == NULL );
	M_widgetList[M_numWidgets] = widget;
	M_numWidgets++;
	
	/* let the widget optimize itself for our display */
	widget->optimize( M_surface );
	}

void Display::dispatch( SDL_Event& event, int x, int y ) {
	/* walk through list from last to first */
	for( int i = M_numWidgets - 1; i > -1; i-- ) {
		assert( M_widgetList[i] );
		/* coordinates lie in the widget's region */
		if( M_widgetList[i]->inRegion( x, y ) ) {
			/* dispatch the event to the widget */
			M_widgetList[i]->event( event, *this );
			return;
			}
		}
	}

void Display::dispatch( SDL_Event& event ) {
	/* handle each type of event */
	switch( event.type ) {
		/* user closed the window */
		case SDL_QUIT: throw DisplayQuit();
		
		/* key events go to focused widget */
		case SDL_KEYDOWN:
		case SDL_KEYUP:
			if( M_focusedWidget ) M_focusedWidget->event( event, *this );
			break;
		/* mouse events go to the widget under the mouse pointer */
		case SDL_MOUSEBUTTONDOWN:
		case SDL_MOUSEBUTTONUP:
			dispatch( event, event.button.x, event.button.y );
			break;
		case SDL_MOUSEMOTION:
			dispatch( event, event.motion.x, event.motion.y );
			break;
		/* window resize */
		case SDL_VIDEORESIZE:
			/* change the display size */
			setVideoMode( event.resize.w, event.resize.h);
			/* re-optimize all widgets */
			assert( M_widgetList );
			assert( M_widgetListLength );
			assert( M_numWidgets < M_widgetListLength );
			for( int i = 0; i < M_numWidgets; i++ ) {
				assert( M_widgetList[i] );
				M_widgetList[i]->optimize( M_surface );
				}
			break;
		}
	}

Display::Display( int width, int height, const char* caption ) {
	
	assert( width );
	assert( height );
	assert( caption );
	
	/* initialize SDL */
	if( SDL_Init( SDL_INIT_VIDEO ) < 0 ) {
		fprintf(stderr, "Couldn't initialize SDL: %s\n",SDL_GetError());
		throw DisplayInitFailure();
		}
	
	/* Set window caption */
	SDL_WM_SetCaption( caption, caption );
	
	/* set the video mode */
	M_surface = NULL;
	setVideoMode( width, height );
	
	/* initalize widget list */
	M_widgetListLength = 8;
	M_widgetList = (Displayable* *)malloc( sizeof( Displayable* ) * M_widgetListLength );
	assert( M_widgetList );
	for( int i = 0; i < M_widgetListLength; i++ ) M_widgetList[i] = NULL;
	M_numWidgets = 0;
	
	/* initially there is no focused widget */
	M_focusedWidget = NULL;
	}

Display::~Display() {
	/* free each widget */
	for( int i = 0; i < M_numWidgets; i++ ) {
		assert( M_widgetList[i] );
		delete M_widgetList[i];
		}
	
	/* free the widget list memory */
	delete M_widgetList;
	M_widgetList = NULL;
	M_widgetListLength = 0;
	M_numWidgets = 0;
	
	/* shut down SDL /
	SDL_Quit();/**/
	}

void Display::draw() {
	assert( M_surface );
	assert( M_widgetList );
	assert( M_widgetListLength );
	assert( M_numWidgets < M_widgetListLength );
	
	int left = -1, right = -1, top = -1, bottom = -1;
	SDL_Rect const* rect;
	
	/* each widget */
	for( int i = 0; i < M_numWidgets; i++ ) {
		assert( M_widgetList[i] );
		/* draw the widget */
		rect = M_widgetList[i]->draw( M_surface );
		/* add returned rectangle to update region */
		if( rect ) {
			/* no existing update region */
			if( left == -1 ) {
				/* use returned region */
				left = rect->x;
				top = rect->y;
				right = rect->x + rect->w;
				bottom = rect->y + rect->h;
				}
			/* add to existing region */
			else {
				if( rect->x < left ) left = rect->x;
				if( rect->y < top ) top = rect->y;
				if( rect->x + rect->w > right ) right = rect->x + rect->w;
				if( rect->y + rect->h > bottom ) bottom = rect->y + rect->h;
				}
			}
		}
	/* clamp region to screen */
	if( left < 0 ) left = 0;
	if( top < 0 ) top = 0;
	if( right > M_surface->w ) right = M_surface->w;
	if( bottom > M_surface->h ) bottom = M_surface->h;
	
	/* update the screen */
	SDL_UpdateRect( M_surface, left, top, right - left, bottom - top );
	
	/*int ret = SDL_Flip( M_surface );
	if( ret == -1 ) {
		fprintf( stderr, "SDL_Flip failed: %s\n",SDL_GetError() );
		throw DisplayError();
		}/**/
	}

void Display::setFocus( Displayable* widget ) {
	assert( widget );
	M_focusedWidget = widget;
	}

void Display::setVideoMode( int width, int height ) {
	/* free existing screen surface */
	if( M_surface ) {
		SDL_FreeSurface( M_surface );
		M_surface = NULL;
		}
	
	/* sanity check */
	if( width < 1 ) width = 1;
	if( height < 1 ) height = 1;

	/* set the video mode with the current color depth*/
	M_surface = SDL_SetVideoMode( width, height, 0, SDL_RESIZABLE );/*SDL_SWSURFACE*/
	
	/* failure */
	if( M_surface == NULL ) {
		fprintf( stderr,"Couldn't set video mode: %s\n", SDL_GetError() );
		SDL_Quit();
		throw DisplayVideoModeFailure();
		}
	}

void Display::updateRegion( SDL_Rect &rect) {
	/* update the region on the screen */
	SDL_UpdateRect( M_surface, rect.x, rect.y, rect.w, rect.h );
	}

/******************************************************************************
 * Displayable
 ******************************************************************************
*/
Displayable::Displayable() {
	move( 0, 0 );
	resize( 0, 0 );
	M_visible = false;
	}

Displayable::Displayable( int x, int y ) {
	move( x, y );
	resize( 0, 0 );
	M_visible = false;
	}

Displayable::Displayable( int x, int y, int w, int h ) {
	move( x, y );
	resize( w, h );
	M_visible = false;
	}

/******************************************************************************
 * Background
 ******************************************************************************
*/
Background::Background( int red, int green, int blue ) {
	setColor( red, green, blue );
	M_needsOptimize = true;
	M_visible = true;
	}

SDL_Rect const* Background::draw( SDL_Surface *screen ) {
	/* is not visible */
	if( !M_visible ) return NULL;
	/* needs optimization */
	if( M_needsOptimize ) optimize( screen );
	/* fill the entire screen with color */
	SDL_FillRect( screen, NULL, M_color );
	/* update region is entire screen */
	return &M_rect;
	}

void Background::optimize( SDL_Surface* screen ) {
	assert( screen );
	M_color = SDL_MapRGB( screen->format, M_red, M_green, M_blue );
	move( 0, 0 );
	resize( screen->w, screen->h );
	M_needsOptimize = false;
	}

void Background::setColor( int red, int green, int blue ) {
	M_red = red;
	M_green = green;
	M_blue = blue;
	M_needsOptimize = true;
	}

/******************************************************************************
 * Rectangle
 ******************************************************************************
*/
Rectangle::Rectangle( int left, int right, int top, int bottom, int red, int green, int blue )
	 : Background( red, green, blue ) {
	move( left, top );
	resize( right - left, bottom - top );
	}

SDL_Rect const* Rectangle::draw( SDL_Surface* screen ) {
	/* is not visible */
	if( !M_visible ) return NULL;
	/* needs optimization */
	if( M_needsOptimize ) optimize( screen );
	/* draw the rectangle on the screen */
	SDL_FillRect( screen, &M_rect, M_color );
	/* return update region */
	return &M_rect;
	}

void Rectangle::optimize( SDL_Surface* screen ) {
	assert( screen );
	M_color = SDL_MapRGB( screen->format, M_red, M_green, M_blue );
	M_needsOptimize = false;
	}
	
/******************************************************************************
 * Text
 ******************************************************************************
*/
SDL_Rect const* Text::draw( SDL_Surface* screen ) {
	SDL_Rect srcrect, dstrect;
	
	/* is not visible */
	if( !M_visible ) return NULL;

	/* needs optimization */
	if( M_needsOptimize ) optimize( screen );
	
	assert( screen );
	assert( M_text );
	assert( M_font );
	dstrect.x = M_rect.x;
	dstrect.y = M_rect.y;
	srcrect.y = 0;
	srcrect.w = M_charWidth;
	srcrect.h = M_font->h;
	
	/* draw each digit */
	char* digit = M_text;
	while( *digit ) {
		srcrect.x = (*digit) * M_charWidth;
		if( dstrect.x >= screen->w ) break;
		SDL_BlitSurface( M_font, &srcrect, screen, &dstrect );
		dstrect.x = dstrect.x + M_charWidth;
		digit++;
		};
	/* return update region */
	return &M_rect;
	}

void Text::optimize( SDL_Surface* screen ) {
	assert( screen );
	assert( M_unoptimizedFont );
	
	/* free old font */
	if( M_font ) SDL_FreeSurface( M_font );
	
	/* optimize for transparencies */
	M_font = SDL_DisplayFormatAlpha( M_unoptimizedFont );
	assert( M_font );
	
	M_needsOptimize = false;
	}

void Text::setText( const char* newText ) {
	assert( newText );
	int newTextLen = strlen( newText );
	
	/* recalculate text width */
	M_rect.w = M_charWidth * newTextLen;
	
	/* no existing string */
	if( M_text == NULL ) {
		/* allocate memory for new string (and NULL terminator) */
		M_text = (char *)malloc( sizeof( char ) * (newTextLen + 1) );
		assert( M_text );
		}
	/* existing string is too small */
	else if( strlen( M_text ) < newTextLen ) {
		/* free the existing string */
		free( M_text );
		/* allocate memory for new string (and NULL terminator) */
		M_text = (char *)malloc( sizeof( char ) * (newTextLen + 1) );
		assert( M_text );
		}
	
	/* copy the string (including NULL terminator) */
	strncpy( M_text, newText, newTextLen + 1 );
	}

Text::Text( int left, int top, const char* text ) {
	
	/* ???????????????????????????????? !"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\]^_`abcdefghijklmnopqrstuvwxyz{|}~? */
	
	M_visible = true;
	
	/* load the font */
	M_unoptimizedFont = IMG_Load( FONT );
	if( M_unoptimizedFont == NULL ) {
		fprintf( stderr,"Couldn't load image, %s: %s\n", FONT, SDL_GetError() );
		throw TextInitFailure();
		return;
		}
	
	/* font image needs to be converted to display format */
	M_font = NULL;
	M_needsOptimize = true;
	
	/* width of one character */
	M_charWidth = M_unoptimizedFont->w / 128;
	
	/* dimensions */
	move( left, top );
	resize( 0, M_unoptimizedFont->h ); /* width will be calculated by setText() */
	
	/* text */
	M_text = NULL;
	setText( text );
	}

Text::~Text() {
	printf( "~Text(\"%s\") ", M_text );
	fflush( stdout );
	
	SDL_FreeSurface( M_unoptimizedFont );
	M_unoptimizedFont = NULL;
	if( M_font ) SDL_FreeSurface( M_font );
	M_font = NULL;
	if( M_text ) free( M_text );
	M_text = NULL;
	}

/******************************************************************************
 * Number
 ******************************************************************************
*/
Number::Number( int left, int top, int number )
	 : Text( left, top, "" ) {
	M_label = NULL;
	M_number = number;
	render();
	}

Number::Number( int left, int top, int number, const char* label )
	 : Text( left, top, "" ) {
	M_label = NULL;
	M_number = number;
	setLabel( label );
	}

Number::~Number() {
	printf( "~Number(\"%s\", %d) ", M_label, M_number );
	fflush( stdout );
	if( M_label ) free( M_label );
	M_label = NULL;
	}

void Number::setLabel( const char* label ) {
	/* identical strings */
	if( M_label && label && strcmp( M_label, label ) == 0 ) return;
	
	/* free existing label */
	if( M_label ) {
		free( M_label );
		M_label = NULL;
		}
	
	/* no new label */
	if( label == NULL ) return;
	
	/* copy new label */
	int len = strlen( label ) + 1;
	M_label = (char*)malloc( sizeof( char ) * len );
	assert( M_label );
	strncpy( M_label, label, len );
	
	/* update the text */
	render();
	}

void Number::setNumber( int number ) {
	/* no change */
	if( number == M_number ) return;
	/* save the number */
	M_number = number;
	/* update the text */
	render();
	}

void Number::render() {
	int i = 0;
	
	/* label exists */
	if( M_label ) i = strlen( M_label );
	
	/* maximum number of digits */
	int max = i + 127;
	
	/* get memory for digits */
	char* digits = (char*)malloc( sizeof( char ) * (max + 1) );
	assert( digits );
	
	/* copy label */
	if( M_label ) strncpy( digits, M_label, max );
	
	/* number is negative */
	int absNumber = M_number;
	if( absNumber < 0 ) {
		digits[i++] = '-';
		absNumber = 0 - absNumber;
		}
	
	/* zero */
	if( absNumber == 0 ) i++;
	
	/* count digits */
	int number = absNumber;
	for( ; i < max; i++ ) {
		if( number == 0 ) break;
		number /= 10;
		}
	assert( number == 0 );
	
	/* recalculate text width */
	M_rect.w = M_charWidth * i;

	/* null terminate */
	digits[i--] = 0;
	
	/* each digit */
	number = absNumber;
	for( ; i >= 0; i-- ) {
		digits[i] = (char)(48 + (number % 10));
		number /= 10;
		if( number == 0 ) break;
		}
	
	/* free existing text */
	if( M_text ) free( M_text );
	/* set the text */
	M_text = digits;
	}
