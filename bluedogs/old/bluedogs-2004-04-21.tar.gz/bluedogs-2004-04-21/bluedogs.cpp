/*
bluedogs.cc

Copyright (C) 2003
Michael Leonhard
http://tamale.net/
*/

#include <assert.h>
#include <SDL.h>
#include <stdlib.h>
#include <time.h>

#include "bluedogs.h"

#define USAGE "bluedogs - Copyright (C) 2003 Mike Leonhard http://tamale.net\n"

class RateCount : public Number {
	private:
		Uint32 M_nextUpdate;
	public:
	SDL_Rect const* draw( SDL_Surface* surface ) {
		/* draw it */
		Number::draw( surface );
		
		/* not yet time to update count */
		if( SDL_GetTicks() < M_nextUpdate ) {
			M_number++;
			return &M_rect;
			}
		
		/* update */
		render();
		/* the next update will happen at */
		M_nextUpdate = SDL_GetTicks() + 1000;
		/* reset */
		M_number = 0;
		return &M_rect;
		};
	
	RateCount( short left, short top )
		 : Number( left, top, 0, "Cycles/sec:" ) {
		M_nextUpdate = SDL_GetTicks() + 1000;
		};
	};

class PopulationCount : public Number {
	private:
		Field* M_field;
	public:
	SDL_Rect const* draw( SDL_Surface* surface ){
		assert( M_field );
		/* get the new population statistic */
		M_number = M_field->getCritterCount();
		/* update the text */
		render();
		/* draw it */
		return Number::draw( surface );
		};
	PopulationCount( Field* field, short left, short top )
		 : Number( left, top, 0, "Population:" ) {
		assert( field );
		M_field = field;
		M_number = M_field->getCritterCount();
		};
	};

class DayCount : public Number {
	private:
		Field* M_field;
	public:
	SDL_Rect const* draw( SDL_Surface* surface ) {
		assert( M_field );
		/* set the new day */
		setNumber( M_field->getDate() );
		/* draw it */
		return Number::draw( surface );
		};
	
	DayCount( Field* field, short left, short top )
		 : Number( left, top, 0, "Day:" ) {
		assert( field );
		M_field = field;
		M_number = M_field->getDate();
		render();
		};
	};

int main( int argc, char *argv[] ) {
	/* check command line */
	if( argc != 1 ) {
		/* print usage */
		fprintf( stderr, USAGE );
		return 1;
		}
	
	/* initialize */
	try {
		/* create the window */
		Display display( SCREENW, SCREENH, "bluedogs" );
		
		/* seed the random number generator */
		srand( (unsigned int)time( NULL ) );
		
		/* prepare the field */
		Field& field = *new Field( FIELDW, FIELDH, INITIALFOOD, GROWTHRATE, SPROUTRATE );
		
		/* put the field into the display */
		display.addWidget( &field );
		
		/* counters */
		display.addWidget( new RateCount( 20, 20 ) );
		display.addWidget( new PopulationCount( &field, 20, 45 ) );
		display.addWidget( new DayCount( &field, 20, 70 ) );
		
		/* run the simulation */
		SDL_Event event;
		while( 1 ) {
			/* dispatch all messages on event queue */
			while( SDL_PollEvent( &event ) ) display.dispatch( event );
			
			/* draw the screen */
			display.draw();
			
			/* keep the population above minimum */
			for( int c = field.getCritterCount(); c < MINIMUMCRITTERS; c++ ) {
				/* add a bacteria */
				field.add( new Bacteria( field, GENOTYPELENGTH, INITIALENERGY ) );

				/* choose randomly between bacteria and mammal /
				if( RANDINT( 3 ) ) {
					/* make a new bacteria /
					field.add( new Bacteria( field, GENOTYPELENGTH, INITIALENERGY ) );
					}
				else {
					/* make a new mammal /
					field.add( new Mammal( field, GENOTYPELENGTH, INITIALENERGY ) );/
					}/**/
				}
			
			/* update the simulation */
			field.update();/**/
			}
		}
	
	/* graphics system failed to initialize */
	catch (DisplayInitFailure) { return 2; }
	/* video mode unavailable */
	catch (DisplayVideoModeFailure) { return 3; }
	/* normal exit */
	catch (DisplayQuit) { return 0; }
	
	/* program should never reach here */
	assert( 0 );
	return 0;
	}
