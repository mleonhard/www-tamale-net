/*
field.cc

Copyright (C) 2003
Michael Leonhard
http://tamale.net/
*/

#include <assert.h>
#include <SDL.h>
#include <stdlib.h>
#include <string.h>

#include "bluedogs.hpp"

void Field::addFood( int amount ) {
	int x, y;
	
	assert( amount > 0);
	assert( M_field );
	assert( M_width > 0 );
	assert( M_height > 0 );
	
	/* for the whole amount specified */
	for(; amount > 0; amount-- ) {
		/* position of new food growth */
		x = RANDINT( M_width );
		y = RANDINT( M_height );
		assert( in( x, y ) );
		
		/* this point not yet full grown */
		if( M_field[ y*M_width + x ] < 255 ) {
			/* grow the food */
			M_field[ y*M_width + x ] ++;
			}
		}
	}

SDL_Rect& Field::cellRect( int x, int y ) {
	assert( in( x, y ) );
	
	SDL_Rect& rect = *new SDL_Rect;
	
	rect.w = M_display->getWidth() / M_width;
	rect.h = M_display->getHeight() / M_height;
	
	rect.x = rect.w * x;
	rect.y = rect.h * y;
	
	return rect;
	}

void Field::draw() {
	assert( M_display );
	assert( M_field );
	assert( M_width > 0 );
	assert( M_height > 0 );
	
	SDL_Rect rect;
	int x, y, intensity;
	
	rect.w = M_display->getWidth() / M_width;
	rect.h = M_display->getHeight() / M_height;
	
	/* rows */
	rect.y = 0;
	for( y = 0; y < M_height; y++ ) {
		/* columns */
		rect.x = 0;
		for( x = 0; x < M_width; x++ ) {
			/* strength of plant growth */
			intensity = M_field[y*M_width + x];
			/* space has growth, so draw it as a shade of green */
			if( intensity ) M_display->drawCell( rect, intensity >> 2, intensity, intensity >> 2 );
			/* next block */
			rect.x += rect.w;
			}
		/* move down one row */
		rect.y += rect.h;
		}
	}

Field::Field( Display& display, int newWidth, int newHeight, int initialFood, int growthRate, int sproutRate ) {
	assert( newWidth );
	assert( newHeight );
	assert( initialFood );
	assert( growthRate >= 0 );
	
	M_display = &display;
	M_width = newWidth;
	M_height = newHeight;
	M_date = 1;
	M_growthRate = growthRate;
	M_growCounter = 0;
	M_sproutRate = sproutRate;
	M_sproutCounter = 0;
	
	/* allocate memory */
	M_field = (unsigned char *)malloc( M_width * M_height * sizeof( unsigned char ) );
	assert( M_field );
	
	/* clear field of food */
	memset( M_field, 0, M_width * M_height * sizeof( unsigned char ) );
	
	addFood( initialFood );
	}

void Field::foodEaten( int x, int y ) {
	assert( in( x, y ) );
	assert( M_field[ y*M_width + x ] );
	M_field[ y*M_width + x ] --;
	};

int Field::getDate() {
	return M_date;
	}

void Field::growFood() {
	assert( M_field );
	assert( M_width > 0 );
	assert( M_height > 0 );
	
	/* start at upper left corner */
	int max = M_width * M_height;
	int cell = RANDINT( M_growthRate );
	int sprout = 0;
	
	while( cell < max ) {
		/* this point has plants */
		if( M_field[cell] ) {
			 /* plants are not yet full grown */
			 if( M_field[cell] < 255 ) M_field[cell] ++;
			 /* plant is adult (>64) */
			 if( M_field[cell] > 64 ) {
				/* sprout once every M_sproutRate */
				if( M_sproutCounter == M_sproutRate ) {
				 	/* sprout in adjacent cell*/
					sprout = cell + (RANDINT( 3 ) - 1)*M_width + RANDINT( 3 ) - 1;
					/* spot is inside field and empty */
					if( sprout < max && M_field[sprout] == 0 ) {
						/* new plant growth at spot */
						M_field[sprout] = 1;
						}
					}
				else if( M_sproutCounter <= M_sproutRate ) M_sproutCounter++;
				else assert( 0 );
				}
			}
				
		
		/* move on */
		cell += RANDINT( M_growthRate );
		}
	}

int Field::in( int x, int y ) {
	assert( M_field );
	assert( M_width > 0 );
	assert( M_height > 0 );
	
	/* coordinates are outside of field */
	if( x < 0 || x >= M_width || y < 0 || y >= M_height ) return 0;
	/* inside */
	else return 1;
	}

int Field::look( int x, int y ) {
	assert( M_field );
	assert( M_width > 0 );
	assert( M_height > 0 );
	
	/* coordinates are outside of field */
	if( x < 0 || x >= M_width || y < 0 || y >= M_height ) return 128;
	/* return value of plant growth */
	return (M_field[ y*M_width + x] + 15)>> 4; /* to keep inside 0-15 */
	}

int Field::randX() { return RANDINT( M_width ); }
int Field::randY() { return RANDINT( M_height ); }

void Field::update() {
	/* time passes */
	M_date++;
	
	/* grow the food */
	growFood();
	}
