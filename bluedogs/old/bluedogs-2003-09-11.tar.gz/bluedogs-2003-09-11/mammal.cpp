/*
critter.cc

Copyright (C) 2003
Michael Leonhard
http://tamale.net/
*/

#include <assert.h>
#include <SDL.h>
#include <stdlib.h>

#include "bluedogs.hpp"

#define NEWBORNENERGY 64
#define CHILDBIRTHENERGY 64
#define MATINGENERGY 32

#define MALE 0
#define FEMALE 1

void Mammal::draw( Display& display ) {
	SDL_Rect& rect = M_field->cellRect( getX(), getY() );
	rect.x += rect.w / 4;
	rect.y += rect.h / 4;
	rect.w /= 2;
	rect.h /= 2;
	if( M_gender == 0 ) display.drawCell( rect, M_energy >> 4, M_energy >> 4, M_energy, M_direction );
	else display.drawCell( rect, M_energy, M_energy >> 4, M_energy >> 4, M_direction );
	}

unsigned char* Mammal::getEgg() {
	assert( M_gender == FEMALE );
	return M_genotype;
	}

int Mammal::getEggLength() {
	assert( M_gender == FEMALE );
	return M_genotypeLength / 2;
	}
int Mammal::getGender() { return M_gender; }
int Mammal::getPartnerId() { return M_partner; }

unsigned char* Mammal::getSperm() {
	assert( M_gender == MALE );
	return M_genotype + (M_genotypeLength / 2);
	}

int Mammal::getSpermLength() {
	assert( M_gender == MALE );
	return M_genotypeLength / 2;
	}

Mammal::Mammal( Field& field, int genotypeLength, int initialEnergy )
	: Critter( field, genotypeLength, initialEnergy ) {
	
	M_gender = RANDINT( 2 );
	M_partner = 0;
	}

Mammal::Mammal( Field& field, int x, int y, int initialEnergy, Mammal& mother, Mammal& father )
	: Critter() {
	unsigned char *egg, *sperm;
	int i, eggLength, spermLength;
	
	assert( field.in( x, y ) );
	assert( initialEnergy );
	
	/* initialize environment */
	M_field = &field;
	
	/* initialize metadata */
	M_id = 0;/* id is assigned by Population */
	M_birth = field.getDate();
	M_generation = 1 + (mother.getGeneration() > father.getGeneration())? mother.getGeneration() : father.getGeneration();
	
	eggLength = mother.getEggLength();
	spermLength = father.getSpermLength();
	
	/* initialize VM variables */
	M_p = 0;
	M_genotypeLength = eggLength + spermLength;
	M_wait = 0;
	M_result = 0;
	M_A = 0;
	M_B = 0;
	M_C = 0;
	
	/* allocate genotype */
	M_genotype = new unsigned char[M_genotypeLength];
	assert( M_genotype );
	
	/* copy egg genes first */
	egg = mother.getEgg();
	assert( egg );
	assert( eggLength );
	for( i = 0; i < eggLength; i++ ) M_genotype[i] = egg[i];
	
	/* copy sperm genes after egg */
	sperm = father.getSperm();
	assert( sperm );
	assert( spermLength );
	for( i = 0; i < spermLength; i++ ) {
		assert( i + eggLength < M_genotypeLength );
		M_genotype[i + eggLength] = sperm[i];
		}
	
	/* initialize characteristics */
	move( x, y );
	M_direction = mother.getDirection();/* newborn comes out headfirst (facing father) */
	M_energy = initialEnergy;
	M_gender = RANDINT( 2 );
	M_partner = 0;
	}

void Mammal::mate( Mammal& partner ) {
	/* potential mating partner */
	M_partner = partner.getId();
	
	/*printf( "." ); fflush( stdout );/**/
	
	/* mating must be mutual */
	if( partner.getPartnerId() != M_id ) {
		/*M_wait += 15;/**/
		return;
		}
	
	/*printf( "+" ); fflush( stdout );/**/
	
	/* this is male object */
	if( M_gender == 0 ) {
		/* perform breeding in female object */
		partner.mate( *this );
		return;
		}
	
	/* this is female object */
	assert( M_gender == 1 );
	
	/* current position */
	int x = getX(), y = getY();
	
	/* behind position */
	switch( M_direction ) {
		case EAST: x--; break;
		case NORTH: y++; break;
		case WEST: x++; break;
		case SOUTH: y--; break;
		}
	
	/* back to field wall */
	if( !M_field->in( x, y ) ) return;
	
	/* newborn's position */
	int cx = getX(), cy = getY();
	
	/* move mother backward */
	move( x, y );
	
	/* conception */
	orgasm();
	partner.orgasm();
	Mammal* child;
	child = new Mammal( *M_field, cx, cy, NEWBORNENERGY, *this, partner );
	/*printf( "CHILD%d ", child );/**/
	
	/* birth */
	M_energy -= CHILDBIRTHENERGY;
	child->joinQuad( getQuad() );
	
	printf( "MATE(%d,%d)->%d(%d) ", M_id, partner.getId(), child->getId(), child->getGeneration() );
	
/*	partner.printGenotype();
	partner.printState();
	printGenotype();
	printState();
	child->printGenotype();
	child->printState();/**/
	}

void Mammal::orgasm() {
	M_energy -= MATINGENERGY;
	M_result = 1;
	}

void Mammal::reproduce( int reg ) {
	/*printf( "Mammal::reproduce(%d) ", reg );/**/
	/* sanity checks */
	assert( M_field );
	assert( M_field->in( getX(), getY() ) );
	assert( M_direction >= 0 && M_direction < 4 );
	assert( M_energy && M_energy <= MAXENERGY );
	assert( M_gender == MALE || M_gender == FEMALE );
	assert( M_id );
	assert( M_birth );
	assert( M_generation >= 0 );
	assert( M_p >= 0 );
	assert( M_genotypeLength );
	assert( M_p < M_genotypeLength );
	assert( M_genotype );
	
	assert( reg >= 0 && reg < 16 );
	
	/*M_partner = 0;/**/
	
	int x, y;
	Mammal* partner;
	
	/* current position */
	x = getX();
	y = getY();

	/* forward position */
	switch( M_direction ) {
		case EAST: x++; return;
		case NORTH: y--; return;
		case WEST: x--; return;
		case SOUTH: y++; return;
		}
	
	/* default result */
	M_result = 0;
	
	/* facing field wall */
	if( !M_field->in( x, y ) ) return;
	
	/* potential partner */
	partner = (Mammal *)location( x, y );
	
	/* no partner */
	if( !partner ) return;
	
	/* partner is wrong gender */
	if( partner->getGender() + M_gender != 1 ) return;
	
	/* attempt mating */
	partner->mate( *this );
	}
