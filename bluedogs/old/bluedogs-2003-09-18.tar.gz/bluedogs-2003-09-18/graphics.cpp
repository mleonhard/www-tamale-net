/*
graphics.cpp

Copyright (C) 2003
Michael Leonhard
http://tamale.net/
*/

#include <assert.h>
#include <malloc.h>
#include <stdio.h>
#include <string.h>
#include <SDL.h>
#include <SDL_image.h>

#include "graphics.hpp"

#define FONT "white8x17.png"

void Display::addWidget( Displayable* widget ) {
	assert( widget );
	assert( M_widgetList );
	assert( M_numWidgets < M_widgetListLength );
	
	int i;
	
	/* make sure that the widget isn't already in the list */
	for( i = 0; i < M_widgetListLength; i++ ) {
		if( M_widgetList[i] == widget ) {
			assert( 0 ); /* widget cannot be added to a that list it is already in */
			return; /* non-debug builds will ignore this problem */
			}
		}
	
	/* no extra spaces in list */
	if( M_numWidgets + 1 == M_widgetListLength ) {
		/* make a bigger list */
		int newListLength = M_widgetListLength + 8;
		Displayable** newList = (Displayable* *)malloc( sizeof( Displayable* ) * newListLength );
		assert( newList );
		
		/* copy the entries from the old list */
		for( i = 0; i < M_numWidgets; i++ ) newList[i] = M_widgetList[i];
		
		/* zero the empty spaces */
		for( ; i < newListLength; i++ ) newList[i] = NULL;
		
		/* switch to new list */
		delete M_widgetList;
		M_widgetList = newList;
		M_widgetListLength = newListLength;
		}
	
	/* save widget as next entry in list */
	assert( M_widgetList[M_numWidgets] == NULL );
	M_widgetList[M_numWidgets] = widget;
	M_numWidgets++;
	}

void Display::dispatch( SDL_Event& event, int x, int y ) {
	/* walk through list from last to first */
	for( int i = M_numWidgets - 1; i > -1; i-- ) {
		assert( M_widgetList[i] );
		/* coordinates lie in the widget's region */
		if( M_widgetList[i]->in( x, y ) ) {
			/* dispatch the event to the widget */
			M_widgetList[i]->event( event, *this );
			return;
			}
		}
	}

void Display::dispatch( SDL_Event& event ) {
	/* handle each type of event */
	switch( event.type ) {
		/* user closed the window */
		case SDL_QUIT: throw DisplayQuit();
		
		/* key events go to focused widget */
		case SDL_KEYDOWN:
		case SDL_KEYUP:
			if( M_focusedWidget ) M_focusedWidget->event( event, *this );
			break;
		/* mouse events go to the widget under the mouse pointer */
		case SDL_MOUSEBUTTONDOWN:
		case SDL_MOUSEBUTTONUP:
			dispatch( event, ((SDL_MouseButtonEvent *)&event)->x, ((SDL_MouseButtonEvent *)&event)->y );
			break;
		case SDL_MOUSEMOTION:
			dispatch( event, ((SDL_MouseMotionEvent *)&event)->x, ((SDL_MouseMotionEvent *)&event)->y );
			break;
		}
	}

Display::Display( int width, int height, int depth, const char* caption ) {
	
	assert( width );
	assert( height );
	assert( depth );
	assert( caption );
	
	/* initialize SDL */
	if( SDL_Init( SDL_INIT_VIDEO ) < 0 ) {
		fprintf(stderr, "Couldn't initialize SDL: %s\n",SDL_GetError());
		throw DisplayInitFailure();
		}
	
	/* Set window caption */
	SDL_WM_SetCaption( caption, caption );
	
	/* set the video mode */
	M_surface = SDL_SetVideoMode( width, height, depth, SDL_SWSURFACE );
	if( M_surface == NULL ) {
		fprintf( stderr,"Couldn't set video mode: %s\n", SDL_GetError() );
		SDL_Quit();
		throw DisplayVideoModeFailure();
		}
	
	/* initalize widget list */
	M_widgetListLength = 8;
	M_widgetList = (Displayable* *)malloc( sizeof( Displayable* ) * M_widgetListLength );
	assert( M_widgetList );
	for( int i = 0; i < M_widgetListLength; i++ ) M_widgetList[i] = NULL;
	M_numWidgets = 0;
	
	/* initially there is no focused widget */
	M_focusedWidget = NULL;
	}

Display::~Display() {
	/* free the widget list memory */
	delete M_widgetList;
	M_widgetList = NULL;
	M_widgetListLength = 0;
	M_numWidgets = 0;
	
	/* shut down SDL */
	SDL_Quit();
	}

void Display::draw() {
	assert( M_widgetList );
	assert( M_widgetListLength );
	assert( M_numWidgets < M_widgetListLength );
	
	/* each widget */
	for( int i = 0; i < M_numWidgets; i++ ) {
		assert( M_widgetList[i] );
		/* draw the widget */
		M_widgetList[i]->draw( M_surface );
		}
	
	/* update the screen */
	int ret = SDL_Flip( M_surface );
	if( ret == -1 ) {
		fprintf( stderr, "SDL_Flip failed: %s\n",SDL_GetError() );
		throw DisplayError();
		}
	}

void Display::setFocus( Displayable* widget ) {
	assert( widget );
	M_focusedWidget = widget;
	}

void Display::updateRegion( SDL_Rect &rect) {
	/* update the region on the screen */
	SDL_UpdateRect( M_surface, rect.x, rect.y, rect.w, rect.h );
	}

Background::Background( int red, int green, int blue ) {
	setColor( red, green, blue );
	}

void Background::draw( SDL_Surface *screen ) {
	/* fill the entire screen with color */
	SDL_FillRect( screen, NULL, SDL_MapRGB( screen->format, M_red, M_green, M_blue ) );
	}

void Background::setColor( int red, int green, int blue ) {
	assert( red && green && blue );
	M_red = red;
	M_green = green;
	M_blue = blue;
	}


Rectangle::Rectangle( int left, int right, int top, int bottom, int red, int green, int blue )
	 : Background::Background( red, green, blue ) {
	move( left, right, top, bottom );
	}

void Rectangle::draw( SDL_Surface* screen ) {
	/* draw the rectangle on the screen */
	SDL_FillRect( screen, &M_rect, SDL_MapRGB( screen->format, M_red, M_green, M_blue ) );
	}

void Rectangle::move( int left, int right, int top, int bottom ) {
	assert( left );
	assert( top );
	assert( left < right );
	assert( top < bottom );
	
	M_rect.x = left;
	M_rect.y = top;
	M_rect.w = right - left;
	M_rect.h = bottom - top;
	}

Text::Text( int left, int top, const char* text ) {
	/* load the font */
	SDL_Surface* image;
	image = IMG_Load( FONT );
	if( image == NULL ) {
		fprintf( stderr,"Couldn't load image, %s: %s\n", FONT, SDL_GetError() );
		throw TextInitFailure();
		return;
		}
	/* optimize for transparencies */
	M_font = SDL_DisplayFormatAlpha( image );
	assert( M_font );
	/* delete unoptimized image */
	SDL_FreeSurface( image );
	
	/* width of one character */
	M_charWidth = M_font->w / 129;
	
	/* dimensions */
	M_rect.x = left;
	M_rect.y = top;
	M_rect.w = 0; /* width will be calculated by setText() */
	M_rect.h = M_font->h;
	
	/* text */
	M_text = NULL;
	setText( text );
	}

void Text::move( int left, int top ) {
	M_rect.x = left;
	M_rect.y = top;
	}

void Text::setText( const char* newText ) {
	assert( newText );
	int newTextLen = strlen( newText );
	
	/* no existing string */
	if( M_text == NULL ) {
		/* allocate memory for new string */
		M_text = (char *)malloc( sizeof( char ) * newTextLen );
		assert( M_text );
		}
	/* existing string is too small */
	else if( strlen( M_text ) < newTextLen ) {
		/* free the existing string */
		free( M_text );
		/* allocate memory for new string (and NULL terminator) */
		M_text = (char *)malloc( sizeof( char ) * (newTextLen + 1) );
		assert( M_text );
		}
	
	/* copy the string (including NULL terminator) */
	strncpy( M_text, newText, newTextLen + 1 );
	
	/* recalculate text width */
	M_rect.w = M_charWidth * newTextLen;
	}

#define CHARACTERS "???????????????????? !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJLKMNOPQRSTUVWXYZ[\]^_`abcdefghijlmnopqrstuvwxyz{|}~?"
void Text::draw( SDL_Surface* screen ) {
	SDL_Rect srcrect, dstrect;
	
	assert( screen );
	assert( M_text );
	assert( M_font );
	dstrect.x = M_rect.x;
	dstrect.y = M_rect.y;
	srcrect.y = 0;
	srcrect.w = M_charWidth;
	srcrect.h = M_font->h;
	
	/* draw each digit */
	char* digit = M_text;
	while( *digit ) {
		srcrect.x = (*digit) * M_charWidth;
		SDL_BlitSurface( M_font, &srcrect, screen, &dstrect );
		dstrect.x += M_charWidth;
		digit++;
		};
	}
