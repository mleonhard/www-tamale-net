/*
graphicstest.cpp

Copyright (C) 2003
Michael Leonhard
http://tamale.net/
*/

#include <assert.h>
#include <stdio.h>

#include "graphics.hpp"

int main( int argc, char *argv[] ) {
	/* catch exceptions */
	try {
		/* initialize */		
		Display display( 640, 480, 16, "Graphics Test" );
		display.addWidget( new Background( 0x40, 0x80, 0xB0 ) );
		display.addWidget( new Rectangle( 10, 120, 10, 130, 0xFF, 0xFF, 0x80 ) );
		display.addWidget( new Text( 200, 200, "ABCDEF G" ) );
		/* run */
		SDL_Event event;
		int ret;
		while( 1 ) {
			/* dispatch all messages on event queue */
			while( SDL_PollEvent( &event ) ) display.dispatch( event );
			
			/* draw the screen */
			display.draw();
			
			/* wait for 1/30 of a second */
			SDL_Delay( 33 ); /* <30 fps */
			}
		}
	
	/* graphics system failed to initialize */
	catch (DisplayInitFailure) { return 1; }
	/* video mode unavailable */
	catch (DisplayVideoModeFailure) { return 1; }
	/* normal exit */
	catch (DisplayQuit) { return 0; }
	
	/* program should never reach here */
	assert( 0 );
	return 0;
	}
