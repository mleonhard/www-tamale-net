/*
graphics.cpp

Copyright (C) 2003
Michael Leonhard
http://tamale.net/
*/

#include <assert.h>
#include <malloc.h>
#include <stdio.h>
#include <SDL.h>
#include <SDL_image.h>

#include "graphics.hpp"

#define NUMBERS "numbers.png"

void Display::addWidget( Displayable* widget ) {
	assert( widget );
	assert( M_widgetList );
	assert( M_numWidgets < M_widgetListLength );
	
	int i;
	
	/* make sure that the widget isn't already in the list */
	for( i = 0; i < M_widgetListLength; i++ ) {
		if( M_widgetList[i] == widget ) {
			assert( 0 ); /* widget cannot be added to a that list it is already in */
			return; /* non-debug builds will ignore this problem */
			}
		}
	
	/* no extra spaces in list */
	if( M_numWidgets + 1 == M_widgetListLength ) {
		/* make a bigger list */
		int newListLength = M_widgetListLength + 8;
		Displayable** newList = (Displayable* *)malloc( sizeof( Displayable* ) * newListLength );
		assert( newList );
		
		/* copy the entries from the old list */
		for( i = 0; i < M_numWidgets; i++ ) newList[i] = M_widgetList[i];
		
		/* zero the empty spaces */
		for( ; i < newListLength; i++ ) newList[i] = NULL;
		
		/* switch to new list */
		delete M_widgetList;
		M_widgetList = newList;
		M_widgetListLength = newListLength;
		}
	
	/* save widget as next entry in list */
	assert( M_widgetList[M_numWidgets] == NULL );
	M_widgetList[M_numWidgets] = widget;
	M_numWidgets++;
	}

Display::Display( int width, int height, int depth, const char* caption ) {
	
	assert( width );
	assert( height );
	assert( depth );
	assert( caption );
	
	/* initialize SDL */
	if( SDL_Init( SDL_INIT_VIDEO ) < 0 ) {
		fprintf(stderr, "Couldn't initialize SDL: %s\n",SDL_GetError());
		throw DisplayInitFailure();
		}
	
	/* Set window caption */
	SDL_WM_SetCaption( caption, caption );
	
	/* set the video mode */
	M_surface = SDL_SetVideoMode( width, height, depth, SDL_SWSURFACE );
	if( M_surface == NULL ) {
		fprintf( stderr,"Couldn't set video mode: %s\n", SDL_GetError() );
		SDL_Quit();
		throw DisplayVideoModeFailure();
		}
	
	/* initalize widget list */
	M_widgetListLength = 8;
	M_widgetList = (Displayable* *)malloc( sizeof( Displayable* ) * M_widgetListLength );
	assert( M_widgetList );
	for( int i = 0; i < M_widgetListLength; i++ ) M_widgetList[i] = NULL;
	M_numWidgets = 0;
	}

Display::~Display() {
	/* free the widget list memory */
	delete M_widgetList;
	M_widgetList = NULL;
	M_widgetListLength = 0;
	M_numWidgets = 0;
	
	/* shut down SDL */
	SDL_Quit();
	}

void Display::draw() {
	assert( M_widgetList );
	assert( M_widgetListLength );
	assert( M_numWidgets < M_widgetListLength );
	
	/* each widget */
	for( int i = 0; i < M_numWidgets; i++ ) {
		assert( M_widgetList[i] );
		/* draw the widget */
		M_widgetList[i]->draw( M_surface );
		}
	
	/* update the screen */
	int ret = SDL_Flip( M_surface );
	if( ret == -1 ) {
		fprintf( stderr, "SDL_Flip failed: %s\n",SDL_GetError() );
		throw DisplayError();
		}
	}

void Display::updateRegion( SDL_Rect &rect) {
	/* update the region on the screen */
	SDL_UpdateRect( M_surface, rect.x, rect.y, rect.w, rect.h );
	}

Background::Background( int red, int green, int blue ) {
	assert( red && green && blue );
	
	M_red = red;
	M_green = green;
	M_blue = blue;
	}

void Background::draw( SDL_Surface *screen ) {
	
	}
