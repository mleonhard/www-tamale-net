/*
bluedogs.hh

Copyright (C) 2003
Michael Leonhard
http://tamale.net/
*/

#ifndef TREES_HH

/* class declarations */
class ListNode;
class QuadNode;

class ListNode {
	friend class QuadNode;
	private:
		ListNode * M_next, * M_prev;
		QuadNode *M_quadTree;
		ListNode* getPrev();
		void verifyBackward();
		void verifyForward();
		void setNext( ListNode* next );
		void setPrev( ListNode* prev );
	protected:
		int M_x, M_y;
		QuadNode* getQuad();
		ListNode* location( int x, int y );
		void move( int x, int y );
	public:
		void joinQuad( QuadNode *quadTree );
		ListNode();
		ListNode( int x, int y );
		ListNode* getNext();
		virtual ~ListNode() {};
		int getX();
		int getY();
		void linkNext( ListNode* next );
		void linkPrev( ListNode* prev );
		virtual bool persist();
		void unlink();
		void verify();
	};

class QuadNode {
	private:
		/* list of ListNode items (will be NULL for branch nodes) */
		ListNode* M_itemList;
		/* edges of region */
		int M_left, M_right, M_top, M_bottom, M_centerX, M_centerY;
		
		void initialize( int left, int right, int top, int bottom );
	protected:
		/* number of ListNode items in this node or all sub-nodes */
		int M_itemCount;
		
		/* M_parent will be null for root */
		QuadNode* M_parent;
		void decrementCount();
		void incrementCount();

		/* sub nodes (will be NULL for leaf node) */
		QuadNode * M_i, * M_ii, * M_iii, * M_iv;

		
		int in( int x, int y );
		QuadNode* leafNode( int x, int y );
		void split();
	public:
		virtual void add( ListNode* item );
		void cleanup();
		QuadNode* getI();
		QuadNode* getII();
		QuadNode* getIII();
		QuadNode* getIV();
		int getItemCount();
		ListNode* getList();
		ListNode* location( int x, int y );
		QuadNode( int left, int right, int top, int bottom );
		QuadNode( QuadNode* parent, int left, int right, int top, int bottom );
		void relocate( ListNode* item, int oldx, int oldy );
		virtual void remove( ListNode* item );
		void verify();
	};


#define TREES_HH
#endif
