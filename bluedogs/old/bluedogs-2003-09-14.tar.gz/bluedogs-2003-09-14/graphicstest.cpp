/*
graphicstest.cpp

Copyright (C) 2003
Michael Leonhard
http://tamale.net/
*/

#include <assert.h>
#include <stdio.h>

#include "graphics.hpp"

int main( int argc, char *argv[] ) {
	/* initialize */
	try {
		Display display( 640, 480, 16, "Graphics Test" );
		/* seed the random number generator */
		
		/* run */
		while( 1 ) {
			SDL_Delay( 33 ); /* <30 fps */
			}
		}
	
	/* graphics system failed to initialize */
	catch (DisplayInitFailure) { return 1; }
	/* video mode unavailable */
	catch (DisplayVideoModeFailure) { return 1; }
	/* normal exit */
	catch (DisplayQuit) { return 0; }
	
	/* program should never reach here */
	assert( 0 );
	return 0;
	}
