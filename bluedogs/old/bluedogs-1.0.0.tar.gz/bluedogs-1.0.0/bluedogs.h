/* bluedogs.h
 * 
 * Copyright (C) 2003-2007 Michael Leonhard
 * http://tamale.net/bluedogs
 */

#ifndef BLUEDOGS_H

#include <cassert>
#include <iomanip>
#include <iostream>
#include <SDL.h>
#include "graphics.h"

// tweakable program settings
#define SCREENW 600
#define SCREENH 400

#define FIELDW 100
#define FIELDH 75
#define INITIALFOOD (FIELDW*FIELDH*32)
#define GROWTHRATE 50
#define SPROUTRATE 4

#define MINIMUMCRITTERS 50
#define GENOTYPELENGTH 256
#define INITIALENERGY 64
#define MAXENERGY 255 // Because energy is an 8-bit register
#define THINKCYCLES 32
#define FOODPOTENCY 4

// macros
#define RANDINT(n) ((int)((float)(n) * rand() / (RAND_MAX + 1.0)))

#define EAST 0
#define NORTH 1
#define WEST 2
#define SOUTH 3

// class declarations
class Bacteria;
class Critter;
class Display;
class RateCounter;
class CritterCounter;
class NumberDisplay;
class Sim;
class View;

class Critter
{
private:
  // disabled copy constructor
  Critter (const Critter& rhs);
  // disabled copy assignment operator
  const Critter& operator= (const Critter& rhs);
  
protected:
  Sim& M_sim;
  int M_x, M_y, M_direction, M_energy;
  int M_id, M_birthday, M_generation;
  unsigned int M_ip;
  Uint8 M_result, M_A, M_B, M_C;
  vector<Uint8> M_genotype;
  
  Critter (Sim& sim, int x, int y, int dir, int energy, int generation, vector<Uint8> genotype);
  Uint8 getReg (int reg);
  void setReg (int reg, Uint8 val);
  
public:
  //Critter ();
  Critter (Sim& sim, int genotypeLength, int energy);
  ~Critter ();
  int getAge ();
  virtual Uint8 getAppearance ();
  int getDirection ();
  int getEnergy ();
  int getGeneration ();
  int getId ();
  int getX ();
  int getY ();
  void printGenotype ();
  void printState ();
  virtual void reproduce (int reg);
  void setId (int id);
  void setPosition (int x, int y);
  void think ();
  void update ();
};

class Bacteria : public Critter
{
private:
  // disabled copy constructor
  Bacteria (const Bacteria& rhs);
  // disabled copy assignment operator
  const Bacteria& operator= (const Bacteria& rhs);
  
public:
  Bacteria (Sim& sim, int genotypeLength, int energy);
  Bacteria (Sim& sim, int x, int y, int dir, int energy, int generation, vector<Uint8> genotype);
  void reproduce (int reg);
};

class Sim
{
private:
  int M_idCount, M_maxAge, M_critterCount;
  int M_width, M_height;
  int M_date, M_growthRate, M_sproutRate, M_sproutCounter;
  Uint8* M_food;
  Critter** M_critter;
  // disabled copy constructor
  Sim (const Sim& rhs);
  // disabled copy assignment operator
  const Sim& operator= (const Sim& rhs);

public:
  void add (Critter* critter);
  void addFood (int amount);
  void foodEaten (int x, int y);
  Critter* getCritter (int x, int y);
  int getCritterCount ();
  int getDate ();
  Uint8 getFood (int x, int y);
  int getHeight ();
  int getWidth ();
  void growFood ();
  bool in (int x, int y);
  int look (int x, int y);
  bool moveCritter (Critter* critter, int newX, int newY);
  void printGenotypes ();
  int randX ();
  int randY ();
  void remove (Critter* criter);
  Sim (int width, int height, int food, int growthRate, int sproutRate);
  ~Sim ();
  void update ();
  void verify ();
};

class View : public Displayable
{
private:
  Sim& M_sim;
  int M_cellWidth, M_cellHeight;
  Uint32 M_greenColor[256], M_bodyColor[256], M_headColor[256];
  
  // disabled copy constructor
  View (const View& rhs);
  // disabled copy assignment operator
  const View& operator= (const View& rhs);
  
  void drawCritter (SDL_Surface* surface, int x, int y, int energy, int dir);
  
public:
  SDL_Rect const* draw (SDL_Surface* surface);
  void optimize (SDL_Surface* surface);
  View (Sim& sim);
};

#define BLUEDOGS_H
#endif
