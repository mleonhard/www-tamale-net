/* sim.cpp - Sim class holds field and critters, performs simulation
 * 
 * Copyright (C) 2003-2007 Michael Leonhard
 * http://tamale.net/bluedogs
 */

#include <iostream>
#include "bluedogs.h"

#define CRITTER(x, y) M_critter[y*M_width + x]
#define FOOD(x, y) M_food[y*M_width + x]
#define IN_FIELD(x, y) (x >= 0 && x < M_width && y >= 0 && y < M_height)

/* add - adds the critter to the simulation
 * @param critter the critter object to add
 */
void Sim::add (Critter* critter)
{
  assert (critter);
  
  // ID
  critter->setId (M_idCount++);
  
  // position
  int x = critter->getX ();
  int y = critter->getY ();
  // assign random position
  if (-1 == x && -1 == y)
    {
      do {
	x = randX();
	y = randY();
      } while (getCritter (x, y));
      assert (IN_FIELD (x, y));
      critter->setPosition (x, y);
    }
  assert (IN_FIELD (x, y));
  assert (NULL == getCritter (x, y));
  CRITTER (x, y) = critter;
  
  // count
  M_critterCount++;
}

/* addFood - distributes food randomly throughout the field
 * @param amount the amount of food to distribute, must be > 0
 */
void Sim::addFood (int amount)
{
  int x, y;
  assert (amount > 0);
  assert (M_food);
  assert (M_width > 0);
  assert (M_height > 0);
  
  // for the whole amount specified
  for(; amount > 0; amount--)
    {
      // position of new food growth
      x = randX();
      y = randY();
      assert (IN_FIELD (x, y));
      
      // this point not yet full grown
      if (FOOD (x, y) < 255)
	{
	  // grow the food
	  FOOD (x, y) ++;
	}
    }
}

/*
int Sim::food (int x, int y)
{
  assert (M_food);
  assert (M_width > 0);
  assert (M_height > 0);
  
  // coordinates are outside of field
  if (x < 0 || x >= M_width || y < 0 || y >= M_height)
    {
      return 128;
    }
  // return value of plant growth
  return (FOOD (x, y) + 15)>> 4; // to keep inside 0-15
}
*/

/* foodEaten - causes food to shrink when it has been eaten
 * @param x the x-coordinate of the cell where food was eaten
 * @param y the y-coordinate of the cell where food was eaten
 */
void Sim::foodEaten (int x, int y)
{
  assert (IN_FIELD (x, y));
  assert (FOOD (x, y));
  FOOD (x, y) --;
};

/* getCritter - looks up the critter at a specified point
 * @param x the x-coordinate, must be inside the field
 * @param y the y-coordinate, must be inside the field
 * @return a pointer to the critter at that spot, or NULL if there is none
 */
Critter* Sim::getCritter (int x, int y)
{
  assert (M_critter);
  assert (M_width > 0);
  assert (M_height > 0);
  assert (x >= 0);
  assert (x < M_width);
  assert (y >= 0);
  assert (y < M_height);
  return CRITTER (x, y);
}

/* accessor
 * @return the number of critters present in the sim
 */
int Sim::getCritterCount ()
{
  return M_critterCount;
};

/* accessor
 * @return the current date in the sim
 */
int Sim::getDate()
{
  return M_date;
}

/* getFood - gets the amount of food at the location
 * @param x the x-coordinate to sample
 * @param y the y-coordinate to sample
 * @return the amount of food in the cell, 0 = no food, 255 = max food
 */
Uint8 Sim::getFood (int x, int y)
{
  assert (M_food);
  assert (M_width > 0);
  assert (M_height > 0);
  assert (x >= 0);
  assert (x < M_width);
  assert (y >= 0);
  assert (y < M_height);
  return FOOD (x, y);
}

/* accessor
 * @return the height of the simulation field, in cells
 */
int Sim::getHeight ()
{
  return M_height;
};

/* accessor
 * @return the width of the simulation field, in cells
 */
int Sim::getWidth ()
{
  return M_width;
}

/* growFood - performs growth and seeding of food plants
 */
void Sim::growFood()
{
  assert (M_food);
  assert (M_width > 0);
  assert (M_height > 0);
  assert (M_sproutRate > 0);
  
  // start at upper left corner
  int max = M_width * M_height;
  int cell = RANDINT (M_growthRate);
  while (cell < max)
    {
      // this cell has a plant
      if (M_food[cell])
	{
	  // plant is not yet full grown
	  if (M_food[cell] < 255)
	    {
	      M_food[cell] ++;
	    }
	  // plant is adult (>64) and time to sprout
	  if (M_food[cell] > 64 && M_sproutCounter > M_sproutRate)
	    {
	      // sprout in adjacent cell*/
	      int dx = RANDINT (3) - 1;
	      int dy = RANDINT (3) - 1;
	      int s = cell + dy*M_width + dx;
	      // spot is inside field and empty
	      if (s >= 0 && s < max && M_food[s] == 0)
		{
		  // new plant growth at spot
		  M_food[s] = 1;
		}
	      // reset counter
	      M_sproutCounter = 0;
	    }
	  M_sproutCounter++;
	}
      // move on
      cell += RANDINT (M_growthRate);
    }
}

/* in - tests if the specified coordinates are inside the sim field
 * @param x the x-coordinate to test
 * @param y the y-coordinate to test
 * @return true if (x,y) lies inside the field, otherwise false
 */
bool Sim::in (int x, int y)
{
  assert (M_width > 0);
  assert (M_height > 0);
  return IN_FIELD (x, y);
}

/* look - looks at the specified cell
 * @param x the x-coordinate of the cell
 * @param y the y-coordinate of the cell
 * @return the value that a critter sees when looking at the cell
 */
int Sim::look (int x, int y)
{
  assert (M_food);
  assert (M_width > 0);
  assert (M_height > 0);
  
  // outside of field
  if (!IN_FIELD(x, y))
    {
      return 128;
    }
  
  // another critter
  Critter* critter = CRITTER (x, y);
  if (critter)
    {
      return critter->getAppearance();
    }
  
  // food
  int f = FOOD (x, y);
  return (f + 15)>> 4; // range 0..15
}

/* moveCritter - tries to move the specified critter to the new location
 * @param critter the critter to move
 * @param newx the new x-coordinate of the critter
 * @param newy the new y-coordinate of the critter
 * @return true if the critter was moved, otherwise false
 */
bool Sim::moveCritter (Critter* critter, int newx, int newy)
{
  assert (critter);
  int oldx = critter->getX ();
  int oldy = critter->getY ();
  assert (IN_FIELD (oldx, oldy));
  assert (CRITTER (oldx, oldy) == critter);
  
  if (!IN_FIELD (newx, newy) || CRITTER (newx, newy))
    {
      return false;
    }
  
  CRITTER (oldx, oldy) = NULL;
  critter->setPosition (newx, newy);
  CRITTER (newx, newy) = critter;
  return true;
}

/* printGenotypes - prints out the genotypes of every critter in the sim
 */
void Sim::printGenotypes()
{
  for (int y = 0; y < M_height; y++)
    {
      for (int x = 0; x < M_width; x++)
	{
	  if (CRITTER (x, y))
	    {
	      CRITTER (x, y) ->printGenotype();
	    }
	}
    }
}

/* randX - get a random x-coordinate in the field
 * @return a random x-coordinate in the field
 */
int Sim::randX()
{
  return RANDINT (M_width);
};

/* randY - get a random y-coordinate in the field
 * @return a random y-coordinate in the field
 */
int Sim::randY()
{
  return RANDINT (M_height);
};

/* remove - removes the specified critter from the simulation
 * @param critter the critter to remove
 */
void Sim::remove (Critter* critter)
{
  assert (critter);
  assert (critter->getId());
  assert (critter->getId() < M_idCount);
  int x = critter->getX ();
  int y = critter->getY ();
  assert (IN_FIELD (x, y));
  assert (CRITTER (x, y) == critter);
  CRITTER (x, y) = NULL;
  assert (M_critterCount >= 0);
  M_critterCount--;
}

/* Constructor
 * @param width the width of the simulation field, in cells
 * @param height the height of the simulation field, in cells
 * @param food the amount of food initially present
 * @param growthRate the rate of food growth
 * @param sproutRate the rate that food propagates to neighboring cells
 */
Sim::Sim (int width, int height, int food, int growthRate, int sproutRate)
  : M_idCount (1),
    M_maxAge (0),
    M_critterCount (0),
    M_width (width),
    M_height (height),
    M_date (1),
    M_growthRate (growthRate),
    M_sproutRate (sproutRate),
    M_sproutCounter (0),
    M_food (NULL),
    M_critter (NULL)
{
  assert (width);
  assert (height);
  assert (food);
  assert (growthRate >= 0);
  assert (sproutRate >= 0);
  
  // food
  M_food = (Uint8*) malloc (M_width * M_height * sizeof (Uint8));
  assert (M_food);
  for (int i = 0; i < width * height; i++)
    {
      M_food[i] = 0;
    }
  addFood (food);
  
  // critters
  M_critter = (Critter**) malloc (sizeof (Critter*) * width * height);
  assert (M_critter);
  for (int i = 0; i < width * height; i++)
    {
      M_critter[i] = NULL;
    }
}

/* Destructor - deletes all critter objects
 */
Sim::~Sim()
{
  Critter* critter;
  for (int y = 0; y < M_height; y++)
    {
      for (int x = 0; x < M_width; x++)
	{
	  critter = CRITTER (x, y);
	  if (critter)
	    {
	      assert (critter->getId());
	      assert (critter->getId() < M_idCount);
	      assert (critter->getX () == x);
	      assert (critter->getY () == y);
	      assert (critter->getEnergy ());
	      
	      remove (critter);
	      delete critter;
	    }
	}
    }
  assert (M_critterCount == 0);
}

/* update - updates the simulation, removing and deleting dead critters
 */
void Sim::update()
{
  M_date++;
  growFood();
  verify();
  for (int y = 0; y < M_height; y++)
    {
      for (int x = 0; x < M_width; x++)
	{
	  Critter* critter = CRITTER (x, y);
	  if (critter)
	    {
	      assert (critter->getId());
	      assert (critter->getId() < M_idCount);
	      assert (critter->getX () == x);
	      assert (critter->getY () == y);
	      
	      // critter is alive, give it a turn to think & act
	      if (critter->getEnergy())
		{
		  critter->update();
		}
	      
	      // critter is dead
	      if (!critter->getEnergy())
		{
		  remove (critter);
		  delete critter;
		}
	    }
	}
    }
  verify();
}

/* verify - checks the integrity of sim data structures
 */
void Sim::verify()
{
  int cCount = 0;
  for (int y = 0; y < M_height; y++)
    {
      for (int x = 0; x < M_width; x++)
	{
	  Critter* critter = CRITTER (x, y);
	  if (critter)
	    {
	      cCount++;
	      assert (critter->getId());
	      assert (critter->getId() < M_idCount);
	      assert (critter->getX () == x);
	      assert (critter->getY () == y);
	      assert (critter->getEnergy ());
	    }
	}
    }
  assert (cCount == M_critterCount);
}
