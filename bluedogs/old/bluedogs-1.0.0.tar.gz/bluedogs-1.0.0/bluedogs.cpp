/* bluedogs.cpp
 * 
 * Copyright (C) 2003-2007 Michael Leonhard
 * http://tamale.net/bluedogs
 */

#include "bluedogs.h"

#define USAGE "bluedogs - Copyright (C) 2003 Mike Leonhard http://tamale.net\n"

/* RateCount - shows the number of simulation iterations per second.
*/
class RateCount : public Number
{
private:
  Uint32 M_cyclesThisSecond;
  Uint32 M_nextUpdateTime;
  bool M_drawSlow;
  bool M_needDraw;
public:

  /* count_cycle - counts a simulation cycle, updates number
   */
  void count_cycle ()
  {
    Uint32 now = SDL_GetTicks();
    // time to update count
    if (now >= M_nextUpdateTime)
      {
	setNumber(M_cyclesThisSecond);
	render();
	M_nextUpdateTime = now + 1000;
	M_cyclesThisSecond = 0;
	M_needDraw = true;
      }
    M_cyclesThisSecond++;
  };
  
  /* event - process an event
   * @param event the event
   * @param display the Display object where the widget is shown
   */
  void event (SDL_Event& event, Display& display)
  {
    cout << "event!" << endl;
    switch (event.type)
      {
      case SDL_MOUSEBUTTONDOWN:
	cout << "BUTTONDOWN ";
	// toggle slow display update mode
	M_drawSlow = (M_drawSlow) ? 0 : 1;
	break;
      }
  };

  /* in_region - tests if the specified coordinates lie in the widget's area
   * @param x the x-coordinate
   * @param y the y-coordinate
   * @return true if the coordinates lie in the widget's area, otherwise false
   */
  bool in_region (int x, int y)
  {
    return (x >= M_rect.x) && (x < M_rect.x + M_rect.w)
      && (y >= M_rect.y) && (y < M_rect.y + M_rect.h);
  };

  /* is_time_to_draw - checks if it's time to update the screen
   * @return true if the screen should be updated now, otherwise false
   */
  bool is_time_to_draw ()
  {
    bool needDraw = M_needDraw;
    M_needDraw = false;
    return needDraw || (!M_drawSlow);
  }
  
  /* Constructor
   * @param left x-coordinate of the widget's left edge
   * @param top y-coordinate of the widget's top edge
   */
  RateCount (short left, short top)
    : Number (left, top, 0, "Days/sec:")
  {
    M_cyclesThisSecond = 0;
    M_nextUpdateTime = 0;
    M_drawSlow = false;
    M_needDraw = true;
  };
};

class PopulationCount : public Number
{
private:
  Sim& M_sim;
public:
  /* draw - draws the widget, displaying the number of critters in the sim
   * @param surface the surface to draw on
   * @returns the screen region that was updated
   */
  SDL_Rect const* draw (SDL_Surface* surface)
  {
    setNumber(M_sim.getCritterCount());
    return Number::draw (surface);
  };
  
  /* Constructor
   * @param sim the sim whose population is to be displayed
   * @param left x-coordinate of the widget's left edge
   * @param top y-coordinate of the widget's top edge
   */
  PopulationCount (Sim& sim, short left, short top) 
    : Number (left, top, 0, "Population:"), M_sim (sim)
  {
    setNumber (M_sim.getCritterCount());
  };
};

class DayCount : public Number
{
private:
  Sim& M_sim;
public:
  /* draw - draws the widget, displaying the current simulation date
   * @param surface the surface to draw on
   * @returns the screen region that was updated
   */
  SDL_Rect const* draw (SDL_Surface* surface)
  {
    setNumber (M_sim.getDate());
    return Number::draw (surface);
  };
  
  /* Constructor
   * @param sim the sim whose population is to be displayed
   * @param left x-coordinate of the widget's left edge
   * @param top y-coordinate of the widget's top edge
   */
  DayCount (Sim& sim, short left, short top) 
    : Number (left, top, 0, "Day:"), M_sim (sim)
  {
    setNumber (M_sim.getDate());
  };
};

int main (int argc, char *argv[])
{
  // check command line
  if (argc != 1)
    {
      cerr << USAGE << endl;
      return 1;
    }
  
  // initialize
  try {
    srand ((unsigned int)time (NULL));
    //srand ((unsigned int)1);
    
    Display display (SCREENW, SCREENH, "bluedogs");
    Sim sim (FIELDW, FIELDH, INITIALFOOD, GROWTHRATE, SPROUTRATE);
    View view (sim);
    display.addWidget (&view);
    RateCount rate (20, 20);
    display.addWidget (&rate);
    DayCount day (sim, 20, 45);
    display.addWidget (&day);
    PopulationCount pop (sim, 20, 70);
    display.addWidget (&pop);
    
    // run the simulation
    SDL_Event event;
    while (1)
      {
	// dispatch all messages on event queue
	while (SDL_PollEvent (&event))
	  {
	    display.dispatch (event);
	  }
	
	// keep the population above minimum
	for (int c = sim.getCritterCount (); c < MINIMUMCRITTERS; c++)
	  {
	    sim.add (new Bacteria (sim, GENOTYPELENGTH, INITIALENERGY));
	    // these objects will be deleted by Sim when the bacteria die
	  }
	
	// update the simulation
	sim.update ();
	rate.count_cycle ();
	if (rate.is_time_to_draw ())
	  {
	    display.draw ();
	  }
      }
  }
  
  // normal exit
  catch (DisplayQuit)
    {
      return 0;
    }
  // graphics system had an error
  catch (GraphicsError e)
    {
      e.printStdErr();
      return 1;
    }
  
  // program should never reach here
  assert (0);
  return 1;
}
