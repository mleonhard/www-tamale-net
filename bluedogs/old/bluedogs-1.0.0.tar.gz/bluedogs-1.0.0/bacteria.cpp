/* bacteria.cpp
 * 
 * Copyright (C) 2003-2007 Michael Leonhard
 * http://tamale.net/bluedogs
*/

#include "bluedogs.h"

#define MINSPLITENERGY 96
#define SPLITENERGYLOSS 32
#define RANDGENES 4

/* Constructor - creates a bacteria with random genes, random position
 * @param sim the simulation where the bacteria will live
 * @param genotypeLength the length of the bacteria's VM program
 * @param energy the amount of energy it will have
 */
Bacteria::Bacteria (Sim& sim, int genotypeLength, int energy)
  : Critter (sim, genotypeLength, energy)
{
}

/* Constructor - creates a new bacteria with the specified genes, etc.
 * @param sim the simulation where the bacteria will live
 * @param x the x-coordinate
 * @param y the y-coordinate
 * @param dir the direction it is facing
 * @param energy its initial energy
 * @param generation the number ancestors
 * @param genotype its genes
 */
Bacteria::Bacteria (Sim& sim, int x, int y, int dir, int energy, int generation, vector<Uint8> genotype)
  : Critter(sim, x, y, dir, energy, generation, genotype)
{
}

void Bacteria::reproduce (int reg)  {
  // sanity checks
  assert (M_sim.in (M_x, M_y) );
  assert (M_direction >= 0 && M_direction < 4);
  assert (M_generation >= 0);
  assert (M_ip >= 0);
  assert (M_genotype.size());
  assert (M_ip < M_genotype.size());
  assert (reg >= 0 && reg < 16);
  
  // not enough energy
  if (M_energy < MINSPLITENERGY) 
    {
      M_result = 0;
      return;
    }
  
  // child will occupy mother's old position
  int child_x = M_x;
  int child_y = M_y;
  
  // mother moves forward
  int x = M_x;
  int y = M_y;
  switch (M_direction) 
    {
    case EAST:
      x++;
      break;
    case NORTH:
      y--;
      break;
    case WEST:
      x--;
      break;
    case SOUTH:
      y++;
      break;
    }
  if (!M_sim.moveCritter (this, x, y))
    {
      // mother cannot move forward
      M_result = 0;
      return;
    }
  
  // child points in opposite direction from mother
  int child_dir = M_direction ^ 2;
  
  // child gets a copy of mother's genes, with a few randomized
  vector<Uint8> child_genes = M_genotype;
  for (int r = 0; r < RANDGENES; r++) 
    {
      int i = RANDINT (child_genes.size ());
      child_genes[i] = (Uint8) RANDINT (256);
    }
  
  // reproduction takes energy
  M_energy -= SPLITENERGYLOSS;
  int child_energy = M_energy / 2;
  M_energy /= 2;
  
  int child_generation = M_generation + 1;
  Bacteria* child = new Bacteria (M_sim, child_x, child_y, child_dir, child_energy, child_generation, child_genes);
  M_sim.add (child); // child will be deleted by Sim when dead
  
  //cout << "SPLIT " << M_id << " -> " << child->getId();
  //cout << " gen=" << child_generation << endl;
  
  // success!
  M_result = 1;
}
