/* critter.cpp
 * 
 * Copyright (C) 2003-2007 Michael Leonhard
 * http://tamale.net/bluedogs
 */

#include "bluedogs.h"

// vm registers
#define REG_RESULT    0
#define REG_A         1
#define REG_B         2
#define REG_C         3
#define REG_DIRECTION 4
#define REG_ENERGY    5
#define REG_RESERVED  6
#define REG_NW        7
#define REG_N         8
#define REG_NE        9
#define REG_W        10
#define REG_SELF     11
#define REG_E        12
#define REG_SW       13
#define REG_S        14
#define REG_SE       15

// vm instructions
#define I_SET        0
#define I_COPYA      1
#define I_COPYB      2
#define I_COPYC      3
#define I_ADD        4
#define I_SUBTRACT   5
#define I_MUL        6
#define I_DIV        7
#define I_INC        8
#define I_EQUAL      9
#define I_GREATER   10
#define I_LESS      11
#define I_JUMP      12
#define I_REPRODUCE 13
#define I_MOVE      14
#define I_EAT       15

// exceptions for program flow control
class IgnoreInstruction {};
class ActionPerformed {};

/* Constructor - creates a new critter
 * @param sim the simulation where it will live
 * @param x the x-coordinate
 * @param y the y-coordinate
 * @param dir the direction it is facing
 * @param energy its initial energy
 * @param generation the number ancestors
 * @param genotype its genes
 */
Critter::Critter (Sim& sim, int x, int y, int dir, int energy, int generation, vector<Uint8> genotype)
  : M_sim (sim),
    M_x (x),
    M_y (y),
    M_direction (dir),
    M_energy (energy),
    M_generation (generation),
    M_genotype (genotype)
{
  assert (M_sim.in (M_x, M_y) );
  assert (M_direction >= 0 && M_direction < 4);
  assert (M_generation >= 0);
  assert (energy >= 0);
  assert (genotype.size());
  
  M_id = -1;
  M_birthday = M_sim.getDate();
  M_ip = 0;
  M_result = 0;
  M_A = 0;
  M_B = 0;
  M_C = 0;
}

/* Constructor - creates a new critter with a random program, random location
 * @param sim the simulation where the critter will live
 * @param genotypeLength the length of this critter's VM program
 * @param energy the amount of energy the critter has
 */
Critter::Critter (Sim& sim, int genotypeLength, int energy)
  : M_sim(sim)
{
  assert (genotypeLength);
  assert (energy);
  
  M_id = -1; // assigned when critter is added to the sim
  M_birthday = M_sim.getDate();
  M_generation = 0;
  M_ip = 0;
  M_result = 0;
  M_A = 0;
  M_B = 0;
  M_C = 0;
  M_x = -1;
  M_y = -1;
  M_direction = RANDINT (4);
  M_energy = energy;
  
  // initialize genotype with random instructions
  for (int i = 0; i < genotypeLength; i++)
    {
      M_genotype.push_back((Uint8) RANDINT (256));
    }
}

/* Destructor
 */
Critter::~Critter()
{
  //cout << "~Critter[" << M_id << "]:" << M_generation << endl;
  //printState();
  //printGenotype();
}

/* accessor
 * @return the age of the critter in simulation days
 */
int Critter::getAge()
{
  return M_sim.getDate () - M_birthday;
}

/* getAppearance - returns the way the critter appears to other critters
 * @return the critter's appearance
 */
unsigned char Critter::getAppearance()
{
  return 64;
}

/* accessor
 * @return the critter's current direction
 */
int Critter::getDirection()
{
  assert (M_direction >= 0 && M_direction < 4);
  return M_direction;
}

/* accessor
 * @return the amount of energy in the critter
 */
int Critter::getEnergy()
{
  assert (M_energy >= 0 && M_energy <= MAXENERGY);
  return M_energy;
}

/* accessor
 * @return the number of ancestors this critter has
 */
int Critter::getGeneration()
{
  return M_generation;
}

/* accessor
 * @return the ID number of the critter
 */
int Critter::getId()
{
  return M_id;
}

/* getReg - get the value of a VM register
 * @param reg the register to read
 * @return the value of the specified register
 * @throws IgnoreInstruction when an invalid register is specified
 */
unsigned char Critter::getReg (int reg)
{
  switch (reg)
    {
    case REG_RESULT:
      return M_result;
    case REG_A:
      return M_A;
    case REG_B:
      return M_B;
    case REG_C:
      return M_C;
    case REG_DIRECTION:
      return (Uint8) M_direction;
    case REG_ENERGY:
      return (Uint8) M_energy;
    case REG_RESERVED:
      throw IgnoreInstruction();
    case REG_NW:
      return (Uint8) M_sim.look (M_x - 1, M_y - 1);
    case REG_N:
      return (Uint8) M_sim.look (M_x, M_y - 1);
    case REG_NE:
      return (Uint8) M_sim.look (M_x + 1, M_y - 1);
    case REG_W:
      return (Uint8) M_sim.look (M_x - 1, M_y);
    case REG_SELF:
      return (Uint8) M_sim.look (M_x, M_y);
    case REG_E:
      return (Uint8) M_sim.look (M_x + 1, M_y);
    case REG_SW:
      return (Uint8) M_sim.look (M_x - 1, M_y + 1);
    case REG_S:
      return (Uint8) M_sim.look (M_x, M_y + 1);
    case REG_SE:
      return (Uint8) M_sim.look (M_x + 1, M_y + 1);
    default:
      // program should never reach this point
      assert (0);
    }
  return 0;
}

/* accessor
 * @return the critter's x-coordinate in the simulation sim, or -1
 */
int Critter::getX ()
{
  return M_x;
}

/* accessor
 * @return the critter's y-coordinate in the simulation sim, or -1
 */
int Critter::getY ()
{
  return M_y;
}

/* printGenotype - prints out the critter's id, age, and genotype to stdout
 */
void Critter::printGenotype()
{
  assert (M_id);
  
  cout << "CRITTER[" << M_id << "](" << getAge() << "):";
  for (int i = 0; i < M_genotype.size(); i++)
    {
      cout << hex << setfill('0') << setw(2) << (int)M_genotype[i];
    }
  cout << dec << endl;
}

/* printStates - prints out the critter's ID and position to stdout
 */
void Critter::printState()
{
  cout << "CRITTER[" << M_id << "]:" << M_x << "," << M_y << endl;
}

/*
void Critter::randomGenes()
{
  assert (M_genotypeLength);
  assert (M_genotype == NULL);
  
  // allocate genotype
  M_genotype = new unsigned char[M_genotypeLength];
  assert (M_genotype);
  
  // initialize genotype with random instructions
  for (int i = 0; i < M_genotypeLength; i++)
    {
      M_genotype[i] = (Uint8) RANDINT (256);
    }
}
*/

/* reproduce - reproduce the critter. NOT IMPLEMENTED IN BASE CLASS.
 * @param reg a register value specified in the instruction
 */
void Critter::reproduce (int reg)
{
};

/* setId - sets the critter's ID number, can be called only once
 * @param id the critter's id number
 */
void Critter::setId (int id)
{
  assert (M_id == -1);// allow id to be set only once
  M_id = id;
}

/* setPosition - sets the critter's position in the sim
 * @param x the critter's new x-coordinate
 * @param y the critter's new y-coordinate
 */
void Critter::setPosition (int x, int y)
{
  assert (M_sim.in (x, y));
  assert (NULL == M_sim.getCritter (x, y));
  M_x = x;
  M_y = y;
}

/* setReg - sets the value in a VM register
 * @param reg the register to set
 * @param val the value to assign to the register
 * @throws IgnoreInstruction when an invalid register is specified
 */
void Critter::setReg (int reg, Uint8 val)
{
  switch (reg)
    {
    case REG_RESULT:
      M_result = val;
    case REG_A:
      M_A = val; return;
    case REG_B:
      M_B = val; return;
    case REG_C:
      M_C = val; return;
    case REG_DIRECTION:
      M_direction = val & 0x03;
      return;
    case REG_RESERVED:
      throw IgnoreInstruction();
    default:
      throw IgnoreInstruction();
    }
}

/* think - performs one thought or action
 * @throws ActionPeformed when a turn-ending action was performed
 */
void Critter::think ()
{
  // instruction code
  assert (M_ip < M_genotype.size ());
  int i = M_genotype[M_ip];
  M_ip = (M_ip + 1) % M_genotype.size ();
  
  // register is upper 4 bits
  int reg = (i & 0xFF) >> 4;
  
  // instruction is lower 4 bits
  i &= 0x0F;
  
  // interpret the instruction
  try {
    Uint8 immediate;
    int x, y;
    switch (i)
      {
      case I_SET:
	assert (M_ip < M_genotype.size ());
	immediate = M_genotype[M_ip];
	M_ip = (M_ip + 1) % M_genotype.size ();
	setReg (reg, immediate);
	break;
      case I_COPYA:
	M_A = getReg (reg);
	break;
      case I_COPYB:
	M_B = getReg (reg);
	break;
      case I_COPYC:
	M_C = getReg (reg);
	break;
      case I_ADD:
	M_result = M_result + getReg (reg);
	break;
      case I_SUBTRACT:
	M_result = M_result - getReg (reg);
	break;
      case I_MUL:
	M_result = M_result * getReg (reg);
	break;
      case I_DIV:
	// denominator
	x = getReg (reg);
	// div by zero
	if (x == 0)
	  {
	    M_result = 255;
	  }
	else
	  {
	    M_result = (Uint8) (M_result / x);
	  }
	break;
      case I_INC:
	M_result++;
	break;
      case I_EQUAL:
	M_result = (getReg (reg) == M_result);
	break;
      case I_GREATER:
	M_result = (getReg (reg) > M_result);
	break;
      case I_LESS:
	M_result = (getReg (reg) < M_result);
	break;
      case I_JUMP:
	M_ip = getReg (reg) % M_genotype.size();
	break;
      case I_REPRODUCE:
	// cout "I_REPRODUCE(" << M_id << ") "
	reproduce (reg);
	throw ActionPerformed();
      case I_MOVE:
	// current position
	x = M_x;
	y = M_y;
	
	// forward position
	switch (M_direction)
	  {
	  case EAST:
	    x++;
	    break;
	  case NORTH:
	    y--;
	    break;
	  case WEST:
	    x--;
	    break;
	  case SOUTH:
	    y++;
	    break;
	  }
	
	M_result = M_sim.moveCritter (this, x, y);
	if (M_result)
	  {
	    // successful move ends turn
	    throw ActionPerformed();
	  }
      case I_EAT:
	// don't eat if it would waste
	if ((int) M_energy + FOODPOTENCY > MAXENERGY)
	  {
	    M_result = 0;
	    throw ActionPerformed();
	  }
	
	// no food
	if (!M_sim.getFood (M_x, M_y))
	  {
	    M_result = 0;
	    throw ActionPerformed();
	  }
	
	// eat, end turn
	M_energy += FOODPOTENCY;
	M_sim.foodEaten (M_x, M_y);
	M_result = 1;
	throw ActionPerformed();
      default:
	// program should never reach here
	assert (0);
      }
  }
  catch (IgnoreInstruction) {};
}

void Critter::update ()
{
  // sanity checks
  assert (M_sim.in (M_x, M_y));
  assert (M_sim.getCritter (M_x, M_y) == this);
  assert (M_direction >= 0 && M_direction < 4);
  assert (M_id);
  assert (M_birthday >= 0 && M_birthday <= M_sim.getDate ());
  assert (M_generation >= 0);
  assert (M_energy <= MAXENERGY);
  
  // creature is dead, so do nothing
  if (M_energy < 1)
    {
      return;
    }
  
  try {
    for (int n = 0; n < THINKCYCLES; n++)
      {
	// execute genotype instruction
	think ();
	// dead?
	if (!M_energy)
	  {
	    break;
	  }
      }
  }
  // turn-ending instruction was executed
  catch (ActionPerformed) {};
  
  // thinking takes energy
  M_energy --;
}
