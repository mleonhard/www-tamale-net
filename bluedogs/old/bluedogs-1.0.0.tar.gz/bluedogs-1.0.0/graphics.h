/* graphics.h
 * 
 * Copyright (C) 2003-2007 Michael Leonhard
 * http://tamale.net/bluedogs
 */

#ifndef GRAPHICS_H

#include <cassert>
#include <SDL.h>
#include <string>
#include <vector>

using namespace std;

// classes
class Display;
class Displayable;
class Background;
class Text;
class Number;
class Rectangle;

// instantiate this class to handle the display
class Display
{
private:
  Display (const Display& rhs); // disabled copy constructor
  const Display& operator= (const Display& rhs); // disabled copy assignment operator
  
protected:
  SDL_Surface* M_surface;
  vector<Displayable*> M_widgets;
  Displayable* M_focusedWidget;
public:
  Display (int width, int height, const char* caption);
  ~Display(); // destructor
  
  void addWidget (Displayable* widget);
  void removeWidget (Displayable* widget);
  void dispatch (SDL_Event& event);
  void dispatch (SDL_Event& event, int x, int y);
  void draw ();
  int getHeight ();
  SDL_Surface* getSurface ();
  int getWidth ();
  void setCaption (const char* caption);
  void setFocus (Displayable* widget);
  void setVideoMode (int width, int height);
  void updateRegion (SDL_Rect &rect);
};

class GraphicsError
{
protected:
  string M_description;
public:
  GraphicsError ();
  GraphicsError (const string& description);
  GraphicsError (const string& desc1, const string& desc2);
  GraphicsError (const string& d1, const string& d2, const string& d3);
  void printStdErr ();
};

class DisplayQuit : public GraphicsError
{
public:
  DisplayQuit ();
};

/* Displayable - base class for all widgets.  Make your widgets
                 inherit from this class.
 */
class Displayable
{
protected:
  SDL_Rect M_rect;
  bool M_visible;
  bool M_needsOptimize;
public:
  Displayable();
  Displayable (int x, int y);
  Displayable (int x, int y, int w, int h);
  virtual ~Displayable ();
  virtual SDL_Rect const* draw (SDL_Surface* surface);
  virtual void event (SDL_Event& event, Display& display);
  virtual SDL_Rect const* getRect ();
  virtual bool in_region (int x, int y);
  bool isVisible ();
  virtual void move (int x, int y);
  virtual void optimize (SDL_Surface* surface);
  virtual void resize (int w, int h);
};

//////////////////////////////////////////////////////////////////////
// Widgets
//////////////////////////////////////////////////////////////////////

class Background : public Displayable
{
protected:
  Uint32 M_color;
  int M_red, M_green, M_blue;
public:
  Background (int red, int green, int blue);
  virtual SDL_Rect const* draw (SDL_Surface* screen);
  int getBlue ();
  int getGreen ();
  int getRed ();
  void optimize (SDL_Surface* surface);
  void setColor (int red, int green, int blue);
};

class Rectangle : public Background
{
public:
  Rectangle (int left, int right, int top, int bottom, int red, int green, int blue);
  SDL_Rect const* draw (SDL_Surface* screen);
  void optimize (SDL_Surface* screen);
};

class Text : public Displayable
{
private:
  Text (const Text& rhs); // disabled copy constructor
  const Text& operator= (const Text& rhs); // disabled copy assignment operator
protected:
  unsigned int M_charWidth;
  SDL_Surface* M_unoptimizedFont;
  SDL_Surface* M_font;
  string M_text;
public:
  virtual SDL_Rect const* draw (SDL_Surface* screen);
  //const SDL_Rect* getRect();
  string getText();
  void optimize (SDL_Surface* surface);
  virtual void setText (string text);
  Text (int left, int top, string text);
  virtual ~Text();
};

class Number : public Text
{
protected:
  string M_label;
  int M_number;
public:
  void dec ();
  void inc ();
  Number (int left, int top, int number);
  Number (int left, int top, int number, string label);
  virtual ~Number();
  int getNumber ();
  string getLabel ();
  void render();
  void setLabel (string label);
  void setNumber (int number);
};

#define GRAPHICS_H
#endif
