/*
population.cc

Copyright (C) 2003
Michael Leonhard
http://tamale.net/
*/

#include <assert.h>

#define NULL 0

#include "trees.hpp"

#define maxItems 4

void QuadNode::add( ListNode* item ) {
	int x = item->getX();
	int y = item->getY();
	
	assert( in( x, y ) );
	
	/* this is branch node */
	if( M_i ) {
		/* find leaf node */
		QuadNode& leaf = *leafNode( x, y );
		/* add the item to the leaf node */
		leaf.add( item );
		return;
		}
	
	/* this is a leaf node */
	
	/* list is not empty */
	if( M_itemList ) {
		/* link item before head of list */
		M_itemList->linkPrev( item );
		}
	/* list is empty */
	else assert( M_itemCount == 0 );
	
	/* item is new head of list */
	M_itemList = item;
	
	/* list has one more item */
	incrementCount();
	
	/* too many items in this node, split it */
	if( M_itemCount >= maxItems ) split();
	}

void QuadNode::cleanup() {
	/* this is a branch node */
	if( M_i ) {
		M_i->cleanup();
		M_ii->cleanup();
		M_iii->cleanup();
		M_iv->cleanup();
		return;
		}
	
	/* this is a leaf node */
	ListNode* item = M_itemList, * next;
	while( item ) {
		/* item must be destroyed */
		if( !item->persist() ) {
			next = item->getNext();
			
			/* unlink the item from the list */
			remove( item );
			/* destroy it */
			delete item;
			
			item = next;
			}
		else item = item->getNext();
		}
	}

void QuadNode::decrementCount() {
	M_itemCount--;
	/* parent exists, so decrement it */
	if( M_parent ) M_parent->decrementCount();
	}

QuadNode* QuadNode::getI() { return M_i; }
QuadNode* QuadNode::getII() { return M_ii; }
QuadNode* QuadNode::getIII() { return M_iii; }
QuadNode* QuadNode::getIV() { return M_iv; }
int QuadNode::getItemCount() { return M_itemCount; }
ListNode* QuadNode::getList() { return M_itemList; }

int QuadNode::in( int x, int y ) {
	return (x >= M_left && x < M_right && y >= M_top && y < M_bottom );
	}

void QuadNode::incrementCount() {
	M_itemCount++;
	/* parent exists, so increment it */
	if( M_parent ) M_parent->incrementCount();
	}

void QuadNode::initialize( int left, int right, int top, int bottom ) {
	assert( left >= 0 );
	assert( right > left );
	assert( top >= 0 );
	assert( bottom > top );
	
	/* start out as empty leaf node */
	M_itemCount = 0;
	M_itemList = NULL;
	M_parent = NULL;
	
	/* borders of region. top and left are included, bottom and right are not */
	M_left = left;
	M_right = right;
	M_top = top;
	M_bottom = bottom;
	
	/* the center of the region (where it would be divided) */
	M_centerX = (left + right)/2;
	M_centerY = (top + bottom )/2;
	
	/* leaf node has no sub nodes */
	M_i = M_ii = M_iii = M_iv = NULL;
	}

/* I hope the stack is big enough for these deep traversals */
QuadNode* QuadNode::leafNode( int x, int y ) {
	assert( in( x, y ) );
	
	/* this is a leaf node */
	if( M_i == NULL ) return this;
	
	/* this is a branch node */
	assert( M_i );
	assert( M_ii );
	assert( M_iii );
	assert( M_iv );
	
	/* traverse to the next smallest node */
	
	/* right side, i and iv */
	if( x >= M_centerX ) {
		/* bottom right */
		if( y >= M_centerY ) return M_iv->leafNode( x, y );
		/* top right */
		return M_i->leafNode( x, y );
		}
	
	/* bottom left */
	if( y >= M_centerY ) return M_iii->leafNode( x, y );
	/* top left */
	return M_ii->leafNode( x, y );
	}

ListNode* QuadNode::location( int x, int y ) {
	/* coordinates are not in this node */
	if( !in( x, y ) ) return NULL;
	
	/* this is branch node */
	if( M_i ) {
		/* find leaf node */
		QuadNode& leaf = *leafNode( x, y );
		/* search in leaf node */
		return leaf.location( x, y );
		}
	
	/* this is a leaf node */
	
	/* look for item with position */
	ListNode* current = M_itemList;
	while( current ) {
		if( current->getX() == x && current->getY() == y ) return current;
		current = current->getNext();
		}
	
	/* no item with that position */
	return NULL;
	}

QuadNode::QuadNode( int left, int right, int top, int bottom ) {
	initialize( left, right, top, bottom );
	}

QuadNode::QuadNode( QuadNode* parent, int left, int right, int top, int bottom ) {
	initialize( left, right, top, bottom );
	M_parent = parent;
	}

void QuadNode::relocate( ListNode* item, int newX, int newY ) {
	assert( in( item->getX(), item->getY() ) );
	assert( in( newX, newY ) );
	
	/* find the leaf node where item lives */
	QuadNode *leaf = leafNode( item->getX(), item->getY() );
	
	/* new location is still in that leaf node */
	if( leaf->in( newX, newY ) ) {
		/* update the location */
		item->M_x = newX;
		item->M_y = newY;
		return;
		}
	
	/* remove the item from the leaf node */
	leaf->remove( item );
	
	/* update the location */
	item->M_x = newX;
	item->M_y = newY;

	/* add the item back in to the tree */
	QuadNode::add( item );
	}

void QuadNode::remove( ListNode* item ) {
	assert( item );
	
	int x = item->getX();
	int y = item->getY();
	
	assert( in( x, y ) );
	
	/* this is branch node */
	if( M_i ) {
		/* find leaf node */
		QuadNode& leaf = *leafNode( x, y );
		/* remove the item from the leaf node */
		leaf.remove( item );
		return;
		}
	
	/* this is a leaf node */
	
	/* make certain that item is in this list */
	ListNode* current = M_itemList;
	while( current ) {
		if( current == item ) break;
		current = current->getNext();
		}
	assert( current == item );
	
	/* it's the head of list */
	if( M_itemList == item ) {
		/* next is new head of list */
		M_itemList = item->getNext();
		}
	
	/* remove the item from the list */
	item->unlink();
	
	/* list has one less item */
	decrementCount();
	}

void QuadNode::split() {
	assert( M_itemCount >= maxItems );
	
	/* create the sub-nodes */
	M_i = new QuadNode( this, M_centerX, M_right, M_top, M_centerY );
	M_ii = new QuadNode( this, M_left, M_centerX, M_top, M_centerY );
	M_iii = new QuadNode( this, M_left, M_centerX, M_centerY, M_bottom );
	M_iv = new QuadNode( this, M_centerX, M_right, M_centerY, M_bottom );
	
	ListNode* next;
	
	/* remove and add each item */
	while( M_itemList ) {
		/* remember next item */
		next = M_itemList->getNext();
		/* remove the first item from the list */
		M_itemList->unlink();
		/* one less item */
		decrementCount();
		/* add the item again (to the sub nodes) */
		QuadNode::add( M_itemList );
		/* go on... */
		M_itemList = next;
		}
	verify();
	}

void QuadNode::verify() {
	/* this is a branch node */
	if( M_i ) {
		M_i->verify();
		M_ii->verify();
		M_iii->verify();
		M_iv->verify();
		return;
		}
	
	/* this is a leaf node */
	ListNode* item = M_itemList;
	while( item ) {
		/* check that item is in this square */
		assert( in( item->getX(), item->getY() ) );
		item = item->getNext();
		}
	}

ListNode* ListNode::getNext() { return M_next; }
ListNode* ListNode::getPrev() { return M_prev; }
QuadNode* ListNode::getQuad() { return M_quadTree; }
int ListNode::getX() { return M_x; }
int ListNode::getY() { return M_y; }

void ListNode::joinQuad( QuadNode *quadTree ) {
	assert( quadTree );
	assert( M_quadTree == NULL );/* can only add to one Quad Tree */
	M_quadTree = quadTree;
	M_quadTree->add( this );
	}

void ListNode::linkNext( ListNode* newnode ) {
	/* newnode must be solitary node */
	assert( newnode );
	assert( newnode->getPrev() == NULL );
	assert( newnode->getNext() == NULL );
	
	/* second node */
	ListNode* second = M_next;
	/* link both ways with new node */
	M_next = newnode;
	newnode->setPrev( this );
	/* link new node to second */
	newnode->setNext( second );
	/* second node exists, link second back to new node */
	if( second ) second->setPrev( newnode );
	}

void ListNode::linkPrev( ListNode* newnode ) {
	/* newnode must be solitary node */
	assert( newnode );
	assert( newnode->getPrev() == NULL );
	assert( newnode->getNext() == NULL );
	
	/* second node */
	ListNode* second = M_prev;
	/* link both ways with new node */
	M_prev = newnode;
	newnode->setNext( this );
	/* link new node to second */
	newnode->setPrev( second );
	/* if second node exists, link it forward to new node */
	if( second ) second->setNext( newnode );
	}

ListNode::ListNode( int x, int y ) {
	assert( x >= 0 );
	assert( y >= 0 );
	
	/* initialize to unlinked state */
	M_next = M_prev = NULL;
	M_x = x;
	M_y = y;
	M_quadTree = NULL;
	}

ListNode::ListNode() {
	/* initialize to unlinked state */
	M_next = M_prev = NULL;
	M_x = M_y = -1;
	M_quadTree = NULL;
	}

ListNode* ListNode::location( int x, int y ) {
	assert( M_quadTree );
	return M_quadTree->location( x, y );
	}

void ListNode::move( int newX, int newY ) {
	assert( newX >= 0 );
	assert( newY >= 0 );
	
	/* remember our old position /
	int oldx = M_x, oldy = M_y;
	/* move to new position /
	M_x = x;
	M_y = y;
	
	/* if in quadTree, let it move us */
	if( M_quadTree ) M_quadTree->relocate( this, newX, newY );
	/* not in quadTree, so update our own position */
	else {
		M_x = newX;
		M_y = newY;
		}
	}

bool ListNode::persist() { return true; }

void ListNode::setNext( ListNode* next ) {
	/* link to next node */
	M_next = next;
	}

void ListNode::setPrev( ListNode* prev ) {
	/* link to prev node */
	M_prev = prev;
	}

void ListNode::unlink() {
	verify();
	/* if prev exists, link it to next */
	if( M_prev ) M_prev->setNext( M_next );
	/* if next exists, link it to prev */
	if( M_next ) M_next->setPrev( M_prev );
	/* this is now unlinked */
	M_prev = M_next = NULL;
	}

void ListNode::verify() {
	verifyBackward();
	verifyForward();
	}

void ListNode::verifyBackward() {
	ListNode *node, *prev;
	/* walk backward */
	node = this;
	while( node ) {
		/* check prev node */
		prev = node->getPrev();
		/* if it exists, make sure it links to this */
		if( prev ) assert( prev->getNext() == node );
		/* prev node */
		node = prev;
		}
	}

void ListNode::verifyForward() {
	ListNode *node, *next;
	/* walk forward */
	node = this;
	while( node ) {
		/* check next node */
		next = node->getNext();
		/* if it exists, make sure it links to this */
		if( next ) assert( next->getPrev() == node );
		/* next node */
		node = next;
		}
	}
