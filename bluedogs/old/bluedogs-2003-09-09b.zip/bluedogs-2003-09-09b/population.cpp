/*
population.cc

Copyright (C) 2003
Michael Leonhard
http://tamale.net/
*/

#include <assert.h>
#include <SDL.h>
#include <time.h>

#include "bluedogs.hpp"

void Population::add( ListNode* item ) {
	Critter* critter = (Critter *)item;
	
	/* give the new critter an ID */
	critter->setId( M_idCount++ );
	
	/*printf( "+%d ", critter->getId() );
	fflush( stdout );/**/
	
	/* add it to the quad tree */
	QuadNode::add( critter );
	}

void Population::checkAge( int age ) {
	if( age < M_maxAge ) return;
	printf( "%d ", age );
	fflush( stdout );
	M_maxAge = age;
	}

void Population::drawNode( QuadNode *node ) {
	assert( node );
	
	/* this is a branch node */
	if( node->getI() ) {
		drawNode( node->getI() );
		drawNode( node->getII() );
		drawNode( node->getIII() );
		drawNode( node->getIV() );
		return;
		}
	
	/* this is a leaf node */
	Critter* critter = (Critter *)node->getList();
	while( critter ) {
		critter->draw( *M_display );
		critter = (Critter *)critter->getNext();
		}
	}

void Population::draw() {
	drawNode( this );
	}

Population::Population( Display& display )
	 : QuadNode( 0, display.getWidth(), 0, display.getHeight() ) {
	/* initialize data */
	M_display = &display;
	M_idCount = 1;
	M_maxAge = 0;
	}

void Population::printGenotypes() {
	Critter* critter;
	
	/* start at head of list */
	critter = (Critter *)getList();
	/* walk list */
	while( critter ) {
		assert( critter->getId() );
		assert( critter->getId() < M_idCount );
		/* print it */
		critter->printGenotype();
		/* next */
		critter = (Critter *)critter->getNext();
		}
	}

void Population::remove( Critter* critter ) {
	assert( critter );
	assert( critter->getId() );
	assert( critter->getId() < M_idCount );
	
	checkAge( critter->getAge() );
	
	QuadNode::remove( critter );
	}

void Population::updateNode( QuadNode *node ) {
	assert( node );
	
	/* this is a branch node */
	if( node->getI() ) {
		updateNode( node->getI() );
		updateNode( node->getII() );
		updateNode( node->getIII() );
		updateNode( node->getIV() );
		return;
		}
	
	/* this is a leaf node */
	Critter* critter = (Critter *)node->getList();
	while( critter ) {
		assert( critter->getId() );
		assert( critter->getId() < M_idCount );
		critter->update();
		critter = (Critter *)critter->getNext();
		}
	}

void Population::update() {
	/* clean list of dead critters */
	cleanup();
	
	/* update each critter */
	updateNode( this );
	}
