/*
bluedogs.cc

Copyright (C) 2003
Michael Leonhard
http://tamale.net/
*/

#include <assert.h>
#include <SDL.h>
#include <SDL_image.h>
#include <time.h>

#include "bluedogs.hh"

#define NUMBERS "numbers.png"

FPSCounter::FPSCounter( Display& display, int x, int y ) {
	last = 0;
	times = 0;
	/*NumberDisplay( display, x, y, 0 );/**/
	}

void FPSCounter::draw() {
	time_t now;
	
	now = time( NULL );
	if( now >= last ) {
		last = now;
		setVal( times );
		times = 0;
		}
	
	NumberDisplay::draw();
	}

void NumberDisplay::draw() {
	SDL_Rect srcrect, dstrect;
	dstrect.x = M_x;
	dstrect.y = M_y;
	srcrect.y = 0;
	srcrect.w = M_numbers->w / 11;
	srcrect.h = M_numbers->h;
	
	for( int i = 0; i < 13 && M_digits[i] != -2; i++ ) {
		srcrect.x = (M_digits[i] + 1) * srcrect.w;
		SDL_BlitSurface( M_numbers, &srcrect, M_display->getSurface(), &dstrect );
		dstrect.x += srcrect.w;
		};
	}

void NumberDisplay::move( int x, int y ) {
	assert( x >= 0 );
	assert( x < M_display->getWidth() );
	assert( y >= 0 );
	assert( y < M_display->getHeight() );
	
	M_x = x;
	M_y = y;
	}

NumberDisplay::NumberDisplay() {
	M_display = NULL;
	M_x = -1;
	M_y = -1;
	for( int i = 0; i < 13; i++ ) M_digits[i] = -2;
	M_numbers = NULL;
	}

NumberDisplay::NumberDisplay( Display& display, int x, int y, int val ) {
	M_display = &display;
	move( x, y );
	setVal( val );
	
	/* load the image */
	SDL_Surface *image = IMG_Load( NUMBERS );
	if( image == NULL ) {
		fprintf( stderr,"Couldn't load image, %s: %s\n", NUMBERS, SDL_GetError() );
		throw NumberDisplayInitFailure();
		return;
		}
	M_numbers = SDL_DisplayFormatAlpha( image );
	SDL_FreeSurface( image );
	}

void NumberDisplay::setVal( int newval ) {
	int i, n;
	int negative = 0;
	
	/* negative number */
	if( newval < 0 ) {
		negative = 1;
		newval = 0 - newval;
		}
	
	/* longest number: -4294967296 is 11 digits long */
	assert( newval <= 2147483647 ); /* in case int is >32 bits */
	
	n = newval;
	
	/* count digits */
	for( i = 0; i <= 13; i++ ) {
		if( n == 0 ) break;
		n /= 10;
		}
	
	assert( i < 12 );
	
	/* zero needs one digit */
	if( i == 0 ) i = 1;
	
	/* neg needs one digit too */
	if( negative ) {
		i++;
		M_digits[0] = -1;
		}
	
	/* end marker */
	/*printf( "M_digits[%d] = -2\n", i );/**/
	M_digits[i] = -2;
	i--;
	
	/* each digit */
	for( ; i >= 0; i-- ) {
		/*printf( "M_digits[%d] = %d %% 10 = %d\n", i, newval, newval % 10 );/**/
		M_digits[i] = newval % 10;
		newval /= 10;
		if( newval == 0 ) break;
		}
	
	/*
	printf( "Printing digits:\n" );
	for( i = 0; i < 13; i++ ) {
		printf( "M_digits[%d] = %d\n", i, M_digits[i] );
		}/**/
	}

bool Display::areDrawing() {
	return (M_draw > 0);
	}

void Display::blank() {
	/* not drawing */
	if( !M_draw ) return;

	/* draw a big black rectangle over the whole screen */
	SDL_FillRect( M_screen, NULL, SDL_MapRGB( M_screen->format, 0, 0, 0 ) );
	}

Display::Display( int width, int height, int depth, const char* caption ) {
	
	assert( width );
	assert( height );
	assert( depth );
	assert( caption );
	
	/* initialize SDL */
	if( SDL_Init( SDL_INIT_VIDEO ) < 0 ) {
		fprintf(stderr, "Couldn't initialize SDL: %s\n",SDL_GetError());
		throw DisplayInitFailure();
		}
	
	/* Set window caption */
	SDL_WM_SetCaption( caption, caption );
	
	/* set the video mode */
	M_screen = SDL_SetVideoMode( width, height, depth, SDL_SWSURFACE );
	if( M_screen == NULL ) {
		fprintf( stderr,"Couldn't set video mode: %s\n", SDL_GetError() );
		SDL_Quit();
		throw DisplayVideoModeFailure();
		}
	
	/* initialize data */
	M_draw = 1;
	M_FPS = new FPSCounter( *this, getWidth() - 50, 10 );
	}

Display::~Display() {
	SDL_Quit();
	}

void Display::draw() {
	/* always draw FPS */
	M_FPS->draw();
	
	/* update if no key is pressed */
	if( M_draw ) SDL_UpdateRect( M_screen, 0, 0, 0, 0 );
	}

void Display::drawCell( SDL_Rect& rect, int red, int blue, int green ) {
	/* not drawing */
	if( !M_draw ) return;

	/* draw the cell */
	SDL_FillRect( M_screen, &rect, SDL_MapRGB( M_screen->format, red, blue, green ) );
	}

void Display::drawCell( SDL_Rect& rect, int red, int blue, int green, int direction ) {
	/* not drawing */
	if( !M_draw ) return;

	/* draw the cell */
	SDL_FillRect( M_screen, &rect, SDL_MapRGB( M_screen->format, red, blue, green ) );
	
	/* construct the "head" pointing in right direction */
	SDL_Rect head;
	head.x = head.y = 0;
	head.w = head.h = 2;
	switch( direction ) {
		case SOUTH:
			head.y = rect.h - 3;
		case NORTH:
			head.y += rect.y + 1;
			head.x = rect.x + 2;
			head.w = rect.w - 4;
			break;
		case EAST:
			head.x = rect.w - 3;
		case WEST: head.x += rect.x + 1;
			head.y = rect.y + 2;
			head.h = rect.h - 4;
			break;
		}
	
	/* draw the "head" */
	SDL_FillRect( M_screen, &head, SDL_MapRGB( M_screen->format, red - 0x80, blue - 0x80, green - 0x80 ) );
	}

void Display::events() {
	SDL_Event event;
	
	/* process all events on queue */
	while( SDL_PollEvent( &event ) ) {
		switch( event.type ) {
			case SDL_QUIT: throw DisplayQuit();
			case SDL_KEYDOWN:
				/* stop drawing when a key is pressed */
				M_draw = 0;
				break;
			case SDL_KEYUP:
				/* start drawing when a key is released */
				M_draw = 1;
				fflush( stdout );
				break;				
			case SDL_MOUSEBUTTONDOWN:
				/* if we're not drawing then mouse click starts us drawing */
				if( M_draw == 0 ) {
					M_draw = 1;
					fflush( stdout );
					}
				/* if we're drawing then mouse click stops us drawing */
				else M_draw = 0;
				break;
			}
		}
	}
	
int Display::getHeight() {
	return M_screen->h;
	}

SDL_Surface* Display::getSurface() {
	return M_screen;
	}

int Display::getWidth() {
	return M_screen->w;
	}

/*
Display::LoadPicture( const char *filename ) {
	/* load the graphic /
	dogpic = IMG_Load( DOGPIC );
	if( dogpic == NULL ) {
		fprintf( stderr,"Couldn't load image, %s: %s\n", DOGPIC, SDL_GetError() );
		SDL_Quit();
		return 4;
		}
	SDL_SetColorKey( dogpic, SDL_SRCCOLORKEY, SDL_MapRGB( dogpic->format, 0xFF, 0xFF, 0xFF ) );
	dogpic = SDL_DisplayFormatAlpha( dogpic );
	}
*/
