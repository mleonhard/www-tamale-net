/*
bluedogs.cc

Copyright (C) 2003
Michael Leonhard
http://tamale.net/
*/

#include <assert.h>
#include <SDL.h>
#include <stdlib.h>
#include <time.h>

#include "bluedogs.hh"

void Simulation::loop() {
	Critter *critter;
	int c;

	/* loop until DisplayQuit */
	while( 1 ) {
		/*printf( "." );
		fflush( stdout );/**/
		
		/* keep the population above minimum */
		for( c = M_population->count(); c < M_minCritters; c++ ) {
			critter = new Critter( *M_field, M_genotypeLength, M_initialEnergy );
			M_population->add( *critter );
			}

		/* update the simulation */
		M_field->update();/**/
		M_population->update();/**/
		
		/* process events from the user */
		M_display->events();
		
		/* the screen should be updated */
		if( M_display->areDrawing() ) {
			M_display->blank();/**/
			M_field->draw();/**/
			M_population->draw();/**/
			M_display->draw();/**/
			/*SDL_Delay( 1000 );/**/
			}
		}
	}

Simulation::Simulation( Display& display, Field& field, Population& population, int minCritters, int genotypeLength, int initialEnergy ) {
	M_display = &display;
	M_field = &field;
	M_population = &population;
	M_minCritters = minCritters;
	M_genotypeLength = genotypeLength;
	M_initialEnergy = initialEnergy;
	}

Simulation::~Simulation() {
	printf( "\n~Simulation\n" );
	/*M_population->printGenotypes();/**/
	}

#define USAGE "bluedogs - Mike Leonhard http://tamale.net\n"
#define FIELDW 32
#define FIELDH 32
#define MINIMUMCRITTERS 96
#define INITIALFOOD 65536
#define GROWTHRATE 100
#define GENOTYPELENGTH 64
#define INITIALENERGY 64

int main( int argc, char *argv[] ) {
	/* check command line */
	if( argc != 1 ) {
		/* print usage */
		fprintf( stderr, USAGE );
		return 1;
		}
	
	/* initialize */
	try {
		Display display( 800, 600, 16, "bluedogs" );
		/* seed the random number generator */
		srand( (unsigned int)time( NULL ) );
		
		/* prepare the field */
		Field field( display, FIELDW, FIELDH, INITIALFOOD, GROWTHRATE );
		
		/* prepare the initial critters */
		Population population( display, field );
		
		/* the simulation */
		Simulation simulation( display, field, population, MINIMUMCRITTERS, GENOTYPELENGTH, INITIALENERGY );
		
		/* run it */
		simulation.loop();/**/
		}
	
	/* graphics system failed to initialize */
	catch (DisplayInitFailure) { return 2; }
	/* video mode unavailable */
	catch (DisplayVideoModeFailure) { return 3; }
	/* normal exit */
	catch (DisplayQuit) { return 0; }
	
	/* program should never reach here */
	assert( 0 );
	return 0;
	}
