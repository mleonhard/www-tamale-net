/*
bluedogs.hh

Copyright (C) 2003
Michael Leonhard
http://tamale.net/
*/

#ifndef BLUEDOGS_H

/* macros */
#define RANDINT( n ) ((int)((float)(n) * rand() / (RAND_MAX + 1.0)))

#define EAST 0
#define NORTH 1
#define WEST 2
#define SOUTH 3

/* class declarations */
class Critter;
class Display;
class Field;
class FPSCounter;
class NumberDisplay;
class Population;

class Critter {
	private:
		/* environment */
		Field* M_field;
		Population* M_population;
		/* characteristics */
		int M_x, M_y, M_direction, M_energy, M_gender, M_partner;
		/* metadata */
		int M_id, M_birth, M_generation;
		/* VM variables */
		int M_p, M_genotypeLength, M_wait;
		unsigned char M_result, M_A, M_B, M_C;
		unsigned char* M_genotype;
		/* linked-list node */
		Critter* M_next;
		
		/* procedures */
		unsigned char getReg( int reg );
		void setReg( int reg, unsigned char val );
	public:
		/* procedures */
		Critter( Field &field, int genotypeLength, int initialEnergy );
		Critter( Field& field, int x, int y, int initialEnergy, Critter& mother, Critter& father );
		~Critter();
		void draw( Display& display );
		int getAge();
		int getDirection();
		unsigned char* getEgg();
		int getEggLength();
		int getEnergy();
		int getGender();
		int getGeneration();
		int getId();
		Critter* getNext();
		int getPartnerId();
		int getSpermLength();
		unsigned char* getSperm();
		void initialize( Field& field, int generation, int genotypeLength, int initialEnergy );
		int isAlive();
		int isAt( int x, int y );
		void linkNext( Critter* next );
		void mate( Critter& partner );
		void orgasm();
		void printGenotype();
		void printState();
		void randomGenes();
		void setPopulation( Population& population, int id );
		void unlinkNext();
		void update();
	};

class Display {
	public:
		bool areDrawing();
		void blank();
		Display( int width, int height, int depth, const char* caption );
		~Display();
		void draw();
		void drawCell( SDL_Rect& rect, int red, int blue, int green );
		void drawCell( SDL_Rect& rect, int red, int blue, int green, int direction );
		void events();
		int getHeight();
		SDL_Surface* getSurface();
		int getWidth();
	private:
		int M_draw;
		NumberDisplay* M_FPS;
		SDL_Surface* M_screen;
	};

class DisplayInitFailure {};
class DisplayQuit {};
class DisplayVideoModeFailure {};

class Field {
	private:
		int M_width, M_height, M_date, M_growthrate, M_growcounter;
		unsigned char* M_field;
		Display* M_display;
	public:
		void addFood( int amount );
		SDL_Rect& cellRect( int x, int y );
		void draw();
		Field( Display& display, int newwidth, int newheight, int intialfood, int growthrate );
		void foodEaten( int x, int y );
		int getDate();
		void growFood();
		int in( int x, int y );
		int look( int x, int y );
		int randX();
		int randY();
		void update();
	};

class NumberDisplay {
	private:
		Display* M_display;
		int M_x, M_y;/* top left corner */
		int M_digits[13];
		SDL_Surface* M_numbers;
	public:
		void draw();
		void move( int x, int y );
		NumberDisplay();
		NumberDisplay( Display& display, int x, int y, int val );
		void setVal( int newval );
	};

class NumberDisplayInitFailure {};

class FPSCounter : NumberDisplay {
	private:
		time_t last;
		int times;
	public:
		void draw();
		FPSCounter( Display& display, int x, int y );
	};

class Population {
	private:
		Display* M_display;
		Field *M_field;
		int M_idcount, M_maxage;
		Critter* M_list;
	public:
		void add( Critter& newCritter );
		void checkAge( int age );
		int count();
		void draw();
		Critter* location( int x, int y );
		Population( Display& display, Field& field );
		void printGenotypes();
		void purgeDeadCritters();
		void remove( Critter* newCritter );
		void update();
	};

class Simulation {
	private:
		Display* M_display;
		Field* M_field;
		Population* M_population;
		int M_minCritters, M_genotypeLength, M_initialEnergy;
	public:
		void loop();
		Simulation( Display& display, Field& field, Population& population, int mincritters, int genotypeLength, int initialEnergy );
		~Simulation();
	};

#define BLUEDOGS_H
#endif
