/*
population.cc

Copyright (C) 2003
Michael Leonhard
http://tamale.net/
*/

#include <assert.h>
#include <SDL.h>

#include "bluedogs.hh"

void Population::add( Critter& newCritter ) {
	Critter* second;;
	
	/* give the new critter an ID */
	newCritter.setPopulation( *this, M_idcount++ );
	
	/*printf( "HEAD(%d->%d,0x%08X->0x%08X) ", (M_list)?M_list->getId():0, newCritter.getId(), M_list, &newCritter );/**/
	/* head of list will become second */
	second = M_list;
	/* new critter becomes head of list */
	M_list = &newCritter;
	/* link second (and rest of list) */
	newCritter.linkNext( second );
	assert( M_list->getId() );
	assert( M_list->getId() < M_idcount );
	/*newCritter.printState();/**/
	}

void Population::checkAge( int age ) {
	if( age < M_maxage ) return;
	printf( "%d ", age );
	fflush( stdout );
	M_maxage = age;
	}

int Population::count() {
	Critter* critter;
	int c = 0;
	
	/* start at head of list */
	critter = M_list;
	/* walk list */
	while( critter ) {
		assert( critter->getId() );
		assert( critter->getId() < M_idcount );
		/* next */
		critter = critter->getNext();
		c++;
		}
	
	/* number in list */
	return c;
	}

void Population::draw() {
	Critter* critter;
	
	/* start at head of list */
	critter = M_list;
	/* walk list */
	while( critter ) {
		assert( critter->getId() );
		assert( critter->getId() < M_idcount );
		/* draw the critter */
		critter->draw( *M_display );
		/* next */
		critter = critter->getNext();
		}
	}

Critter* Population::location( int x, int y ) {
	Critter* critter;
	
	/* start at head of list */
	critter = M_list;
	/* walk list */
	while( critter ) {
		assert( critter->getId() );
		assert( critter->getId() < M_idcount );
		/* found it */
		if( critter->isAt( x, y ) ) return critter;
		/* next */
		critter = critter->getNext();
		}
	/* not found */
	return NULL;
	}

Population::Population( Display& display, Field& field ) {
	/* initialize data */
	M_display = &display;
	M_field = &field;
	M_list = NULL;
	M_idcount = 1;
	M_maxage = 0;
	}

void Population::printGenotypes() {
	Critter* critter;
	
	/* start at head of list */
	critter = M_list;
	/* walk list */
	while( critter ) {
		assert( critter->getId() );
		assert( critter->getId() < M_idcount );
		/* print it */
		critter->printGenotype();
		/* next */
		critter = critter->getNext();
		}
	}

void Population::purgeDeadCritters() {
	Critter* alive;
	Critter* critter;
	Critter* next;
	
	/* head of list is dead */
	while( M_list && !M_list->isAlive() ) {
		assert( M_list->getId() );
		assert( M_list->getId() < M_idcount );
		/* dead head */
		critter = M_list;
		/* new head of list */
		M_list = M_list->getNext();
		/* destroy critter */
		/*printf( "_" );/**/
		checkAge( critter->getAge() );
		delete critter;
		}
	
	/* head is alive */
	alive = M_list;
	/* walk list */
	while( alive ) {
		critter = alive->getNext();
		/* critter is dead */
		while( critter && !critter->isAlive() ) {
			assert( critter->getId() );
			assert( critter->getId() < M_idcount );
			/* unlink it */
			alive->unlinkNext();
			/* destroy it */
			/*printf( "-" );/**/
			checkAge( critter->getAge() );
			delete critter;
			/* next */
			critter = alive->getNext();
			}
		
		/* next is alive */
		alive = alive->getNext();
		}
	}

void Population::remove( Critter* toRemove ) {
	Critter* critter;
	Critter* next;
	
	assert( toRemove );
	assert( toRemove->getId() );
	assert( toRemove->getId() < M_idcount );
	
	/* it's the head of list */
	if( M_list == toRemove ) {
		assert( M_list->getId() );
		assert( M_list->getId() < M_idcount );
		/* new head of list */
		M_list = toRemove->getNext();
		/* destroy critter */
		delete toRemove;
		return;
		}
	
	/* look for critter, starting at head of list */
	critter = M_list;
	/* walk list */
	while( critter ) {
		assert( critter->getId() );
		assert( critter->getId() < M_idcount );
		next = critter->getNext();
		/* found it */
		if( next == toRemove ) break;
		/* next */
		critter = next;
		}
	
	/* it should be found */
	assert( critter );
	
	/* unlink it */
	critter->unlinkNext();
	/* destroy it */
	delete toRemove;
	}

void Population::update() {
	Critter* critter;
	
	/* clean list of dead critters */
	purgeDeadCritters();
	
	/* start at head of list */
	critter = M_list;
	/* walk list */
	while( critter ) {
		assert( critter->getId() );
		assert( critter->getId() < M_idcount );
		/* update the critter */
		critter->update();
		/* next */
		critter = critter->getNext();
		}
	}
