/*
	SDL_anim:  an animation library for SDL
	Copyright (C) 2001  Michael Leonhard

	This library is under the GNU Library General Public License.
	See the file "COPYING" for details.

	Michael Leonhard
	mike@tamale.net
*/

#ifndef _SDL_anim_h
#define _SDL_anim_h

#include "begin_code.h"

/* Set up for C function definitions, even when using C++ */
#ifdef __cplusplus
extern "C" {
#endif

struct SDL_Animation;
typedef struct SDL_Animation {
	SDL_Surface *surface;
	int frames, w, h;
	Uint32 duration;
	} SDL_Animation;

struct SDL_Animation *Anim_Load( const char *file );
void Anim_Free( SDL_Animation *anim );
int Anim_GetFrameNum(	SDL_Animation *anim, Uint32 start, Uint32 now );
int Anim_BlitFrame(	SDL_Animation *anim, Uint32 start, Uint32 now, SDL_Surface *dest, SDL_Rect *dr );
void Anim_GetFrameRect(	SDL_Animation *anim, int frame, SDL_Rect *rect );
int Anim_BlitFrameNum(	SDL_Animation *anim, int frame, SDL_Surface *dest, SDL_Rect *dr );
int Anim_DisplayFormat( SDL_Animation *anim );
	
/* We'll use SDL for reporting errors */
#define Anim_SetError	SDL_SetError
#define Anim_GetError	SDL_GetError

/* Ends C function definitions when using C++ */
#ifdef __cplusplus
};
#endif
#include "SDL/close_code.h"

#endif /* _SDL_anim_h */
