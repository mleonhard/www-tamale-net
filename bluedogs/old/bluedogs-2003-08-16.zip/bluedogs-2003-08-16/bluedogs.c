/*
bluedogs

Michael Leonhard
http://tamale.net/
*/

#include <assert.h>
#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <SDL.h>
#include <SDL_image.h>

/* Global program settings */
#define DOGPIC "bluedog.20x15.png"
#define FIELDW 64
#define FLOATINGFIELDW 64.0
#define FIELDH 48
#define FLOATINGFIELDH 48.0
#define INITIALCRITTERS 40
#define BREEDERS 20
#define INITIALFOOD 150
#define GENOTYPELENGTH 256
#define BRAINMEMORYSIZE 256
#define INITIALENERGY 200
#define FOODPOTENCY 10

int ranking;

/* Data types */
struct critter_struct {
	int x, y, energy, p, reg, rank;
	int genotype[GENOTYPELENGTH];
	int brainmemory[BRAINMEMORYSIZE];
	struct critter_struct *next;
	};
/*
void bubble( unsigned char *dst, int px, int py, unsigned char pc ) {
	int x, y, l;
	
	if( px < 0 ) px = 0;
	if( py < 0 ) py = 0;
	if( px > FIELDW ) px = FIELDW;
	if( py > FIELDH ) py = FIELDH;
	
	/* y axis /
	y = py;
	py += OBJECTH;
	if( py >= FIELDH ) py = FIELDH;
	
	/* x axis /
	l = px;
	px += OBJECTW;
	if( px >= FIELDW ) px = FIELDW;
	
	dst += y * FIELDW;
	for( ; y < py; y++ ) {
		for( x = l; x < px; x++ ) dst[x] = pc;
		dst += FIELDW;
		}
	}
*/

void InitializeCritter( struct critter_struct *critter ) {
	int i;
	
	/* initialize critter */
	critter->x = (int)(FLOATINGFIELDW * rand() / (RAND_MAX + 1.0) );
	critter->y = (int)(FLOATINGFIELDH * rand() / (RAND_MAX + 1.0) );
	critter->energy = INITIALENERGY;
	critter->p = 0;
	critter->reg = 0;
	
	/* genotype */
	for( i = 0; i < GENOTYPELENGTH; i++ ) critter->genotype[i] = (int)(17.0 * rand() / (RAND_MAX + 1.0) );
	/* memory */
	for( i = 0; i < BRAINMEMORYSIZE; i++ ) critter->brainmemory[i] = 0;
	}

struct critter_struct *RelinkCritterList( struct critter_struct *list ) {
	int i;
	
	assert( list );
	
	ranking = INITIALCRITTERS;
	
	/* for each one */
	for( i = 0; i < INITIALCRITTERS; i++ ) {
		/* next in linked list */
		list[i].next = &list[i + 1];
		}
	
	/* terminate the linked list */
	list[i - 1].next = NULL;
	
	/* return the first item of the list */
	return list;
	}

void PrintGenotype( struct critter_struct *critter ) {
	int i;
	
	assert( critter );
	
	printf( "%d- ", critter->rank );
	for( i = 0; i < GENOTYPELENGTH; i++ ) {
		printf( "%02X", critter->genotype[i] );
		}
	printf( "\n" );
	}

void PrintAllGenotypes( struct critter_struct *list ) {
	int i;
	for( i = 0; i < INITIALCRITTERS; i++ ) PrintGenotype( &list[i] );
	}

struct critter_struct *BreedCritters( struct critter_struct *list ) {
	int bottom = 0, top = INITIALCRITTERS - 1, save, i;
	
	assert( BREEDERS % 2 == 0 );
	assert( BREEDERS < INITIALCRITTERS );
	assert( list );
	
	for( save = 0; save < BREEDERS; save++ ) {
		/* find next lowest breeder */
		while( list[bottom].rank > BREEDERS ) bottom++;
/*		PrintGenotype( &list[bottom] );/**/
		
		/* find next highest breeder */
		while( list[top].rank > BREEDERS ) top--;
/*		PrintGenotype( &list[top] );/**/
		
		assert( top > bottom );
		
		if( bottom != save ) memcpy( list[save].genotype, list[bottom].genotype, sizeof( list[save].genotype ) );
		memcpy( list[save].genotype + GENOTYPELENGTH / 2, list[top].genotype + GENOTYPELENGTH / 2, GENOTYPELENGTH / 2 );

		bottom++;
		top--;
		save++;
		}
	
	return list;
	}

struct critter_struct *MakeCritters( struct critter_struct *list ) {
	int i = 0;
	
	/* first set */
	if( list == NULL ) {
		/* allocate one chunk of memory for critters */
		list = (struct critter_struct*)malloc( sizeof( struct critter_struct ) * INITIALCRITTERS );
		if( list == NULL ) {
			perror( "couldn't allocate memory for object list" );
			return NULL;
			}
		
		/* seed the random number generator */
		srand( (unsigned int)time( NULL ) );
		}
	/* must breed most successful critters */
	else {
		BreedCritters( list );
		i = BREEDERS;
		}
	
	/* Initialize new random critters */
	for( ; i < INITIALCRITTERS; i++ ) InitializeCritter( &list[i] );
	
	/* relink the list */
	return RelinkCritterList( list );
	}

void NewCritter( struct critter_struct *list, int x, int y, int energy ) {
	int o;
	
	assert( list );
	
	/* find unused slot */
	for( o = 0; o < INITIALCRITTERS; o++ ) if( list[o].x == -1 ) break;
	
	/* no unused object slots */
	if( o == INITIALCRITTERS ) {
		printf( "full\n" );
		return;
		}
	
	printf( "%d, %d\n", x, y );
	list[o].x = x;
	list[o].y = y;
	}

void DrawCritters( SDL_Surface *screen, SDL_Surface *dogpic, struct critter_struct *list ) {
	SDL_Rect rect;
	int xpitch, ypitch;
	
	assert( screen );
	
	if( list == NULL ) return;
	
	xpitch = screen->w / FIELDW;
	ypitch = screen->h / FIELDH;
	
	/* traverse entire list */
	while( list != NULL ) {
		rect.x = list->x * xpitch;
		rect.y = list->y * ypitch;
		SDL_BlitSurface( dogpic, NULL, screen, &rect);
		
		/* next in list */
		list = list->next;
		}
	}

void DrawField( SDL_Surface *screen, unsigned char *field ) {
	int x, y, w, h, intensity;
	SDL_Rect rect;
	
	assert( screen );
	assert( field );
	
	w = screen->w;
	h = screen->h;
	rect.w = w / FIELDW;
	rect.h = h / FIELDH;
	
	/* rows */
	rect.y = 0;
	for( y = 0; y < FIELDH; y++ ) {
		/* columns */
		rect.x = 0;
		for( x = 0; x < FIELDW; x++ ) {
			intensity = field[y * FIELDW + x];
			SDL_FillRect( screen, &rect, SDL_MapRGB( screen->format, 0x80, 0x80, intensity ) );
			/* next block */
			rect.x += rect.w;
			}
		/* move down one row */
		rect.y += rect.h;
		}
	}

void InitializeField( unsigned char *field ) {
	int f, x, y;
	memset( field, 0, FIELDW * FIELDH * sizeof( unsigned char ) );
	
	/* add food */
	for( f = 0; f < INITIALFOOD; f++ ) {
		/* food position */
		x = (int)(FLOATINGFIELDW * rand() / (RAND_MAX + 1.0) );
		y = (int)(FLOATINGFIELDH * rand() / (RAND_MAX + 1.0) );
		
		/* food already exists at this point */
		if( field[y * FIELDW + x] != 0 ) {
			/* do it again */
			f--;
			}
		/* point is empty */
		else {
			/* place the food */
			field[y * FIELDW + x] = 255;
			}
		}
	}

unsigned char *MakeField() {
	unsigned char *field;
	/* allocate memory */
	field = (unsigned char *)malloc( FIELDW * FIELDH * sizeof( unsigned char ) );
	assert( field );
	
	InitializeField( field );
	
	return field;
	}

struct critter_struct *Spot( struct critter_struct *critter, int x, int y ) {
	while( y < 0 ) y += FIELDH;
	while( y >= FIELDH ) y -= FIELDH;
	while( x < 0 ) x += FIELDW;
	while( x >= FIELDW ) x -= FIELDW;
	
	/* traverse entire list */
	while( critter != NULL ) {
		if( critter->x == x && critter->y == y ) return critter;
		/* next in list */
		critter = critter->next;
		}
	
	/* not found */
	return NULL;
	}

#define DONOTHING 0
#define FOODNORTH 1
#define FOODSOUTH 2
#define FOODEAST 3
#define FOODWEST 4
#define EAT 5
#define GONORTH 6
#define GOSOUTH 7
#define GOEAST 8
#define GOWEST 9
#define STORE 10
#define LOAD 11
#define GOTO 12
#define INCREMENT 13
#define SUBTRACT 14
#define GREATERTHANZERO 15
#define ENERGY 16

void TheyLive( struct critter_struct *list, unsigned char *field ) {
	int p, n, action, i, x, y;
	struct critter_struct *critter = list, *previous = NULL;
	
	assert( field );

	if( list == NULL ) return;
	
	/* traverse entire list */
	while( critter != NULL ) {
		p = critter->p; /* resume execution where it left off */
		action = 0;
		
		for( n = 0; n < 100; n++ ) {
			/* last instruction was action */
			if( action == 1 ) break;
			
			/* no more energy */
			if( critter->energy < 0 ) break;
			
			/* stay in genotype */
			if( p >= GENOTYPELENGTH ) p = 0;
			/* next instruction */
			i = critter->genotype[p];
			p++;
			/* stay in genotype */
			if( p >= GENOTYPELENGTH ) p = 0;
			
			switch( i ) {
				case DONOTHING:
					break;
				case EAT:
					/* standing on food */
					if( field[critter->y * FIELDW + critter->x] > 0 ) {
						/* eat */
						critter->energy += FOODPOTENCY;
						field[critter->y * FIELDW + critter->x] -= 1;
						critter->reg = 1;
						action = 1;
						}
					else critter->reg = 0;
					break;
				case FOODNORTH:
					x = critter->x;
					y = critter->y - 1;
					if( y < 0 ) y = FIELDH - 1;
					if( field[y * FIELDW + x] > 0 ) critter->reg = 1;
					break;
				case FOODSOUTH:
					x = critter->x;
					y = critter->y + 1;
					if( y >= FIELDH ) y = 0;
					if( field[y * FIELDW + x] > 0 ) critter->reg = 1;
					break;
				case FOODEAST:
					x = critter->x + 1;
					y = critter->y;
					if( x >= FIELDW ) x = 0;
					if( field[y * FIELDW + x] > 0 ) critter->reg = 1;
					break;
				case FOODWEST:
					x = critter->x - 1;
					y = critter->y;
					if( x < 0 ) x = FIELDW - 1;
					if( field[y * FIELDW + x] > 0 ) critter->reg = 1;
					break;
				case GONORTH:
					/* nobody above us */
					if( Spot( list, critter->x, critter->y - 1 ) == NULL ) {
						/* move up */
						critter->y -= 1;
						/* wrap around from top to bottom */
						if( critter->y < 0 ) critter->y = FIELDH - 1;
						/* moving is hard work */
						critter->energy -= 2;
						action = 1;
						}
					break;
				case GOSOUTH:
					/* nobody below us */
					if( Spot( list, critter->x, critter->y + 1 ) == NULL ) {
						/* move down */
						critter->y += 1;
						/* wrap around from bottom to top */
						if( critter->y >= FIELDH ) critter->y = 0;
						/* moving is hard work */
						critter->energy -= 2;
						action = 1;
						}
					break;
				case GOEAST:
					/* nobody to the right of us */
					if( Spot( list, critter->x + 1, critter->y ) == NULL ) {
						/* move right */
						critter->x += 1;
						/* wrap around from right to left */
						if( critter->x >= FIELDW ) critter->x = 0;
						/* moving is hard work */
						critter->energy -= 2;
						action = 1;
						}
					break;
				case GOWEST:
					/* nobody to the left of us */
					if( Spot( list, critter->x - 1, critter->y ) == NULL ) {
						/* move left */
						critter->x -= 1;
						/* wrap around from left to right */
						if( critter->x < 0 ) critter->x = FIELDW - 1;
						/* moving is hard work */
						critter->energy -= 2;
						action = 1;
						}
					break;
				case STORE:
					i = critter->genotype[p];
					p++;
					i %= BRAINMEMORYSIZE;
					critter->brainmemory[i] = critter->reg;
					break;
				case LOAD:
					i = critter->genotype[p];
					p++;
					i %= BRAINMEMORYSIZE;
					critter->reg = critter->brainmemory[i];
					break;
				case GOTO:
					p = critter->reg;
					/* stay in genotype */
					if( p < 0 ) p = 0;
					if( p >= GENOTYPELENGTH ) p = 0;
					break;
				case INCREMENT:
					critter->reg ++;
					break;
				case SUBTRACT:
					i = critter->genotype[p];
					p++;
					critter->reg -= i;
					break;
				case GREATERTHANZERO:
					if( critter->reg > 0 ) critter->reg = 1;
					break;
				case ENERGY:
					critter->reg = critter->energy;
					break;
				default:
					p++;
					break;
				}
			
			}
		
		/* remember place */
		critter->p = p;
		
		/* thinking takes energy */
		critter->energy --;
		
		/* out of energy */
		if( critter->energy < 0 ) {
			/* die (unlink from list) */
			if( previous != NULL ) previous->next = critter->next;
			/*if( ranking < 20 ) printf( "%d-0x%08X\n", ranking, critter );*/
			
			critter->rank = ranking;
			ranking --;
			}
		
		else previous = critter;
		
		/* next in list */
		critter = critter->next;
		}
	}

int main( int argc, char *argv[] ) {
	unsigned char *field;
	struct critter_struct *list, *first;
	int done, draw, rounds, recordrounds = 0;
	SDL_Surface *screen, *dogpic;
	SDL_Rect rect;
	SDL_Event event;
	
	/* command line parameters */
	if( argc != 1 ) {
		fprintf( stderr, "bluedogs - Mike Leonhard http://tamale.net\n" );
		return 1;
		}
	
	/* initialize SDL */
	if( SDL_Init( SDL_INIT_VIDEO ) < 0 ) {
		fprintf(stderr, "Couldn't initialize SDL: %s\n",SDL_GetError());
		return 2;
		}
	
	SDL_WM_SetCaption( "BlueDogs", "BlueDogs" );
	
	/* set the video mode */
	screen = SDL_SetVideoMode( 640, 480, 16, SDL_SWSURFACE );
	if( screen == NULL ) {
		fprintf( stderr,"Couldn't set video mode: %s\n", SDL_GetError() );
		SDL_Quit();
		return 3;
		}
	
	/* load the graphic */
	dogpic = IMG_Load( DOGPIC );
	if( dogpic == NULL ) {
		fprintf( stderr,"Couldn't load image, %s: %s\n", DOGPIC, SDL_GetError() );
		SDL_Quit();
		return 4;
		}
	SDL_SetColorKey( dogpic, SDL_SRCCOLORKEY, SDL_MapRGB( dogpic->format, 0xFF, 0xFF, 0xFF ) );
	
	/* prepare for game */
	field = MakeField();
	if( field == NULL ) {
		SDL_Quit();
		return 5;
		}
	list = MakeCritters( NULL );
	if( list == NULL ) {
		SDL_Quit();
		return 6;
		}
	first = list;
	
	done = 0;
	draw = 1;
	rounds = 0;
	while( !done ) {
		while( SDL_PollEvent( &event ) ) {
			switch( event.type ) {
				case SDL_QUIT:
					done = 1;
					break;
				case SDL_KEYDOWN:
				case SDL_MOUSEBUTTONDOWN:
					if( draw == 0 ) draw = 1;
					else draw = 0;
					break;
				}
			}
		
		TheyLive( first, field );
		
		/* check if first critter died */
		while( first && first->energy < 0 ) first = first->next;
		
		/* no critters alive */
		if( first == NULL ) {
			if( rounds > recordrounds ) {
				recordrounds = rounds;
				printf( "ROUNDS %d\n", rounds );
				PrintAllGenotypes( list );
				printf( "\n" );
				}
			
			InitializeField( field );
			MakeCritters( list );
			first = list;
			rounds = 0;
			}
		
		/* draw if no key is pressed */
		if( draw == 1 ) {
			SDL_FillRect( screen, NULL, SDL_MapRGB( screen->format, 0, 0, 0 ) );
			DrawField( screen, field );/**/
			DrawCritters( screen, dogpic, first );/**/
			
			SDL_UpdateRect( screen, 0, 0, 0, 0 );
			/*SDL_Delay( 20 );/**/
			}
		
		rounds ++;
		}
	
	PrintAllGenotypes( list );

	SDL_Quit();
	return 0;
	}

