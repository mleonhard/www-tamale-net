/*
critter.cc

Copyright (C) 2003
Michael Leonhard
http://tamale.net/
*/

#include <assert.h>
#include <SDL.h>
#include <stdlib.h>

#include "bluedogs.hh"

#define THINKCYCLES 32
#define FOODPOTENCY 4

#define MALE 0
#define FEMALE 1

/* vm registers */
#define REG_RESULT 0
#define REG_A 1
#define REG_B 2
#define REG_C 3
#define REG_DIRECTION 4
#define REG_ENERGY 5
#define REG_RESERVED 6
#define REG_NW    7
#define REG_N     8
#define REG_NE    9
#define REG_W    10
#define REG_SELF 11
#define REG_E    12
#define REG_SW   13
#define REG_S    14
#define REG_SE   15

/* vm instructions */
#define I_SET 0
#define I_COPYA 1
#define I_COPYB 2
#define I_COPYC 3
#define I_ADD 4
#define I_SUBTRACT 5
#define I_MUL 6
#define I_DIV 7
#define I_INC 8
#define I_EQUAL 9
#define I_GREATER 10
#define I_LESS 11
#define I_JUMP 12
#define I_REPRODUCE 13
#define I_MOVE 14
#define I_EAT 15

/* exceptions for program flow control */
class IgnoreInstruction {};
class ActionPerformed {};

Critter::Critter() {
	/* all data to safe uninitialized state */

	M_field = NULL;
	M_population = NULL;
	M_x = -1;
	M_y = -1;
	M_direction = -1;
	M_energy = -1;
	M_id = -1;
	M_birth = -1;
	M_generation = -1;
	M_p = -1;
	M_genotypeLength = -1;
	M_wait = -1;
	M_result = 0;
	M_A = 0;
	M_B = 0;
	M_C = 0;
	M_genotype = NULL;
	M_next = NULL;
	}

Critter::Critter( Field& field, int genotypeLength, int initialEnergy ) {
	assert( genotypeLength );
	assert( initialEnergy );

	/* initialize environment */
	M_field = &field;
	M_population = NULL;
	
	/* initialize metadata */
	M_id = 0;/* id is assigned by Population */
	M_birth = field.getDate();
	M_generation = 0;
	
	/* initialize VM variables */
	M_p = 0;
	M_genotypeLength = genotypeLength;
	M_wait = 0;
	M_result = 0;
	M_A = 0;
	M_B = 0;
	M_C = 0;
	
	/* allocate genotype */
	M_genotype = new unsigned char[M_genotypeLength];
	assert( M_genotype );
	
	/* initialize genotype with random instructions */
	for( int i = 0; i < M_genotypeLength; i++ ) M_genotype[i] = (unsigned char)RANDINT( 256 );
	
	/* initialize characteristics */
	M_x = field.randX();
	M_y = field.randY();
	M_direction = RANDINT( 4 );
	M_energy = initialEnergy;
	
	/* not part of a list yet */
	M_next = NULL;
	}

Critter::~Critter() {
	/*printGenotype();/**/
	/*printState();/**/
	}

void Critter::draw( Display& display ) {
	SDL_Rect& rect = M_field->cellRect( M_x, M_y );
	rect.x += rect.w / 4;
	rect.y += rect.h / 4;
	rect.w /= 2;
	rect.h /= 2;
	display.drawCell( rect, M_energy, M_energy, M_energy >> 4, M_direction );
	}

int Critter::getAge() { return M_field->getDate() - M_birth; }
unsigned char Critter::getAppearance() { return 64; }
int Critter::getDirection() { return M_direction; }
int Critter::getEnergy() { return M_energy; }
int Critter::getGeneration() { return M_generation; }
int Critter::getId() { return M_id; }
Critter* Critter::getNext() { return M_next; }

unsigned char Critter::getReg( int reg ) {
	int x = 0, y = 0;
	
	switch( reg ) {
		case REG_RESULT: return M_result;
		case REG_A: return M_A;
		case REG_B: return M_B;
		case REG_C: return M_C;
		case REG_DIRECTION: return M_direction;
		case REG_ENERGY: return (unsigned char)M_energy;
		case REG_RESERVED: throw IgnoreInstruction();
		case REG_NW:   y = -1; x = -1; break;
		case REG_N:    y = -1;         break;
		case REG_NE:   y = -1; x = +1; break;
		case REG_W:    x = -1;         break;
		case REG_SELF: return M_field->look( M_x, M_y );
		case REG_E:    x = +1;         break;
		case REG_SW:   y = +1; x = -1; break;
		case REG_S:    y = +1;         break;
		case REG_SE:   y = +1; x = +1; break;
		default:
			/* program should never reach this point */
			assert( 0 );
		}
	
	x += M_x;
	y += M_y;
	/* check for critter in location */
	Critter *critter = M_population->location( x, y );
	
	/* critter is there */
	if( critter ) return critter->getAppearance();
	
	/* no critter, get vegetation level */
	return M_field->look( x, y );
	}

void Critter::initialize( Field& field, int generation, int genotypeLength, int initialEnergy ) {
	/* initialize environment */
	M_field = &field;
	M_population = NULL;
	
	/* initialize metadata */
	M_id = 0;/* id is assigned by Population */
	M_birth = field.getDate();
	M_generation = generation;
	
	/* initialize VM variables */
	M_p = 0;
	M_genotypeLength = genotypeLength;
	M_wait = 0;
	M_result = 0;
	M_A = 0;
	M_B = 0;
	M_C = 0;
	
	/* genotype is initialized by caller */
	M_genotype = NULL;
	
	/* initialize characteristics */
	M_x = field.randX();
	M_y = field.randY();
	M_direction = RANDINT( 4 );
	M_energy = initialEnergy;
	
	/* not part of a list yet */
	M_next = NULL;
	}

int Critter::isAlive() {
	if( M_energy < 1 || M_id < 1 ) return 0;
	return 1;
	}

int Critter::isAt( int x, int y ) {
	if( M_x == x && M_y == y ) return 1;
	return 0;
	}

void Critter::linkNext( Critter* next ) {
	assert( next != this );
	/*printf( "RELINK(%d)0x%08X->0x%08X ", M_id, M_next, next );/**/
	M_next = next;
	}

void Critter::printGenotype() {
	int i;
	
	assert( M_id );
	assert( M_genotypeLength );
	assert( M_genotype );
	
	/* ID */
	printf( "CRITTER,%d(%d):", M_id, getAge() );
	
	/* GENOTYPE */
	for( i = 0; i < M_genotypeLength; i++ ) {
		printf( "%02X", M_genotype[i] );
		}
	printf( "(%d) ", M_genotypeLength );
	}

void Critter::printState() {
	printf( "CRITTER %d: %d, %d\n", M_id, M_x, M_y );
	}

void Critter::randomGenes() {
	assert( M_genotypeLength );
	assert( M_genotype == NULL );
	
	/* allocate genotype */
	M_genotype = new unsigned char[M_genotypeLength];
	assert( M_genotype );
	
	/* initialize genotype with random instructions */
	for( int i = 0; i < M_genotypeLength; i++ ) M_genotype[i] = (unsigned char)RANDINT( 256 );
	}

void Critter::reproduce( int reg ) {
	/*printf( "REPRODUCE%d ", reg );/**/
	}

void Critter::setPopulation( Population &population, int id ) {
	M_population = &population;
	M_id = id;
	}

void Critter::setReg( int reg, unsigned char val ) {
	switch( reg ) {
		case REG_RESULT: M_result = val;
		case REG_A: M_A = val; return;
		case REG_B: M_B = val; return;
		case REG_C: M_C = val; return;
		case REG_DIRECTION:
			M_direction = val & 0x03;
			return;
		case REG_RESERVED: throw IgnoreInstruction();
		default: throw IgnoreInstruction();
		}
	}

void Critter::unlinkNext() {
	Critter* newnext;
	assert( M_next );
	
	newnext = M_next->getNext();
	linkNext( newnext );
	}

void Critter::update() {
	/* sanity checks */
	assert( M_field );
	assert( M_population );
	assert( M_field->in( M_x, M_y ) );
	assert( M_direction >= 0 && M_direction < 4 );
	assert( M_energy && M_energy <= MAXENERGY );
	assert( M_id );
	assert( M_birth );
	assert( M_generation >= 0 );
	assert( M_p >= 0 );
	assert( M_genotypeLength );
	assert( M_p < M_genotypeLength );
	assert( M_genotype );
	
	/* last instruction needs a wait period */
	if( M_wait ) {
		/*printf( "?%d ", M_id );/**/
		M_wait--;
		/* waiting takes energy */
		M_energy --;
		return;
		}
		
	int i, reg, x, y;
	
	try {
		/* execute critter genes */
		for( int n = 0; n < THINKCYCLES; n++ ) {
			/* instruction code */
			i = M_genotype[M_p++];
			
			/* wrap around end of genotype to beginning */
			assert( M_p <= M_genotypeLength );
			if( M_p == M_genotypeLength ) M_p = 0;
			
			/* register is upper 4 bits */
			reg = (i & 0xF0) >> 4;
			
			/* instruction is lower 4 bits */
			i &= 0x0F;
			
			/* interpret the instruction */
			try {
				switch( i ) {
					case I_SET:
						/* save the value in the specified register */
						setReg( reg, M_genotype[M_p++] );
						break;
					case I_COPYA: M_A = getReg( reg ); break;
					case I_COPYB: M_B = getReg( reg ); break;
					case I_COPYC: M_C = getReg( reg ); break;
					case I_ADD: M_result += getReg( reg ); break;
					case I_SUBTRACT: M_result -= getReg( reg ); break;
					case I_MUL: M_result *= getReg( reg ); break;
					case I_DIV:
						/* denominator */
						x = getReg( reg );
						/* div by zero */
						if( x == 0 ) M_result = 255;
						else M_result /= x;
						break;
					case I_INC: M_result++; break;
					case I_EQUAL: M_result = (getReg( reg ) == M_result); break;
					case I_GREATER: M_result = (getReg( reg ) > M_result); break;
					case I_LESS: M_result = (getReg( reg ) < M_result); break;
					case I_JUMP:
						/* move execution forward in genotype */
						M_p = getReg( reg );
						/* wrap around to beginning of genotype */
						while( M_p >= M_genotypeLength ) M_p -= M_genotypeLength;
						break;
					case I_REPRODUCE:
						/*printf( "I_REPRODUCE(%d) ", M_id );/**/
						reproduce( reg );
						throw ActionPerformed();
					case I_MOVE:
						/* current position */
						x = M_x;
						y = M_y;
						
						/* forward position */
						switch( M_direction ) {
							case EAST: x++; break;
							case NORTH: y--; break;
							case WEST: x--; break;
							case SOUTH: y++; break;
							}
						
						/* default result */
						M_result = 0;
						
						/* destination is outside field */
						if( !M_field->in( x, y ) ) break;
						
						/* destination is occupied */
						if( M_population->location( x, y ) ) break;
						
						/* move */
						M_x = x;
						M_y = y;
						
						/* success! */
						M_result = 1;
						
						/* I_MOVE is a turn-ending instruction */
						throw ActionPerformed();
					case I_EAT:
						/* default result */
						M_result = 0;
						
						/* energy after eating */
						x = (int)M_energy + FOODPOTENCY;
						/* don't eat if it would waste */
						if( x >= MAXENERGY ) throw ActionPerformed();
						
						/* vegetation level */
						x = M_field->look( M_x, M_y );
						
						/* no food */
						if( !x ) throw ActionPerformed();
						
						/* eat */
						M_energy += FOODPOTENCY;
						M_field->foodEaten( M_x, M_y );
						
						/* success */
						M_result = 1;
						
						/* I_MOVE is a turn-ending instruction */
						throw ActionPerformed();
					default:
						/* program should never reach here */
						assert( 0 );
					}
				}
			catch (IgnoreInstruction) {};

			/* keep execution point inside genotype */
			assert( M_p <= M_genotypeLength );
			if( M_p == M_genotypeLength ) M_p = 0;

			/* dead? */
			if( !M_energy ) break;
			}
		}
	/* turn-ending instruction was executed */
	catch (ActionPerformed) {};
	
	/* thinking takes energy */
	M_energy --;
	}
