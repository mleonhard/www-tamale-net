/*
bluedogs.cc

Copyright (C) 2003
Michael Leonhard
http://tamale.net/
*/

#include <assert.h>
#include <SDL.h>
#include <SDL_image.h>
#include <time.h>

#include "bluedogs.hh"

#define NUMBERS "numbers.png"

RateCounter::RateCounter( Display& display, int x, int y, Field &field )
	 : NumberDisplay( display, x, y, 0 ) {
	printf( "RateCounter(...)\n" );
	M_field = &field;
	M_lastDate = field.getDate();
	M_lastTime = time( NULL );
	}

void RateCounter::draw() {
	/* current time */
	time_t now = time( NULL );
	
	/* new second, so update */
	if( now != M_lastTime ) {
		/* how many "days" have passed in the last second */
		int newdate = M_field->getDate();
		setVal( newdate - M_lastDate );
		
		/* save update time and date */
		M_lastTime = now;
		M_lastDate = newdate;
		}/**/
	
	NumberDisplay::draw();
	}

CritterCounter::CritterCounter( Display& display, int x, int y, Population& population )
	 : NumberDisplay( display, x, y, 0 ) {
	printf( "CritterCounter(...)\n" );
	M_last = 0;
	M_population = &population;
	}

void CritterCounter::draw() {
	int count = M_population->getCritterCount();
	/* different number of critters */
	if( M_last != count ) {
		M_last = count;
		setVal( M_last );
		}/**/
	
	NumberDisplay::draw();
	}

void NumberDisplay::draw() {
	SDL_Rect srcrect, dstrect;
	
	assert( M_display );
	assert( M_numbers );
	dstrect.x = M_rect.x;
	dstrect.y = M_rect.y;
	srcrect.y = 0;
	srcrect.w = M_numbers->w / 11;
	srcrect.h = M_numbers->h;
	
	/* draw each digit */
	int i;
	for( i = 0; i < 13 && M_digits[i] != -2; i++ ) {
		srcrect.x = (M_digits[i] + 1) * srcrect.w;
		SDL_BlitSurface( M_numbers, &srcrect, M_display->getSurface(), &dstrect );
		dstrect.x += srcrect.w;
		};
	}

int NumberDisplay::getHeight() { return M_rect.h; }
int NumberDisplay::getWidth() { return M_rect.w; }
SDL_Rect& NumberDisplay::getRect() { return M_rect; }

void NumberDisplay::move( int x, int y ) {
	assert( x >= 0 );
	assert( x < M_display->getWidth() );
	assert( y >= 0 );
	assert( y < M_display->getHeight() );
	
	M_rect.x = x;
	M_rect.y = y;
	}

NumberDisplay::NumberDisplay() {
	printf( "NumberDisplay()\n" );
	M_display = NULL;
	M_rect.x = -1;
	M_rect.y = -1;
	M_rect.w = 0;
	M_rect.h = 0;
	for( int i = 0; i < 13; i++ ) M_digits[i] = -2;
	M_numbers = NULL;
	}

NumberDisplay::NumberDisplay( Display& display, int x, int y, int val ) {
	printf( "NumberDisplay(...)\n" );
	M_display = &display;
	
	/* load the image */
	SDL_Surface *image = IMG_Load( NUMBERS );
	if( image == NULL ) {
		fprintf( stderr,"Couldn't load image, %s: %s\n", NUMBERS, SDL_GetError() );
		throw NumberDisplayInitFailure();
		return;
		}
	M_numbers = SDL_DisplayFormatAlpha( image );
	SDL_FreeSurface( image );

	move( x, y );
	setVal( val );
	}

void NumberDisplay::setVal( int newval ) {
	int i, n;
	int negative = 0;
	
	/* negative number */
	if( newval < 0 ) {
		negative = 1;
		newval = 0 - newval;
		}
	
	/* longest number: -4294967296 is 11 digits long */
	assert( newval <= 2147483647 ); /* in case int is >32 bits */
	
	n = newval;
	
	/* count digits */
	for( i = 0; i <= 13; i++ ) {
		if( n == 0 ) break;
		n /= 10;
		}
	
	assert( i < 12 );
	
	/* zero needs one digit */
	if( i == 0 ) i = 1;
	
	/* neg needs one digit too */
	if( negative ) {
		i++;
		M_digits[0] = -1;
		}
	
	/* size of rectangle */
	M_rect.w = (M_numbers->w / 11) * i;
	M_rect.h = M_numbers->h;
	
	/* end marker */
	/*printf( "M_digits[%d] = -2\n", i );/**/
	M_digits[i] = -2;
	i--;
	
	/* each digit */
	for( ; i >= 0; i-- ) {
		/*printf( "M_digits[%d] = %d %% 10 = %d\n", i, newval, newval % 10 );/**/
		M_digits[i] = newval % 10;
		newval /= 10;
		if( newval == 0 ) break;
		}
	
	/*
	printf( "Printing digits:\n" );
	for( i = 0; i < 13; i++ ) {
		printf( "M_digits[%d] = %d\n", i, M_digits[i] );
		}/**/
	}

void Display::blankRegion( SDL_Rect &rect) {
	/* draw a big black rectangle over the region */
	SDL_FillRect( M_screen, &rect, SDL_MapRGB( M_screen->format, 0, 0, 0 ) );
	}

void Display::blankScreen() {
	/* fill the entire screen with black */
	SDL_FillRect( M_screen, NULL, SDL_MapRGB( M_screen->format, 0, 0, 0 ) );
	}

Display::Display( int width, int height, int depth, const char* caption ) {
	
	assert( width );
	assert( height );
	assert( depth );
	assert( caption );
	
	/* initialize SDL */
	if( SDL_Init( SDL_INIT_VIDEO ) < 0 ) {
		fprintf(stderr, "Couldn't initialize SDL: %s\n",SDL_GetError());
		throw DisplayInitFailure();
		}
	
	/* Set window caption */
	SDL_WM_SetCaption( caption, caption );
	
	/* set the video mode */
	M_screen = SDL_SetVideoMode( width, height, depth, SDL_SWSURFACE );
	if( M_screen == NULL ) {
		fprintf( stderr,"Couldn't set video mode: %s\n", SDL_GetError() );
		SDL_Quit();
		throw DisplayVideoModeFailure();
		}
	}

Display::~Display() {
	SDL_Quit();
	}

void Display::updateScreen() {
	SDL_UpdateRect( M_screen, 0, 0, 0, 0 );
	}

void Display::drawCell( SDL_Rect& rect, int red, int blue, int green ) {
	/* draw the cell */
	SDL_FillRect( M_screen, &rect, SDL_MapRGB( M_screen->format, red, blue, green ) );
	}

void Display::drawCell( SDL_Rect& rect, int red, int blue, int green, int direction ) {
	/* draw the cell */
	SDL_FillRect( M_screen, &rect, SDL_MapRGB( M_screen->format, red, blue, green ) );
	
	/* construct the "head" pointing in right direction */
	SDL_Rect head;
	head.w = head.h = 2;
	switch( direction ) {
		case SOUTH:
			head.y = rect.y + (5*rect.h)/6 - 1;
			head.x = rect.x + (rect.w / 4);
			head.w = rect.w - (rect.w / 2);
			break;
		case NORTH:
			head.y = rect.y + (rect.h / 6);
			head.x = rect.x + (rect.w / 4);
			head.w = rect.w - (rect.w / 2);
			break;
		case EAST:
			head.x = rect.x + (5*rect.w)/6 - 1;
			head.y = rect.y + (rect.h / 4);
			head.h = rect.h - (rect.h / 2);
			break;
		case WEST:
			head.x = rect.x + (rect.w / 6);
			head.y = rect.y + (rect.h / 4);
			head.h = rect.h - (rect.h / 2);
			break;
		}
	
	/* draw the "head" */
	SDL_FillRect( M_screen, &head, SDL_MapRGB( M_screen->format, red - 0x80, blue - 0x80, green - 0x80 ) );
	}

int Display::getHeight() {
	return M_screen->h;
	}

SDL_Surface* Display::getSurface() {
	return M_screen;
	}

int Display::getWidth() {
	return M_screen->w;
	}

void Display::updateRegion( SDL_Rect &rect) {
	/* update the region on the screen */
	SDL_UpdateRect( M_screen, rect.x, rect.y, rect.w, rect.h );
	}

/*
Display::LoadPicture( const char *filename ) {
	/* load the graphic /
	dogpic = IMG_Load( DOGPIC );
	if( dogpic == NULL ) {
		fprintf( stderr,"Couldn't load image, %s: %s\n", DOGPIC, SDL_GetError() );
		SDL_Quit();
		return 4;
		}
	SDL_SetColorKey( dogpic, SDL_SRCCOLORKEY, SDL_MapRGB( dogpic->format, 0xFF, 0xFF, 0xFF ) );
	dogpic = SDL_DisplayFormatAlpha( dogpic );
	}
*/
