/* graphics.cpp
 * 
 * Copyright (C) 2003-2007 Michael Leonhard
 * http://tamale.net/bluedogs
 */

#include <algorithm>
#include <iostream>
#include <string>
#include <sstream>
#include <vector>
#include <SDL_image.h>

#include "graphics.h"

using namespace std;

#define FONT "font.png"

//////////////////////////////////////////////////////////////////////
// GraphicsError
//////////////////////////////////////////////////////////////////////

/* Default Constructor
 */
GraphicsError::GraphicsError ()
{
  M_description = "GraphicsError!";
}

/* Constructor - makes a new exception with the provided description.
 *               Prints to stderr as "GraphicsError: description\n"
 * @param description a string describing the exception
 */
GraphicsError::GraphicsError (const string& description)
{
  M_description = "GraphicsError: " + description;
}

/* Constructor - makes a new exception with the provided description strings.
 *               Prints to stderr as "GraphicsError: desc1: desc2\n"
 * @param desc1 a string describing the exception
 * @param desc2 another string describing the exception
 */
GraphicsError::GraphicsError (const string& desc1, const string& desc2)
{
  M_description = "GraphicsError: " + desc1 + ": " + desc2;
}

/* Constructor - makes a new exception with the provided description strings.
 *               Prints to stderr as "GraphicsError: d1 d2: d3\n"
 * @param desc1 a string describing the exception
 * @param desc2 another string describing the exception
 */
GraphicsError::GraphicsError (const string& d1, const string& d2, const string& d3)
{
  M_description = "GraphicsError: " + d1 + " " + d2 + ": " + d3;
}

void GraphicsError::printStdErr ()
{
  cerr << M_description << endl;
}

//////////////////////////////////////////////////////////////////////
// DisplayQuit
//////////////////////////////////////////////////////////////////////

/* Default Constructor
 */
DisplayQuit::DisplayQuit ()
{
  M_description = "DisplayQuit!";
}

//////////////////////////////////////////////////////////////////////
// Display
//////////////////////////////////////////////////////////////////////

/* getHeight - accessor
 * @return the height of the display surface, in pixels
 */
int Display::getHeight()
{
  return M_surface->h;
};

/* getSurface - accessor
   @return the display surface
 */
SDL_Surface* Display::getSurface()
{
  return M_surface;
};

/* getWidth - accessor
 * @return the width of the display surface, in pixels
 */
int Display::getWidth()
{
  return M_surface->w;
};

/* setCaption - sets the title of the window
 * @param caption a null-terminated UTF-8 string with the desired window title. 
                  This string is not modified.  It is not accessed after the
		  function returns.
 */
void Display::setCaption (const char* caption )
{
  assert(caption);
  SDL_WM_SetCaption (caption, NULL);
};

/* addWidget - adds the specified widget to the list of widgets drawn
 * @param widget a pointer to the widget to be added.  Call removeWidget()
                 before deleting the widget object that you pass here.
*/
void Display::addWidget (Displayable* widget)
{
  assert (widget);
  
  // check if the widget is already in the list
  if (find(M_widgets.begin(), M_widgets.end(), widget) != M_widgets.end())
    {
      assert (0); // widget cannot be added to a list it is already in
      return; // non-debug builds will ignore this problem
    }
  // add widget to end of list
  M_widgets.push_back (widget);
  // let the widget optimize itself for our display
  widget->optimize (M_surface);
}

/* removeWidget - removes the specified widget from the list of widgets drawn
 * @param widget a pointer to the widget to be removed
*/
void Display::removeWidget (Displayable* widget)
{
  assert (widget);
  // search for the widget
  vector<Displayable*>::iterator iter = find(M_widgets.begin(), M_widgets.end(), widget);
  // widget is not in the list
  if (iter == M_widgets.end())
    {
      assert (0); // widget cannot be removed from list where it is not present
      return; // non-debug builds will ignore this problem
    }
  // remove it
  M_widgets.erase(iter);
}

/* dispatch - finds the widget at the specified location, passes the event to it
 * @param event the event object
 * @param x the x-coordinate of the event location
 * @param y the y-coordinate of the event location
 */
void Display::dispatch (SDL_Event& event, int x, int y)
{
  vector<Displayable*>::iterator iter;
  // walk through list of widgets, front to back (newest to oldest)
  for (iter = M_widgets.begin(); iter != M_widgets.end(); iter++)
    {
      // coordinates lie in the widget's region
      if ((*iter)->inRegion (x, y))
	{
	  // dispatch the event to the widget
	  (*iter)->event (event, *this);
	  return;
	}
    }
}

/* dispatch - handles an event from SDL, dispatching to widgets if necessary
 * @param event the event to be handled
 */
void Display::dispatch (SDL_Event& event)
{
  // handle each type of event
  switch (event.type)
    {
      // user closed the window
    case SDL_QUIT:
      throw DisplayQuit();
      
      // key events go to focused widget
    case SDL_KEYDOWN:
    case SDL_KEYUP:
      if (M_focusedWidget ) M_focusedWidget->event (event, *this);
      break;
      // mouse events go to the widget under the mouse pointer
    case SDL_MOUSEBUTTONDOWN:
    case SDL_MOUSEBUTTONUP:
      dispatch (event, event.button.x, event.button.y);
      break;
    case SDL_MOUSEMOTION:
      dispatch (event, event.motion.x, event.motion.y);
      break;
      // window resize
    case SDL_VIDEORESIZE:
      // change the display size
      setVideoMode (event.resize.w, event.resize.h);
      // re-optimize all widgets
      vector<Displayable*>::iterator iter;
      for (iter = M_widgets.begin(); iter != M_widgets.end(); iter++)
	{
	  (*iter)->optimize (M_surface);
	}
      break;
    }
}

/* Constructor - initializes SDL and creates the display surface
 * @param width the desired width of the client area, in pixels
 * @param height the desired height of the client area, in pixels
 * @param caption a null-terminated UTF-8 string to set as the window title
 */
Display::Display (int width, int height, const char* caption)
{
  assert (width);
  assert (height);
  assert (caption);
  
  // initialize SDL
  if (SDL_Init (SDL_INIT_VIDEO | SDL_INIT_NOPARACHUTE ) < 0)
    {
      throw GraphicsError("Couldn't initialize SDL", SDL_GetError());
    }
  // Set window caption
  SDL_WM_SetCaption (caption, caption);
  // set the video mode
  M_surface = NULL;
  setVideoMode (width, height);
  // initially there is no focused widget
  M_focusedWidget = NULL;
}

/* Destructor - shuts down SDL
 */ 
Display::~Display() {
  cout << "~Display()" << endl;
  M_widgets.clear(); // widget objects must be destroyed by the code
		     // that created them
  SDL_Quit();// shut down SDL
}

/* CLAMP - clamps a to the interval [0,b]
 * @param a the value to be clamped
 * @param b the upper bound
 * @return 0 if a is negative, b if a>b, otherwise a
 */
#define CLAMP(a,b) ((a<0)?0:(a>b)?b:a)

/* clipRect - clips the rectangle to fit on the screen
 * @param rect the rectangle to be clipped
 * @param w the width of the screen
 * @param h the height of the screen
 * @return the rectangle clipped to the screen
 */
SDL_Rect clipRect(SDL_Rect rect, int w, int h)
{
  assert(w);
  assert(h);
  
  int x2 = rect.x + rect.w;
  int y2 = rect.y + rect.h;
  
  rect.x = CLAMP(rect.x, w);
  rect.y = CLAMP(rect.y, h);
  x2 = CLAMP(x2, w);
  y2 = CLAMP(y2, h);
  
  rect.w = x2 - rect.x;
  rect.h = y2 - rect.y;
  return rect;
}

/* draw - draws each widget, back to front, then updates the screen
 */
void Display::draw() {
  assert (M_surface);

  int num_widgets = M_widgets.size();
  SDL_Rect rects[num_widgets];
  int num_rects = 0;
  SDL_Rect const* new_rect;
  SDL_Rect temp_rect;
  
  for (int i = 0; i < num_widgets; i++)
    {
      Displayable* widget = M_widgets[i];
      new_rect = widget->draw (M_surface);
      if (new_rect)
	{
	  rects[num_rects++] = clipRect(*new_rect, M_surface->w, M_surface->h);
	}
    }
  
  if (0 < num_rects)
    {
      SDL_UpdateRects (M_surface, num_rects, rects);
    }
  
  //int ret = SDL_Flip (M_surface);
  //if (ret == -1)
  //  {
  //    throw GraphicsError("SDL_Flip failed", SDL_GetError());
  //  }
}

/* setFocus - sets the specified widget to receive keyboard input
 * @param widget the widget to receive input focus, must have been added
 */
void Display::setFocus (Displayable* widget)
{
  assert (widget);
  // search for the widget
  vector<Displayable*>::iterator iter = find(M_widgets.begin(), M_widgets.end(), widget);
  // widget is not in the list
  if (iter == M_widgets.end())
    {
      assert (0);
      return; // non-debug builds will ignore this problem
    }
  M_focusedWidget = widget;
}

/* setVideoMode - uses SDL to get a display surface of the specified dimensions
 * @param width the width of the desired display surface, in pixels
 * @param height the height of the desired display surface, in pixels
 * @throws GraphicsError if the mode cannot be set
 */
void Display::setVideoMode (int width, int height)
{
  // sanity check
  if (width < 1)
    {
      width = 1;
    }
  if (height < 1)
    {
      height = 1;
    }
  // set the video mode with the current color depth
  Uint32 flags = SDL_RESIZABLE;
  //flags |= SDL_ANYFORMAT;
  //flags |= SDL_SWSURFACE;
  //flags |= SDL_HWSURFACE;
  //flags |= SDL_ASYNCBLIT;
  //flags |= SDL_DOUBLEBUF;
  //flags |= SDL_FULLSCREEN;
  M_surface = SDL_SetVideoMode (width, height, 0, flags);
  // failure
  if (M_surface == NULL)
    {
      string sdl_error = SDL_GetError();
      SDL_Quit();
      throw GraphicsError("Couldn't set video mode", sdl_error);
    }
}

/* updateRegion - tells SDL to update the specified region of the display
 * @param rect the rectangle region on the display surface to update
 */
void Display::updateRegion (SDL_Rect &rect) {
  SDL_UpdateRect (M_surface, rect.x, rect.y, rect.w, rect.h);
}

//////////////////////////////////////////////////////////////////////
// Displayable - base class for all widgets
//////////////////////////////////////////////////////////////////////

/* Default Constructor - makes an invisible widget of no size
 */
Displayable::Displayable ()
{
  move (0, 0);
  resize (0, 0);
  M_visible = false;
}

/* Constructor - makes an invisible widget of no size, at the specified location
 * @param x the x-coordinate of the upper-left corner
 * @param y the y-coordinate of the upper-left corner
 */
Displayable::Displayable (int x, int y)
{
  move (x, y);
  resize (0, 0);
  M_visible = false;
}

/* Constructor - makes an invisible widget of the specified size and location
 * @param x the x-coordinate of the upper-left corner
 * @param y the y-coordinate of the upper-left corner
 * @param w the widget's width
 * @param h the widget's height
 */
Displayable::Displayable (int x, int y, int w, int h)
{
  move (x, y);
  resize (w, h);
  M_visible = false;
}

/* Destructor
 */
Displayable::~Displayable ()
{
  cout << "~Displayable() " << this << endl;
}

/* draw - draws the widget to the display surface
 * @param surface the display surface
 */
SDL_Rect const* Displayable::draw (SDL_Surface* surface)
{
  return NULL;
};

/* event - process an event
 * @param event the event
 * @param display the Display object where the widget is shown
 */
void Displayable::event (SDL_Event& event, Display& display)
{
};

/* getRect - accessor
 * @return gets a pointer to the widget's rect struct.  Do not modify the struct.
 */
SDL_Rect const* Displayable::getRect ()
{
  return &M_rect;
};

/* inRegion - tests if the specified coordinates lie inside the widget's area.
 *            NOTE: default inRegion always returns false!  Override this so
 *                  your subclass can receive events.
 * @param x the x-coordinate
 * @param y the y-coordinate
 * @return true if the coordinates lie inside the widget's area, otherwise false
 */
bool Displayable::inRegion (int x, int y)
{
  return false;
};

/* isVisible - checks if the widget is visible or not
 * @return true if it is visible, otherwise false
 */
bool Displayable::isVisible ()
{
  return M_visible;
};

/* move - moves the widget to the specified coordinates
 * @param x the new x-coordinate of the widget's upper-left corner
 * @param y the new y-coordinate of the widget's upper-left corner
 */
void Displayable::move (int x, int y)
{
  M_rect.x = x; M_rect.y = y;
};

/* optimize - allow the widget to optimize itself for display on the new surface
 * @param surface the new display surface
 */
void Displayable::optimize (SDL_Surface* surface)
{
};

/* resize - changes the size of the widget, if supported
 * @param w the new desired width of the widget
 * @param h the new desired height of the widget
 */
void Displayable::resize (int w, int h)
{
  M_rect.w = w; M_rect.h = h;
};

//////////////////////////////////////////////////////////////////////
// Background
//////////////////////////////////////////////////////////////////////

/* Constructor - creates a background with the desired color, or a close color
 * @param red the red component of the color, range is 0-255
 * @param blue the green component, in 0-255
 * @param blue the blue component, in 0-255
 */
Background::Background (int red, int green, int blue)
{
  setColor (red, green, blue);
  M_needsOptimize = true;
  M_visible = true;
}

/* draw - fills the entire display surface with the background color
 * @param screen the display surface on which to draw
 * @return the region updated, which is the entire display region, or NULL if
 *         nothing was drawn
 */
SDL_Rect const* Background::draw (SDL_Surface *screen)
{
  if (!M_visible)
    {
      return NULL; // invisible widgets are not drawn
    }
  if (M_needsOptimize)
    {
      optimize (screen);
    }
  SDL_FillRect (screen, NULL, M_color); // fill the entire screen with color
  return &M_rect; // update region is entire screen
}

/* getBlue - accessor
 * @return the blue component of the desired color
 */
int Background::getBlue ()
{
  return M_blue;
};

/* getGreen - accessor
 * @return the green component of the desired color
 */
int Background::getGreen ()
{
  return M_green;
};

/* getRed - accessor
 * @return the red component of the desired color
 */
int Background::getRed ()
{
  return M_red;
};

/* optimize - positions the background to cover the entire surface, finds a
 *            displayable color that is as close as possible to the desired
 *            color.
 * @param screen the display surface where we draw
 */
void Background::optimize (SDL_Surface* screen)
{
  assert (screen);
  M_color = SDL_MapRGB (screen->format, M_red, M_green, M_blue);
  move (0, 0);
  resize (screen->w, screen->h);
  M_needsOptimize = false;
}

/* setColor - sets the desired color
 * @param red the red component of the color, range is 0-255
 * @param blue the green component, in 0-255
 * @param blue the blue component, in 0-255
 */
void Background::setColor (int red, int green, int blue)
{
  M_red = red;
  M_green = green;
  M_blue = blue;
  M_needsOptimize = true;
}

//////////////////////////////////////////////////////////////////////
// Rectangle
//////////////////////////////////////////////////////////////////////

/* Constructor - makes a colored rectangle widget
 * @param left x-coordinate of the left edge of the rectangle
 * @param right x-coordinate fo the right edge
 * @param top y-coordinate of the the top edge
 * @param bottom y-coordinate of the bottom edge
 * @param red the red component of the desired color, in 0-255
 * @param green the green component
 * @param blue the blue component
 */
Rectangle::Rectangle (int left, int right, int top, int bottom, int red, int green, int blue)
  : Background (red, green, blue)
{
  move (left, top);
  resize (right - left, bottom - top);
}

/* draw - draws the widget to the display surface
 * @param screen the display surface on which to draw
 * @return the region where we just drew, or NULL if nothing was drawn
 */
SDL_Rect const* Rectangle::draw (SDL_Surface* screen)
{
  if (!M_visible)
    {
      return NULL; // invisible widgets are not drawn
    }
  if (M_needsOptimize)
    {
      optimize (screen);
    }
  SDL_FillRect (screen, &M_rect, M_color); // draw the rectangle on the screen
  return &M_rect; // return update region
}

/* optimize - finds a color that is as close as possible to the desired color
 * @param screen the display surface where we draw
 */
void Rectangle::optimize (SDL_Surface* screen)
{
  assert (screen);
  M_color = SDL_MapRGB (screen->format, M_red, M_green, M_blue);
  M_needsOptimize = false;
}

//////////////////////////////////////////////////////////////////////
// Text
//////////////////////////////////////////////////////////////////////

SDL_Rect const* Text::draw (SDL_Surface* screen)
{
  SDL_Rect srcrect, dstrect;
  
  if (!M_visible)
    {
      return NULL;  // invisible widgets are not drawn
    }
  if (M_needsOptimize)
    {
      optimize (screen);
    }
  
  assert (screen);
  assert (M_font);
  dstrect.x = M_rect.x;
  dstrect.y = M_rect.y;
  srcrect.y = 0;
  srcrect.w = M_charWidth;
  srcrect.h = M_font->h;
  
  // each digit
  for (int i = 0; i < M_text.length(); i++)
    {
      if (dstrect.x >= screen->w) // letter is completely off screen
	{
	  break;
	}
      srcrect.x = M_text[i] * M_charWidth;
      SDL_BlitSurface (M_font, &srcrect, screen, &dstrect);
      dstrect.x = dstrect.x + M_charWidth;
    };
  return &M_rect; // return update region
}

/* getText - accessor
 * @param return the text of the widget
 */
string Text::getText ()
{
  return M_text;
};

/* optimize - gets a new copy of the font image, optimized for blitting
 * @param screen the display surface to optimize for
 */
void Text::optimize (SDL_Surface* screen)
{
  assert (screen);
  assert (M_unoptimizedFont);
  
  // free old font image
  if (M_font)
    {
      SDL_FreeSurface (M_font);
    }
  
  // get a copy of the font image, with the proper pixel format so
  // blits will not require any conversion
  M_font = SDL_DisplayFormatAlpha (M_unoptimizedFont);
  assert (M_font);
  
  M_needsOptimize = false;
}

/* setText - sets the text of the widget
 * @param newText the new text of the widget
 */
void Text::setText (string newText)
{
  M_text = newText;
  // normalize string characters to range [0,127]
  for (int i = 0; i < M_text.length(); i++)
    {
      if (M_text[i] < 0)
	{
	  M_text[i] = 0;
	}
    }
  // recalculate text width
  M_rect.w = M_charWidth * M_text.length();
}

/* Constructor - creates a new text display widget
 * @param left the x-coordinate of the text widget's left edge
 * @param top the y-coordinate of the text widget's top edge
 * @param text the string to be displayed in the widget
 */
Text::Text (int left, int top, string text)
{
  // Font file is an image containing 128 ASCII glyphs of equal width:
  // ???????????????????????????????? !"#$%&'()*+,-./0123456789:;<=>?
  // @ABCDEFGHIJKLMNOPQRSTUVWXYZ[\]^_`abcdefghijklmnopqrstuvwxyz{|}~?
  
  // load the font
  M_unoptimizedFont = IMG_Load (FONT);
  if (M_unoptimizedFont == NULL)
    {
      throw GraphicsError("Couldn't load font file", FONT, SDL_GetError());
    }
  
  // font file width must be a multiple of 128
  if (M_unoptimizedFont->w % 128 != 0)
    {
      throw GraphicsError("Font file width is not a multiple of 128", FONT);
    }
  
  // font must have height
  if (M_unoptimizedFont->h < 1)
    {
      throw GraphicsError("Font file image has no height", FONT);
    }
  
  M_font = NULL; // will be set when draw() calls optimize()
  M_needsOptimize = true;
  M_visible = true;
  M_charWidth = M_unoptimizedFont->w / 128;
  // M_text starts out empty.  It is initialized by setText() below
  
  move (left, top);
  resize (0, M_unoptimizedFont->h); // width calculated by setText() below
  setText (text);
}

/* Destructor - frees the images
 */
Text::~Text() {
  cout << "~Text(\"" << M_text << "\") " << this << endl;
  SDL_FreeSurface (M_unoptimizedFont);
  M_unoptimizedFont = NULL;
  if (M_font)
    {
      SDL_FreeSurface (M_font);
    }
  M_font = NULL;
}

//////////////////////////////////////////////////////////////////////
// Check
//////////////////////////////////////////////////////////////////////

/* check - checks the box
 */
void Check::check ()
{
  setCheck (true);
}

/* uncheck - unchecks the box
 */
void Check::uncheck ()
{
  setCheck (false);
}

/* toggle - toggles the check
 */
void Check::toggle ()
{
  setCheck (!M_isChecked);
}

/* Constructor
 * @param left x-coordinate of the left edge of widget
 * @param top y-coordinate of the top edge of widget
 * @param isChecked initial state of the checkbox
 */
Check::Check (int left, int top, bool isChecked)
  : Text (left, top, "")
{
  M_isChecked = isChecked;
  render();
}

/* Constructor
 * @param left x-coordinate of the left edge of widget
 * @param top y-coordinate of the top edge of widget
 * @param isChecked initial state of the checkbox
 * @param label text to appear to the right of checkbox
 */
Check::Check (int left, int top, bool isChecked, string label)
  : Text (left, top, "")
{
  M_isChecked = isChecked;
  setLabel (label);
}

/* Destructor
 */
Check::~Check()
{
  cout << "~Check(\"" << M_label << "\", " << M_isChecked << ") ";
  cout << this << endl;
}

/* accessor
 * @return true if the box is checked, otherwise false
 */
bool Check::getIsChecked () const
{
  return M_isChecked;
}

/* getLabel - accessor
 * @return the text label
 */
string Check::getLabel () const
{
  return M_label;
}

/* setLabel - mutator
 * @param label the new text to appear to the right of the checkbox
 */
void Check::setLabel (string label)
{
  // no change
  if (M_label == label)
    {
      return;
    }
  M_label = label;
  render();
}

/* setCheck - sets the checked state of the box
 * @param isChecked the new state, true if the box is checked, otherwise false
 */
void Check::setCheck (bool isChecked)
{
  // no change
  if (isChecked == M_isChecked)
    {
      return;
    }
  // change
  M_isChecked = isChecked;
  render();
}

/* render - creates checkbox drawing codes appended with label, updates widget
 */
void Check::render()
{
  ostringstream text;
  // cleared checkbox appears in font at position 1, checked at position 2
  text << (M_isChecked ? "\2 " : "\1 ") << M_label;
  setText(text.str());
}

//////////////////////////////////////////////////////////////////////
// Number
//////////////////////////////////////////////////////////////////////

/* dec - decrements the number displayed
 */
void Number::dec ()
{
  M_number--;
  render();
}

/* inc - increments the number displayed
 */
void Number::inc ()
{
  M_number++;
  render();
}

/* Constructor
 * @param left x-coordinate of the left edge of widget
 * @param top y-coordinate of the top edge of widget
 * @param number initial number displayed
 */
Number::Number (int left, int top, int number)
  : Text (left, top, "")
{
  M_number = number;
  render();
}

/* Constructor
 * @param left x-coordinate of the left edge of widget
 * @param top y-coordinate of the top edge of widget
 * @param number initial number displayed
 * @param label text to appear before number
 */
Number::Number (int left, int top, int number, string label)
  : Text (left, top, "")
{
  M_number = number;
  setLabel (label);
}

/* Destructor
 */
Number::~Number()
{
  cout << "~Number(\"" << M_label << "\", " << M_number << ") " << this << endl;
}

/* getNumber - accessor
 * @return the number displayed
 */
int Number::getNumber ()
{
  return M_number;
};

/* getLabel - accessor
 * @return the text appearing before the number
 */
string Number::getLabel ()
{
  return M_label;
}

/* setLabel - mutator
 * @param label the new text to appear before the number
 */
void Number::setLabel (string label)
{
  // no change
  if (M_label == label)
    {
      return;
    }
  M_label = label;
  render();
}

/* setNumber - mutator
 * @param number the new number
 */
void Number::setNumber (int number)
{
  // no change
  if (number == M_number)
    {
      return;
    }
  M_number = number;
  render();
}

/* render - converts the number to text, prepends label, updates widget
 */
void Number::render()
{
  ostringstream text;
  text << M_label << M_number;
  setText(text.str());
}
