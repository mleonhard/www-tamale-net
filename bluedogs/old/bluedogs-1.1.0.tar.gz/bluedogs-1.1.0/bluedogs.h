/* bluedogs.h
 * 
 * Copyright (C) 2003-2007 Michael Leonhard
 * http://tamale.net/bluedogs
 */

#ifndef BLUEDOGS_H

#include <cassert>
#include <iomanip>
#include <iostream>
#include <SDL.h>
#include <vector>
#include <list>
#include "graphics.h"

using namespace std;

// macros
#define RANDINT(n) ((int)((float)(n) * rand() / (RAND_MAX + 1.0)))

#define EAST 0
#define NORTH 1
#define WEST 2
#define SOUTH 3

// class declarations
class Bacteria;
struct Config;
class ColorSim;
class Critter;
//class CritterCounter;
//class Display;
class Field;
class Member;
class Molecule;
//class NumberDisplay;
class Population;
//class RateCounter;
class Sim;
class View;

class ColorSim
{
private:
  list<Molecule*> M_heads;
public:
  ColorSim (Config config);
};

struct Config
{
  int field_width;
  int field_height;
  int initial_food;
  int growth_rate;
  int sprout_rate;
  int minimum_critters;
  int genotype_length;
  int initial_energy;
  int max_energy;
  int think_cycles;
  int food_potency;
  int min_split_energy;
  int split_energy_loss;
  int num_mutations;
};

class Critter
{
private:
  Critter (const Critter& rhs); // copy constructor
  const Critter& operator= (const Critter& rhs); // copy assignment operator
  
protected:
  Critter (int x, int y, int dir, int energy, vector<Uint8> genotype, const Config* config);
  Critter (const Config* config);
  Sim* M_sim;
  int M_x, M_y, M_dir, M_energy;
  unsigned int M_ip;
  Uint8 M_result, M_A, M_B, M_C;
  vector<Uint8> M_genotype;
  const Config* M_config;
/*
  Member* M_member;
  int M_id, M_birthday, M_generation;
  
*/  
  Uint8 getReg (int reg) const;
  void setReg (int reg, Uint8 val);
public:
  Critter (int energy, const Config* config);
  virtual Uint8 getAppearance () const;
  int getDirection () const;
  int getEnergy () const;
  int getX () const;
  int getY () const;
  virtual void reproduce ();
  void setPosition (int x, int y);
  void setSim (Sim* sim);
  void think ();
  void update ();
/*
  ~Critter ();
  int getAge () const;
  int getGeneration () const;
  int getId () const;
  Member* getMember () const;
  void printGenotype () const;
  void printState () const;
  void setId (int id);
*/
};

class Field
{
private:
  int M_width, M_height;
  int M_growthRate, M_sproutRate, M_sproutCounter;
  Uint8* M_food;
  Critter** M_critter;
/*
  
  Sim (const Sim& rhs); // disabled copy constructor
  const Sim& operator= (const Sim& rhs); // disabled copy assignment operator
*/
public:
  void add (Critter* critter);
  void addFood (int amount);
  Field (Config config);
  ~Field ();
  void foodEaten (int x, int y);
  Critter* getCritter (int x, int y) const;
  Uint8 getFood (int x, int y) const;
  int getHeight () const;
  int getWidth () const;
  void growFood ();
  int look (int x, int y) const;
  bool moveCritter (Critter* critter, int newX, int newY);
  int randX () const;
  int randY () const;
  void remove (Critter* criter);
  void update ();
  void verify () const;
/*
  int getCritterCount ();
  bool in (int x, int y);
  void printGenotypes ();
*/
};

class Member
{
private:
  Member* M_parent;
  vector<Member*> M_child;
  Critter* M_critter;
public:
  Member (Critter* M_critter, Member* M_parent);
  Member* getParent () const;
  Critter* getCritter () const;
  const vector<Member*> getChildren () const;
  void removeChild (Member* child);
};

class Molecule
{
private:
  float M_h, M_s;
  Critter* M_critter;
public:
  Molecule (Critter* critter);
};

class Population
{
private:
  //int M_idCount, M_maxAge, M_critterCount;
  vector<Member*> M_founder;
public:
  Population (Config config);
};

class Sim
{
private:
  int M_date, M_numCritters;
  list<Critter*> M_critters;
  
  // disabled copy constructor
  Sim (const Sim& rhs);
  // disabled copy assignment operator
  const Sim& operator= (const Sim& rhs);

public:
  Field field;
  Population pop;
  ColorSim col;
  
  void add (Critter* critter);
  int getDate () const;
  int getNumCritters () const;
  Sim (Config config);
  ~Sim ();
  void update ();
};

class Bacteria : public Critter
{
private:
  // disabled copy constructor
  Bacteria (const Bacteria& rhs);
  // disabled copy assignment operator
  const Bacteria& operator= (const Bacteria& rhs);
  
public:
  Bacteria (const Config* config);
  Bacteria (int x, int y, int dir, int energy, vector<Uint8> genotype, const Config* config);
  void reproduce ();
};

class View : public Displayable
{
private:
  Field& M_field;
  int M_cellWidth, M_cellHeight;
  Uint32 M_greenColor[256], M_bodyColor[256], M_headColor[256];
  bool M_tooSmall;
  
  View (const View& rhs);// disabled copy constructor
  const View& operator= (const View& rhs);// disabled copy assignment operator
  
  void drawCritter (SDL_Surface* surface, int x, int y, int energy, int dir);
  
public:
  SDL_Rect const* draw (SDL_Surface* surface);
  void optimize (SDL_Surface* surface);
  View (Field& field);
};

#define BLUEDOGS_H
#endif
