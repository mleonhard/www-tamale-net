/* field.cpp - Field of food and critters, main portion of simulation
 * 
 * Copyright (C) 2003-2007 Michael Leonhard
 * http://tamale.net/bluedogs
 */

#include <iostream>
#include "bluedogs.h"

#define CRITTER(x, y) M_critter[y*M_width + x]
#define FOOD(x, y) M_food[y*M_width + x]
#define IN_FIELD(x, y) (x >= 0 && x < M_width && y >= 0 && y < M_height)
#define RANDPOS() ((int)((float)(M_width*M_height)*rand() / (RAND_MAX +1.0)))

/* add - adds the critter to the field
 * @param critter the critter object to add
 */
void Field::add (Critter* critter)
{
  assert (critter);
  
  int x = critter->getX ();
  int y = critter->getY ();
  
  // needs random position
  if (-1 == x && -1 == y)
    {
      do {
	x = randX();
	y = randY();
      } while (getCritter (x, y));
      assert (IN_FIELD (x, y));
      critter->setPosition (x, y);
    }
  
  assert (IN_FIELD (x, y));
  assert (NULL == getCritter (x, y));
  CRITTER (x, y) = critter;
}

/* addFood - distributes food randomly throughout the field
 * @param amount the amount of food to distribute, must be > 0
 */
void Field::addFood (int amount)
{
  assert (M_food);
  assert (M_width > 0);
  assert (M_height > 0);
  
  // for the whole amount specified
  for(; amount > 0; amount--)
    {
      // position of new food growth
      int pos = RANDPOS();
      
      // this point not yet full grown
      if (M_food[pos] < 255)
	{
	  // grow the food
	  M_food[pos] ++;
	}
    }
}

/* Constructor
 * @param config configuration parameters
 */
Field::Field (Config config)
  : M_width (config.field_width),
    M_height (config.field_height),
    M_growthRate (config.growth_rate),
    M_sproutRate (config.sprout_rate),
    M_sproutCounter (0),
    M_food (NULL),
    M_critter (NULL)
{
  assert (M_width);
  assert (M_height);
  assert (M_growthRate >= 0);
  assert (M_sproutRate >= 0);
  
  // food
  M_food = new Uint8[M_width * M_height];
  assert (M_food);
  for (int i = 0; i < M_width * M_height; i++)
    {
      M_food[i] = 0;
    }
  addFood (config.initial_food);
  
  // critter pointers
  M_critter = new Critter*[M_width * M_height];
  assert (M_critter);
  for (int i = 0; i < M_width * M_height; i++)
    {
      M_critter[i] = NULL;
    }
}

/* Destructor - deletes all critter objects
 */
Field::~Field()
{
  // food
  assert (M_food);
  delete[] M_food;
  M_food = NULL;
  delete[] M_critter;
  M_critter = NULL;
/*
  Critter* critter;
  for (int y = 0; y < M_height; y++)
    {
      for (int x = 0; x < M_width; x++)
	{
	  critter = CRITTER (x, y);
	  if (critter)
	    {
	      assert (critter->getId());
	      assert (critter->getId() < M_idCount);
	      assert (critter->getX () == x);
	      assert (critter->getY () == y);
	      assert (critter->getEnergy ());
	      
	      remove (critter);
	      delete critter;
	    }
	}
    }
  assert (M_critterCount == 0);
*/
}

/*
int Field::food (int x, int y)
{
  assert (M_food);
  assert (M_width > 0);
  assert (M_height > 0);
  
  // coordinates are outside of field
  if (x < 0 || x >= M_width || y < 0 || y >= M_height)
    {
      return 128;
    }
  // return value of plant growth
  return (FOOD (x, y) + 15)>> 4; // to keep inside 0-15
}
*/

/* foodEaten - causes food to shrink when it has been eaten
 * @param x the x-coordinate of the cell where food was eaten
 * @param y the y-coordinate of the cell where food was eaten
 */
void Field::foodEaten (int x, int y)
{
  assert (IN_FIELD (x, y));
  assert (FOOD (x, y));
  FOOD (x, y) --;
};

/* getCritter - looks up the critter at a specified point
 * @param x the x-coordinate, must be inside the field
 * @param y the y-coordinate, must be inside the field
 * @return a pointer to the critter at that spot, or NULL if there is none
 */
Critter* Field::getCritter (int x, int y) const
{
  assert (M_critter);
  assert (M_width > 0);
  assert (M_height > 0);
  assert (IN_FIELD (x, y));
  return CRITTER (x, y);
}

/* getFood - gets the amount of food at the location
 * @param x the x-coordinate to sample
 * @param y the y-coordinate to sample
 * @return the amount of food in the cell, 0 = no food, 255 = max food
 */
Uint8 Field::getFood (int x, int y) const
{
  assert (M_food);
  assert (M_width > 0);
  assert (M_height > 0);
  assert (x >= 0);
  assert (x < M_width);
  assert (y >= 0);
  assert (y < M_height);
  return FOOD (x, y);
}

/* accessor
 * @return the height of the field, in cells
 */
int Field::getHeight () const
{
  return M_height;
};

/* accessor
 * @return the width of the field, in cells
 */
int Field::getWidth () const
{
  return M_width;
}

/* growFood - performs growth and seeding of food plants
 */
void Field::growFood()
{
  assert (M_food);
  assert (M_width > 0);
  assert (M_height > 0);
  assert (M_growthRate > 0);
  assert (M_sproutRate > 0);
  
  // start at upper left corner
  int max = M_width * M_height;
  int base = RANDINT (M_growthRate);
  for (int base = 0; base < max; base += M_growthRate)
    {
      int cell = base + RANDINT (M_growthRate);
      // this cell has a plant
      if (cell < max && M_food[cell])
	{
	  // cell is inside field, plant is not yet full grown
	  if (M_food[cell] < 255)
	    {
	      M_food[cell] ++; // grow
	    }
	  // plant is adult (>64) and time to sprout
	  if (M_food[cell] > 64 && M_sproutCounter > M_sproutRate)
	    {
	      // sprout in adjacent cell*/
	      int dx = RANDINT (3) - 1;
	      int dy = RANDINT (3) - 1;
	      int s = cell + dy*M_width + dx;
	      // spot is inside field and barren
	      if (s >= 0 && s < max && M_food[s] == 0)
		{
		  // new plant growth at spot
		  M_food[s] = 1;
		}
	      // reset counter
	      M_sproutCounter = 0;
	    }
	  M_sproutCounter++;
	}
    }
}

/* in - tests if the specified coordinates are inside the field
 * @param x the x-coordinate to test
 * @param y the y-coordinate to test
 * @return true if (x,y) lies inside the field, otherwise false
 *
bool Field::in (int x, int y)
{
  assert (M_width > 0);
  assert (M_height > 0);
  return IN_FIELD (x, y);
}

/* look - looks at the specified cell
 * @param x the x-coordinate of the cell
 * @param y the y-coordinate of the cell
 * @return the value that a critter sees when looking at the cell
 */
int Field::look (int x, int y) const
{
  assert (M_food);
  assert (M_width > 0);
  assert (M_height > 0);
  
  // outside of field
  if (!IN_FIELD(x, y))
    {
      return 128;
    }
  
  // another critter
  Critter* critter = CRITTER (x, y);
  if (critter)
    {
      return critter->getAppearance();
    }
  
  // food
  int f = FOOD (x, y);
  return (f + 15)>> 4; // range 0..15
}

/* moveCritter - tries to move the specified critter to the new location
 * @param critter the critter to move
 * @param newx the new x-coordinate of the critter
 * @param newy the new y-coordinate of the critter
 * @return true if the critter was moved, otherwise false
 */
bool Field::moveCritter (Critter* critter, int newx, int newy)
{
  assert (critter);
  int oldx = critter->getX ();
  int oldy = critter->getY ();
  assert (IN_FIELD (oldx, oldy));
  assert (CRITTER (oldx, oldy) == critter);
  
  if (!IN_FIELD (newx, newy) || CRITTER (newx, newy))
    {
      return false;
    }
  
  CRITTER (oldx, oldy) = NULL;
  critter->setPosition (newx, newy);
  CRITTER (newx, newy) = critter;
  return true;
}

/* printGenotypes - prints out the genotypes of every critter
 *
void Field::printGenotypes()
{
  for (int y = 0; y < M_height; y++)
    {
      for (int x = 0; x < M_width; x++)
	{
	  if (CRITTER (x, y))
	    {
	      CRITTER (x, y) ->printGenotype();
	    }
	}
    }
}

/* randX - get a random x-coordinate in the field
 * @return a random x-coordinate in the field
 */
int Field::randX () const
{
  return RANDINT (M_width);
};

/* randY - get a random y-coordinate in the field
 * @return a random y-coordinate in the field
 */
int Field::randY () const
{
  return RANDINT (M_height);
};

/* remove - removes the specified critter
 * @param critter the critter to remove
 */
void Field::remove (Critter* critter)
{
  assert (critter);
  int x = critter->getX ();
  int y = critter->getY ();
  assert (IN_FIELD (x, y));
  assert (CRITTER (x, y) == critter);
  CRITTER (x, y) = NULL;
}

/* update - updates the simulation food
 */
void Field::update()
{
  growFood();
  verify();
  /*  
  for (int y = 0; y < M_height; y++)
    {
      for (int x = 0; x < M_width; x++)
	{
	  Critter* critter = CRITTER (x, y);
	  if (critter)
	    {
	      assert (critter->getX () == x);
	      assert (critter->getY () == y);
	      
	      // critter is alive, give it a turn to think and act
	      if (critter->getEnergy())
		{
		  critter->update();
		}
	    }
	}
    }
  */
}

/* verify - checks the integrity of data structures
 */
void Field::verify () const
{
  assert (M_food);
/*
  int cCount = 0;
  for (int y = 0; y < M_height; y++)
    {
      for (int x = 0; x < M_width; x++)
	{
	  Critter* critter = CRITTER (x, y);
	  if (critter)
	    {
	      cCount++;
	      assert (critter->getId());
	      assert (critter->getId() < M_idCount);
	      assert (critter->getX () == x);
	      assert (critter->getY () == y);
	      assert (critter->getEnergy ());
	    }
	}
    }
  assert (cCount == M_critterCount);
*/
}
