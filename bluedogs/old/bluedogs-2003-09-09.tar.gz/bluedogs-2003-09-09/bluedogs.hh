/*
bluedogs.hh

Copyright (C) 2003
Michael Leonhard
http://tamale.net/
*/

#ifndef BLUEDOGS_H

#include "trees.hh"

/* macros */
#define RANDINT( n ) ((int)((float)(n) * rand() / (RAND_MAX + 1.0)))

#define EAST 0
#define NORTH 1
#define WEST 2
#define SOUTH 3
#define MAXENERGY 255 /* Because energy is an 8-bit register */

/* class declarations */
class Bacteria;
class Critter;
class Display;
class Field;
class RateCounter;
class CritterCounter;
class Mammal;
class NumberDisplay;
class Population;

class Critter : public ListNode {
	protected:
		/* environment */
		Field* M_field;
		/* characteristics */
		int M_direction, M_energy;
		/* metadata */
		int M_id, M_birth, M_generation;
		/* VM variables */
		int M_p, M_genotypeLength, M_wait;
		unsigned char M_result, M_A, M_B, M_C;
		unsigned char* M_genotype;
		
		/* procedures */
		unsigned char getReg( int reg );
		void setReg( int reg, unsigned char val );
	
	public:
		/* procedures */
		Critter();
		Critter( Field &field, int genotypeLength, int initialEnergy );
		~Critter();
		virtual void draw( Display& display );
		int getAge();
		virtual unsigned char getAppearance();
		int getDirection();
		int getEnergy();
		int getGeneration();
		int getId();
		bool persist();
		void printGenotype();
		void printState();
		void randomGenes();
		virtual void reproduce( int reg );
		void setId( int id );
		void update();
	};

class Bacteria : public Critter {
	private: int data;
	public:
		Bacteria( Field& field, int genotypeLength, int initialEnergy );
		Bacteria( Field& field, int x, int y, int direction, int energy, int generation, int genotypeLength, unsigned char *genotype );
		void reproduce( int reg );
	};

class Mammal : public Critter {
	private:
		int M_gender, M_partner;
	public:
		void draw( Display& display );
		unsigned char* getEgg();
		int getEggLength();
		int getGender();
		int getPartnerId();
		unsigned char* getSperm();
		int getSpermLength();
		Mammal( Field& field, int genotypeLength, int initialEnergy );
		Mammal( Field& field, int x, int y, int initialEnergy, Mammal& mother, Mammal& father );
		void mate( Mammal& partner );
		void orgasm();
		void reproduce( int reg );
	};

class Display {
	public:
		void blankRegion( SDL_Rect &rect);
		void blankScreen();
		Display( int width, int height, int depth, const char* caption );
		~Display();
		void updateScreen();
		void drawCell( SDL_Rect& rect, int red, int blue, int green );
		void drawCell( SDL_Rect& rect, int red, int blue, int green, int direction );
		int getHeight();
		SDL_Surface* getSurface();
		int getWidth();
		void updateRegion( SDL_Rect &rect );
	private:
		SDL_Surface* M_screen;
	};

class DisplayInitFailure {};
class DisplayQuit {};
class DisplayVideoModeFailure {};

class Field {
	private:
		int M_width, M_height, M_date, M_growthrate, M_growcounter;
		unsigned char* M_field;
		Display* M_display;
	public:
		void addFood( int amount );
		SDL_Rect& cellRect( int x, int y );
		void draw();
		Field( Display& display, int newwidth, int newheight, int intialfood, int growthrate );
		void foodEaten( int x, int y );
		int getDate();
		void growFood();
		int in( int x, int y );
		int look( int x, int y );
		int randX();
		int randY();
		void update();
	};

class NumberDisplay {
	protected:
		Display* M_display;
		int M_digits[13];
		SDL_Surface* M_numbers;
		SDL_Rect M_rect;
	public:
		virtual void draw();
		int getHeight();
		int getWidth();
		SDL_Rect& getRect();
		void move( int x, int y );
		NumberDisplay();
		NumberDisplay( Display& display, int x, int y, int val );
		void setVal( int newval );
	};

class NumberDisplayInitFailure {};

class RateCounter : public NumberDisplay {
	private:
		Field* M_field;
		time_t M_lastTime;
		int M_lastDate;
	public:
		void draw();
		RateCounter( Display& display, int x, int y, Field &field );
	};

class CritterCounter : public NumberDisplay {
	private:
		int M_last;
		Population* M_population;
	public:
		void draw();
		CritterCounter( Display& display, int x, int y, Population& population );
	};

class Population : public QuadNode {
	protected:
		Display* M_display;
		int M_idCount, M_maxAge;
	public:
		void add( ListNode* item );
		void checkAge( int age );
		void draw();
		void drawNode( QuadNode *node );
		Population( Display& display );
		void printGenotypes();
		void remove( Critter* critter );
		void update();
		void updateNode( QuadNode *node );
	};

class Simulation {
	private:
		time_t M_lastSecond;
		int M_mode;
		Display* M_display;
		Field* M_field;
		Population* M_population;
		int M_minCritters, M_genotypeLength, M_initialEnergy;
		
		SDL_Rect statsRect;
		RateCounter* M_rateCounter;
		CritterCounter* M_critterCounter;
	public:
		void drawStats( bool update );
		void drawSim();
		void loop();
		Simulation( Display& display, Field& field, Population& population, int mincritters, int genotypeLength, int initialEnergy );
		~Simulation();
		void userEvents();
	};

#define BLUEDOGS_H
#endif
