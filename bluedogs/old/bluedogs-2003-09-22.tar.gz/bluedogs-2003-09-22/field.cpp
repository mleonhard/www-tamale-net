/*
field.cc

Copyright (C) 2003
Michael Leonhard
http://tamale.net/
*/

#include <assert.h>
#include <SDL.h>
#include <stdlib.h>
#include <string.h>

#include "bluedogs.h"

/* TODO: consolidate SDL_MapRGB() calls for field drawing */

void Field::add( Critter* critter ) {
	assert( critter );
	
	/* give the new critter an ID */
	critter->setId( M_idCount++ );
	M_critterCount++;
	
	/* add it to the lookup table */
	int x = critter->M_x, y = critter->M_y;
	assert( in( x, y ) );
	assert( M_lookupTable[y*M_width + x] == NULL );
	M_lookupTable[y*M_width + x] = critter;
	}

void Field::addFood( int amount ) {
	int x, y;
	
	assert( amount > 0);
	assert( M_field );
	assert( M_width > 0 );
	assert( M_height > 0 );
	
	/* for the whole amount specified */
	for(; amount > 0; amount-- ) {
		/* position of new food growth */
		x = RANDINT( M_width );
		y = RANDINT( M_height );
		assert( in( x, y ) );
		
		/* this point not yet full grown */
		if( M_field[ y*M_width + x ] < 255 ) {
			/* grow the food */
			M_field[ y*M_width + x ] ++;
			}
		}
	}

void Field::drawCell( SDL_Surface* surface, int x, int y, int red, int green, int blue, int direction ) {
	assert( in( x, y ) );
	
	SDL_Rect rect;
	
	rect.w = surface->w / M_width;
	rect.h = surface->h / M_height;
	
	rect.x = rect.w * x;
	rect.y = rect.h * y;
	
	rect.x += rect.w / 4;
	rect.y += rect.h / 4;
	rect.w /= 2;
	rect.h /= 2;
	
	/* draw the cell */
	SDL_FillRect( surface, &rect, SDL_MapRGB( surface->format, red, green, blue ) );
	
	/* don't draw head if cell is smaller than 6x6 /
	if( rect.w < 6 || rect.h < 6 ) return;
	
	/* construct the "head" pointing in right direction */
	SDL_Rect head;
	head.w = head.h = 2;
	switch( direction ) {
		case SOUTH:
			head.y = rect.y + (5*rect.h)/6 - 1;
			head.x = rect.x + (rect.w / 4);
			head.w = rect.w - (rect.w / 2);
			break;
		case NORTH:
			head.y = rect.y + (rect.h / 6);
			head.x = rect.x + (rect.w / 4);
			head.w = rect.w - (rect.w / 2);
			break;
		case EAST:
			head.x = rect.x + (5*rect.w)/6 - 1;
			head.y = rect.y + (rect.h / 4);
			head.h = rect.h - (rect.h / 2);
			break;
		case WEST:
			head.x = rect.x + (rect.w / 6);
			head.y = rect.y + (rect.h / 4);
			head.h = rect.h - (rect.h / 2);
			break;
		}
	
	/* draw the "head" */
	SDL_FillRect( surface, &head, SDL_MapRGB( surface->format, 0xFF - red, 0xFF - blue, 0xFF - green ) );
	}

SDL_Rect const* Field::draw( SDL_Surface* surface ) {
	/* is not visible */
	if( !M_visible ) return NULL;

	/* drawing slow */
	if( M_drawSlow ) {
		/* not yet time to draw */
		if( SDL_GetTicks() < M_nextDraw ) return NULL;
		/* the next draw will happen at */
		M_nextDraw = SDL_GetTicks() + 1000;
		}

	/* needs optimization */
	if( M_needsOptimize ) optimize( surface );
	
	assert( surface );
	assert( M_field );
	assert( M_width > 0 );
	assert( M_height > 0 );
	
	SDL_Rect rect;
	int x, y, intensity;
	
	rect.w = surface->w / M_width;
	rect.h = surface->h / M_height;
	
	/* rows */
	rect.y = 0;
	for( y = 0; y < M_height; y++ ) {
		/* columns */
		rect.x = 0;
		for( x = 0; x < M_width; x++ ) {
			/* strength of plant growth */
			intensity = M_field[y*M_width + x];
			/* draw the space as a shade of green */
			SDL_FillRect( surface, &rect, SDL_MapRGB( surface->format, intensity >> 2, intensity, intensity >> 2 ) );
			/* next block */
			rect.x += rect.w;
			}
		/* move down one row */
		rect.y += rect.h;
		}
	
	/* draw the critters */
	Critter* critter;
	for( y = 0; y < M_height; y++ ) {
		for( x = 0; x < M_width; x++ ) {
			critter = M_lookupTable[y*M_width + x];
			if( critter ) critter->draw( surface );
			}
		}
	/* return update region */
	return &M_rect;
	}

void Field::event( SDL_Event& event, Display& display ) {
	switch( event.type ) {
		/* key is pressed */
		case SDL_KEYDOWN:
			printf( "KEYDOWN " );
			M_drawSlow = true;
			/* the next draw will happen at */
			M_nextDraw = SDL_GetTicks() + 1000; 
			fflush( stdout );
			break;
		/* key is released */
		case SDL_KEYUP:
			printf( "KEYUP " );
			M_drawSlow = false;
			fflush( stdout );
			break;
		case SDL_MOUSEBUTTONDOWN:
			printf( "BUTTONDOWN " );
			/* mouse click toggles slow mode */
			if( M_drawSlow ) M_drawSlow = false;
			else {
				M_drawSlow = true;
				/* the next draw will happen at */
				M_nextDraw = SDL_GetTicks() + 1000; 
				}
			fflush( stdout );
			break;
		}
	}

Field::Field( int newWidth, int newHeight, int initialFood, int growthRate, int sproutRate ) {
	
	/* initialize data */
	M_visible = true;
	move( 0, 0 );
	resize( 0, 0 );
	M_idCount = 1;
	M_maxAge = 0;
	assert( newWidth );
	assert( newHeight );
	assert( initialFood );
	assert( growthRate >= 0 );
	
	M_critterCount = 0;
	M_drawSlow = false;
	M_width = newWidth;
	M_height = newHeight;
	M_date = 1;
	M_growthRate = growthRate;
	M_growCounter = 0;
	M_sproutRate = sproutRate;
	M_sproutCounter = 0;
	
	/* allocate memory */
	M_field = (unsigned char *)malloc( M_width * M_height * sizeof( unsigned char ) );
	assert( M_field );
	
	/* clear field of food */
	memset( M_field, 0, M_width * M_height * sizeof( unsigned char ) );
	
	/* add the initial random food growth */
	addFood( initialFood );
	
	/* set up lookup table */
	M_lookupTable = (Critter* *)malloc( sizeof( Critter* ) * newWidth * newHeight );
	assert( M_lookupTable );
	for( int i = 0; i < newWidth * newHeight; i++ ) M_lookupTable[i] = NULL;
	}

Field::~Field() {
	Critter* critter;
	for( int y = 0; y < M_height; y++ ) {
		for( int x = 0; x < M_width; x++ ) {
			critter = M_lookupTable[y*M_width + x];
			if( critter ) {
				assert( critter->getId() );
				assert( critter->getId() < M_idCount );
				assert( critter->M_x == x );
				assert( critter->M_y == y );
				assert( critter->M_energy > 0 );
				remove( critter );
				}
			}
		}
	assert( M_critterCount == 0 );
	}

int Field::food( int x, int y ) {
	assert( M_field );
	assert( M_width > 0 );
	assert( M_height > 0 );
	
	/* coordinates are outside of field */
	if( x < 0 || x >= M_width || y < 0 || y >= M_height ) return 128;
	/* return value of plant growth */
	return (M_field[ y*M_width + x] + 15)>> 4; /* to keep inside 0-15 */
	}

void Field::foodEaten( int x, int y ) {
	assert( in( x, y ) );
	assert( M_field[ y*M_width + x ] );
	M_field[ y*M_width + x ] --;
	};

int Field::getDate() {
	return M_date;
	}

void Field::growFood() {
	assert( M_field );
	assert( M_width > 0 );
	assert( M_height > 0 );
	
	/* start at upper left corner */
	int max = M_width * M_height;
	int cell = RANDINT( M_growthRate );
	int sprout = 0;
	
	while( cell < max ) {
		/* this point has plants */
		if( M_field[cell] ) {
			 /* plants are not yet full grown */
			 if( M_field[cell] < 255 ) M_field[cell] ++;
			 /* plant is adult (>64) */
			 if( M_field[cell] > 64 ) {
				/* sprout once every M_sproutRate */
				if( M_sproutCounter == M_sproutRate ) {
				 	/* sprout in adjacent cell*/
					sprout = cell + (RANDINT( 3 ) - 1)*M_width + RANDINT( 3 ) - 1;
					/* spot is inside field and empty */
					if( sprout < max && M_field[sprout] == 0 ) {
						/* new plant growth at spot */
						M_field[sprout] = 1;
						}
					}
				else if( M_sproutCounter <= M_sproutRate ) M_sproutCounter++;
				else assert( 0 );
				}
			}
				
		
		/* move on */
		cell += RANDINT( M_growthRate );
		}
	}

int Field::in( int x, int y ) {
	assert( M_field );
	assert( M_width > 0 );
	assert( M_height > 0 );
	
	/* coordinates are outside of field */
	if( x < 0 || x >= M_width || y < 0 || y >= M_height ) return 0;
	/* inside */
	else return 1;
	}

Critter* Field::location( int x, int y ) {
	/* coordinates are not in this field */
	if( !in( x, y ) ) return NULL;
	return M_lookupTable[y*M_width + x];
	}

int Field::look( int x, int y ) {
	assert( M_field );
	assert( M_width > 0 );
	assert( M_height > 0 );
	
	/* coordinates are outside of field */
	if( x < 0 || x >= M_width || y < 0 || y >= M_height ) return 128;
	/* critter is at that spot */
	if( M_lookupTable[y*M_width + x] != NULL ) return 64;
	/* return value of plant growth */
	return (M_field[ y*M_width + x] + 15)>> 4; /* to keep inside 0-15 */
	}

void Field::optimize( SDL_Surface* screen ) {
	assert( screen );
	move( 0, 0 );
	resize( screen->w, screen->h );
	M_needsOptimize = false;
	}

void Field::printGenotypes() {
	for( int y = 0; y < M_height; y++ ) {
		for( int x = 0; x < M_width; x++ ) {
			if( M_lookupTable[y*M_width + x] ) M_lookupTable[y*M_width + x]->printGenotype();
			}
		}
	}

int Field::randX() { return RANDINT( M_width ); };
int Field::randY() { return RANDINT( M_height ); };

void Field::relocate( Critter* critter, int newx, int newy ) {
	assert( critter );
	int x = critter->M_x, y = critter->M_y;
	assert( in( x, y ) );
	assert( M_lookupTable[y*M_width + x] == critter );
	M_lookupTable[y*M_width + x] = NULL;
	
	/* add it to the lookup table */
	assert( in( newx, newy ) );
	assert( M_lookupTable[newy*M_width + newx] == NULL );
	M_lookupTable[newy*M_width + newx] = critter;
	}

void Field::remove( Critter* critter ) {
	assert( critter );
	assert( critter->getId() );
	assert( critter->getId() < M_idCount );
	
	int x = critter->M_x, y = critter->M_y;
	assert( in( x, y ) );
	assert( M_lookupTable[y*M_width + x] == critter );
	M_lookupTable[y*M_width + x] = NULL;
	delete critter;
	assert( M_critterCount >= 0 );
	M_critterCount--;
	}

void Field::update() {
	/* time passes */
	M_date++;
	
	/* grow the food */
	growFood();
	
	/* let the critters move */
	Critter* critter;
	int x, y;
	for( y = 0; y < M_height; y++ ) {
		for( x = 0; x < M_width; x++ ) {
			critter = M_lookupTable[y*M_width + x];
			if( critter ) {
				assert( critter->getId() );
				assert( critter->getId() < M_idCount );
				assert( critter->M_x == x );
				assert( critter->M_y == y );
				if( critter->M_energy ) critter->update();
				if( critter->M_energy < 1 ) remove( critter );
				}
			}
		}
	
	int cCount = 0;
	for( y = 0; y < M_height; y++ ) {
		for( x = 0; x < M_width; x++ ) {
			critter = M_lookupTable[y*M_width + x];
			if( critter ) {
				cCount++;
				assert( critter->getId() );
				assert( critter->getId() < M_idCount );
				assert( critter->M_x == x );
				assert( critter->M_y == y );
				assert( critter->M_energy > 0 );
				}
			}
		}
	assert( cCount == M_critterCount );
	}
