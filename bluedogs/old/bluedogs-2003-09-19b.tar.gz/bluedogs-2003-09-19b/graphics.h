/*
 * graphics.hpp
 * 
 * Copyright (C) 2003
 * Michael Leonhard
 * http://tamale.net/
*/

#ifndef GRAPHICS_H

#include <SDL.h>

/* TODO:
 *	return descriptive text with exceptions
 *	implement Display::raise( Displayable &widget )
 *	make updates more efficient (so only what has changed must be updated)
 *
*/

/* classes */
class Display;
class Displayable;
class Background;
class Text;
class Number;
class Rectangle;

/* instantiate this class to handle the display */
class Display {
	protected:
		SDL_Surface* M_surface;
		Displayable** M_widgetList;
		int M_widgetListLength, M_numWidgets;
		Displayable* M_focusedWidget;
	public:
		void addWidget( Displayable* widget );
		void dispatch( SDL_Event& event );
		void dispatch( SDL_Event& event, int x, int y );
		Display( int width, int height, int depth, const char* caption );
		~Display();
		void draw();
		int getHeight() { return M_surface->h; };
		SDL_Surface* getSurface() { return M_surface; };
		int getWidth() { return M_surface->w; };
		void setCaption( const char* caption ) { SDL_WM_SetCaption( caption, NULL ); };
		void setFocus( Displayable* widget );
		void updateRegion( SDL_Rect &rect );
	};
class DisplayError {};
class DisplayInitFailure : public DisplayError {};
class DisplayQuit : public DisplayError {};
class DisplayVideoModeFailure : public DisplayError {};

/* Make your widgets inherit from this class */
class Displayable {
	protected:
		bool M_visible;
	public:
		Displayable() { M_visible = false; };
		virtual void draw( SDL_Surface* surface ) {};
		virtual void event( SDL_Event& event, Display& display ) {};
		virtual bool in( int x, int y ) { return false; };
		bool isVisible() { return M_visible; };
	};
class DisplayableInitFailure {};


/*************** Widgets ****************/

class Background : public Displayable {
	protected:
		int M_red, M_green, M_blue; /* color of the background */
	public:
		Background( int red, int green, int blue );
		virtual void draw( SDL_Surface* screen );
		int getBlue() { return M_blue; };
		int getGreen() { return M_green; };
		int getRed() { return M_red; };
		void setColor( int red, int green, int blue );
	};
class BackgroundInitFailure : public DisplayableInitFailure {};

class Text : public Displayable {
	protected:
		char* M_text;
		SDL_Surface* M_font;
		int M_charWidth;
		SDL_Rect M_rect;
	public:
		Text( int left, int top, const char* text );
		void draw( SDL_Surface* screen );
		const SDL_Rect* getRect() { return &M_rect; };
		const char* getText() { return M_text; };
		void setText( const char* text );
		void move( int left, int top );
	};
class TextInitFailure : public DisplayableInitFailure {};

class Number : public Text {
	protected:
		int M_number;
	public:
		Number( int left, int top, int number );
		int getNumber();
		int setNumber( int number );
	};
class NumberInitFailure : public TextInitFailure {};

class Rectangle : public Background {
	protected:
		SDL_Rect M_rect;
	public:
		Rectangle( int left, int right, int top, int bottom, int red, int green, int blue );
		void draw( SDL_Surface* screen );
		const SDL_Rect* getRect() { return &M_rect; };
		void move( int left, int right, int top, int bottom );
	};
class RectangleInitFailure : public DisplayableInitFailure {};

#define GRAPHICS_H
#endif
