/*
critter.cc

Copyright (C) 2003
Michael Leonhard
http://tamale.net/
*/

#include <assert.h>
#include <SDL.h>
#include <stdlib.h>

#include "bluedogs.h"

#define MINSPLITENERGY 96
#define SPLITENERGYLOSS 32
#define RANDGENES 4

Bacteria::Bacteria( Field& field, int genotypeLength, int initialEnergy )
	: Critter( field, genotypeLength, initialEnergy ) {
	}

Bacteria::Bacteria( Field& field, int x, int y, int direction, int energy, int generation, int genotypeLength, unsigned char *genotype ) 
	 : Critter() {
	assert( field.in( x, y ) );
	assert( direction >= 0 && direction < 4 );
	assert( energy >= 0 );
	assert( generation );
	assert( genotypeLength );
	assert( genotype );
	
	/* initialize environment */
	M_field = &field;
	
	/* initialize metadata */
	M_birth = field.getDate();
	M_generation = generation;
	
	/* initialize VM variables */
	M_p = 0;
	M_genotypeLength = genotypeLength;
	M_wait = 0;
	M_result = 0;
	M_A = 0;
	M_B = 0;
	M_C = 0;
	
	/* allocate genotype */
	M_genotype = new unsigned char[M_genotypeLength];
	assert( M_genotype );
	
	/* initialize genotype with twin's genes */
	int i;
	for( i = 0; i < M_genotypeLength; i++ ) M_genotype[i] = genotype[i];
	
	/* randomize genes */
	for( int r = 0; r < RANDGENES; r++ ) {
		i = RANDINT( M_genotypeLength );
		assert( i < M_genotypeLength );
		M_genotype[i] = RANDINT( 256 );
		}
	
	/* initialize characteristics */
	move( x, y );
	M_direction = direction;
	M_energy = energy;
	}

void Bacteria::reproduce( int reg ) {
	/* sanity checks */
	assert( M_field );
	assert( M_field->in( getX(), getY() ) );
	assert( M_direction >= 0 && M_direction < 4 );
	assert( M_energy >= 0&& M_energy <= MAXENERGY );
	assert( M_id );
	assert( M_birth );
	assert( M_generation >= 0 );
	assert( M_p >= 0 );
	assert( M_genotypeLength );
	assert( M_p < M_genotypeLength );
	assert( M_genotype );
	
	assert( reg >= 0 && reg < 16 );
	
	/* default result */
	M_result = 0;
	
	/* not enough energy */
	if( M_energy < MINSPLITENERGY ) return;
	
	/* current position */
	int x = getX(), y = getY();
	
	/* forward position */
	switch( M_direction ) {
		case EAST: x++; break;;
		case NORTH: y--; break;
		case WEST: x--; break;
		case SOUTH: y++; break;
		}
	
	/* destination is outside field */
	if( !M_field->in( x, y ) ) return;
	
	/* destination is occupied */
	if( location( x, y ) ) return;
	
	/* twin's position */
	int tx = getX(), ty = getY();
	
	/* twin's direction (opposite) */
	int td = M_direction ^ 2;
	
	/* move mother forward */
	move( x, y );
	
	/* split */
	M_energy -= SPLITENERGYLOSS;
	Bacteria* twin;
	twin = new Bacteria( *M_field, tx, ty, td, M_energy / 2, M_generation + 1, M_genotypeLength, M_genotype );
	M_energy /= 2;
	twin->joinQuad( getQuad() );
	
	/*printf( "SPLIT%d->%d(%d) ", M_id, twin->getId(), M_generation + 1 );/**/
	
	/* success! */
	M_result = 1;
	
/*	partner.printGenotype();
	partner.printState();
	printGenotype();
	printState();
	child->printGenotype();
	child->printState();/**/
	}
