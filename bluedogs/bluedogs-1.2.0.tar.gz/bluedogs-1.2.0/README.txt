Bluedogs
Copyright (C) 2003-2007 Michael Leonhard
http://tamale.net/

For license information disclaimer of warranty, see the file LICENSE.txt.

= TODO =
 * Change const Config* to const Config&
 * use automake to build on unix
 * Document classes in JavaDoc format
 * Make into a screensaver - suggestion by Kuril in #hcoop@EFNet
 * Make an animated GIF for the webpage, mpeg
 * Use LINT to find inconsistencies in code and formatting
 * Add dynamic coloring of populations based on ancestry
   * Search web for algorithm!
   * Investigate algorithm with these properties:
     * whole color range is utilized
     * no sudden change of color for a group
     * similar groups have similar color
   * Potential algorithm:
     * Triangular space represents color space, each corner is a primary color (RGB)
     * Each simulation individual also exists in the color space
     * The individual's color is determined by its distance from the three corners
     * Each individual exerts pressure on neighbors and can move to relieve pressure
     * Pressure exerted on neighbors is determined by distance in ancestral tree
     * Close cousins exert negative pressure, adhering to one another
     * Walls of space exert no pressure - there will be surface tension!
       * tweak space so surface tension improves color choices
       * maybe have walls representing basic colors
     * Or have islands representing basic colors
       * large populations will tend to glom onto them
       * intermediate space will be mild colored
       * edges of space will be gradually repulsive
       * many islands means many easily distinguishable populations
       * find a good way to choose the island colors
     * Or have no walls - make color space spherical, toroidal, circular, square (CMYK)
     * Iterate the color space simulation not as frequently as the main sim
     * New children appear next to parent
     * Use floating point positions
     * MAYBE add slight jitter to destination after movement, allows breakaway from wall
     * Collision detection is expensive!  Make sure it's not necessary.
     * How to find neighbors:
       * use a grid, search closest 4 cells
       * quad trees
   * Indicate critter strength with brightness of head marker
 * Add on-screen statistics and scrolling graphs:
	* Total amount of food
	* Average age of critters
	* Population Size
 * implement bacteria-like gene exchange
 * Load & Save simulation state from sequentially named files
 * Dump running simulation data to stdout
 * enhance Population class to keep geneologies (on disk)
 * write program to extract data from geneologies
 * Add sexual reproduction, rewrite whole program :P
 * Add potent inRegion to Displayable, bool M_canReceiveEvents

= DONE =
Version 1.2:
 * The colors look great! :D
 * Removed config data from Field, now using M_config->
 * Removed cached critter head colors from View
 * ColorSim draws its round background with SDL_gfxPrimitives from SDL_gfx by
   Andreas Schiffler, http://www.ferzkopp.net/joomla/content/view/19/14/
 * Created DrawColorSim to show the placement of molecules
 * Now View displays each critter with its molecule's color
 * ColorSim keeps a molecule for every critter, position determines color
 * Wrote function that determines how closely two critters are related
 * Wrote code to prune and contract population tree
Version 1.1:
 * Prepared class structure for addition of family tree and dynamic coloring
 * Added checkbox to main screen with "draw every day" label.  USABILITY!
 * Make checkbox class with label
 * Sim now handles creature updates and death, using linked list
 * Split Sim into Sim & Field classes
 * Replace constants with passed parameter
 * Field::M_food is now deleted properly with delete[] M_food
   See: http://www.matasano.com/log/663/
 * Fixed error in growFood() where first cells didn't grow as fast as others
Version 1.0:
 * Created LICENSE file with the "MIT License"
 * Created Makefile for building on unix.  Thanks to Orborde in
   ##crypto@freenode for help with this.
 * Double-check object deletions, make sure it happens only once
 * Document methods in JavaDoc format
 * Click on rate printout to switch between fast and slow rendering
 * Added faint black background to font
 * Added disabled copy constructors to Critter, Bacteria, and Field.  All
   classes which are unsafe for default copy constructors are now protected.
 * Check passing of objects, make sure that objects are passed by pointer or
   reference, not by value
 * Add constructors and destructors
 * Rewrite README file
 * Move accessors out of header file
 * Fixed filenames in headers
 * Updated copyright in headers
 * Created build.bat, now I can build in emacs on Windows
 * Imported into cvs
Dated Versions 2003-2005:
 * Made proper display model
 * removed quad trees and replaced with big array of pointers
 * Create text display class that has full alphabet, numbers, and symbols
 * implement bacteria-like reproduction (splitting... mitosis?)
 * implement sexual reproduction
 * Fixed Makefile compiler options to disable assertions -DNDEBUG
 * Critter now inherits from ListNode
 * Population now inherits from QuadNode, reduced lookup from O(N) to O(log N)?
 * Implemented linked list class, ListNode (in trees.cc and trees.hh)
 * Implemented Quad-Tree class, QuadNode (in trees.cc and trees.hh)
 * Add on-screen statistics:
	* Date
	* FPS (cycles per second)
	* Number of living critters
 * Make Critter class easily extended (for BlueDog, Predator, etc.)
 * Weed out unneeded inclusions from each file
 * Encapsulate all code in classes
 * Learn C++ Exception syntax and implement it with SDL class
 * Change display of bluedogs to blue boxes with arrows for direction
     (it turns out to just be a bar for the head)


= Building =

Bluedogs is written in C++.  It was developed on Windows XP with Emacs 21.3
and g++ 3.4.2.  Required libraries:
 * SDL 1.2.11 (probably any 1.2.x version will work)
 * SDL_image 1.2.5 with PNG support

== Building on Linux ==

Install SDL 1.2.11 and SDL_image 1.2.5

make && ./bluedogs

== Building on Windows ==

Install DevC++ 5 beta 9 (version 4.9.9.2) from
http://sourceforge.net/projects/dev-cpp/
 * Install to C:\DevCpp
 * Add C:\DevCpp\bin to your PATH

Install SDL 1.2 http://libsdl.org/download-1.2.php
 * Download SDL-devel-1.2.11-mingw32.tar.gz
 * Extract as C:\DevCpp\SDL-1.2.11

Install SDL_image 1.2 from http://www.libsdl.org/projects/SDL_image/
 * Download SDL_image-devel-1.2.5-VC6.zip
 * Extract as C:\DevCpp\SDL_image-1.2.5

If necessary, fix the paths in Makefile.win.

make -f Makefile.win
bluedogs.exe

Note that the SDLmain library redirects stdout to stdout.txt and
stderr to stderr.txt.  So when you run bluedogs.exe, these files are
automatically overwritten.

= GUI commands =

Click on the simulation to toggle fast/slow display updates:

 * fast updates: the on-screen view of the simulation is updated in
real-time with the progress of the simulation.  This slows down the
simulation a lot.

 * slow updates: the on-screen view is updated once a second.  This
allows the simulation to run very quickly.


= Virtual Machine =

BlueDogs are virtual animals.  Each animal's behavior is determined by
a short program running in a virtual machine.  The instructions are called the genotype.

  Each instruction is one 8-bit byte.  The lowest 4 bits
are the instruction type, and the high bits indicate a register
parameter.  

The instructions are executed in a virtual machine.  Each
animal's virtual machine has 16 registers.  Registers store an 8-bit
unsigned integer value.

== Registers ==

The virtual machine contains 16 registers.  Each register can store an
8-bit unsigned integer value.  The registers facilitate computation
and awareness of the animal's body and the simulation field.

Reg0 Result: the result of each instruction goes into this register

Reg1 Register A: general purpose registers
Reg2 Register B
Reg3 Register C
    
Reg4 Direction: the direction that the animal is facing.  East=0,
Nort=1, West=2, South=3.  The animal can turn itself by setting the
value of this register.  When setting this register, the upper 6 bits
are discarded.  Only the lower 2 bits are saved.

Reg5 Energy: this read-only register indicates how much energy the
animal has.  The animal consumes energy every day.  Some actions, such
as moving and reproducing, consume extra energy.  An animal that runs
out of energy dies and is removed from the simulation.  Animals
increase their energy by eating food.

Reg6 Reserved

Reg7,8,9,10,11,12,13,14,15 Vision: these read-only registers allow the
animal to look down at the space it occupies and also to neighboring
spaces.  The value read from a vision register depends on the contents
of that space in the simulation field:
 * 0 nothing
 * 1-15 food of various quantities
 * 64 another animal
 * 128 a barrier, like the edge of the field

The registers form a 3x3 matrix, centered on the animal's square:

   7  8  9

  10 11 12

  13 14 15

The amount of food under the animal's feet is available in Reg11.
Reg12 has the contents of the square to the animal's right.  Reg10 is
the animal's left, and so on.

== Instruction Listing ==

0 SET x - copy the byte after the instruction into register x
1 COPYA x - copy the value in register x into RegA
2 COPYB x - copy the value in register x into RegB
3 COPYC x - copy the value in register x into RegC

4 ADD x - add the value in register x to Reg0
5 SUBTRACT x - subtract the value in register x from Reg0
6 MUL x - multiply Reg0 by the value in register x
7 DIV x - divide Reg0 by register x; div by zero is 255
8 INC x - increment the value in register x

9 EQUAL x - if x and Reg0 are equal then Reg0 = 1, else Reg0 = 0
10 GREATER x - if register x > Reg0 then Reg0 = 1, else 0
11 LESS x - if register x < Reg0 then Reg0 = 1, else 0

12 JUMP x - move the instruction pointer to address stored in register x

Actions actions (result is 1 for success, 0 for failure)
13 BREED - the animal tries to reproduce.  If this fails then Reg0=0.
           Success is indicated by Reg0=1.  This instruction uses extra
           energy.
14 MOVE - move forward
15 EAT - if the dog is standing on food, then it eats some
