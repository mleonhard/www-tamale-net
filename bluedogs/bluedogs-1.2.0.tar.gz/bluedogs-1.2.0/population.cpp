/* population.cpp
 * 
 * Copyright (C) 2003-2007 Michael Leonhard
 * http://tamale.net/bluedogs
*/

#include "bluedogs.h"

/* add - adds the founder critter to the simulation
 * @param critter the critter object to add
 */
void Population::add (Critter* critter)
{
  assert (critter);
  Member* member = new Member (critter);
  critter->setMember (member);
  M_founder.push_back (member);
}

/* add - adds the descendent critter to the simulation
 * @param critter the critter object to add
 * @param parent the critter's parent object, may be NULL
 * @throws GraphicsError if the tree height overflows Uint32
 */
void Population::add (Critter* critter, Critter* parent)
{
  assert (critter);
  assert (parent);
  Member* member = new Member (critter);
  critter->setMember (member);
  Member* parentMember = parent->getMember ();
  assert (parentMember);
  member->setParent (parentMember);
  parentMember->addChild (member);
  Uint32 parentDepth = parentMember->getDepth ();
  Uint32 depth = parentDepth + 1;
  // the sim is limited to the number of generations that fit in Uint32
  if (depth < parentDepth)
    {
      throw GraphicsError ("Reached maximum height of geneology tree.");
    }
  member->setDepth (depth);
}

/* contract - contracts single-child dead descendent nodes with parents
 * @param node the node to try to contract
 */
void Population::contract (Member* node)
{
  while (node && !node->getCritter() && 1==node->getChildCount() && node->getParent())
    {
      Member* parent = node->getParent ();
      // move child to parent
      Member* child = node->getChildren().front();
      parent->addChild (child);
      child->setParent (parent);
      // remove this node from tree
      parent->removeChild (node);
      node->setParent (NULL);
      delete node;
      // try to contract parent
      node = parent;
    }
}

/* getDistance - calculates the distance of the critters in the family tree
 * @param critA the first critter
 * @param critB the second critter
 * @return the sum of the distance up the family tree to a common ancestor
 */
double Population::getDistance (Critter* critA, Critter* critB)
{
  assert (critA);
  assert (critB);
  Member* A = critA->getMember ();
  Member* B = critB->getMember ();
  assert (A);
  assert (B);
  Member* ancestorA = A->getParent ();
  Member* ancestorB = B->getParent ();
  assert (ancestorA);
  assert (ancestorB);
  // walk up tree from both critters, stop when both paths meet.
  while (ancestorA != ancestorB)
    {
      if (ancestorA)
	{
	  ancestorA = ancestorA->getParent ();
	}
      if (ancestorB)
	{
	  ancestorB = ancestorB->getParent ();
	}
    }
  // find the vertical distance walked
  double dist = (double)A->getDepth () + (double)B->getDepth();
  if (ancestorA)
    {
      dist -= 2.0*((double)ancestorA->getDepth());
    }
  return dist;
}

/* Constructor - creates an empty population tree
 * @param config the simulation parameters
 */
Population::Population (const Config* config)
{
}

/* prune - removes a dead leaf and branches
 * @param node the leaf node to be pruned
 * @return the node where pruning stopped, or NULL
 */
Member* Population::prune (Member* node)
{
  while (node && !node->getCritter() && node->getChildren().empty())
    {
      Member* parent = node->getParent ();
      if (parent) // descendent
	{
	  parent->removeChild (node);
	  node->setParent (NULL);
	}
      else // founder
	{
	  removeFounder (node);
	}
      // no longer part of tree
      delete node;
      // try to prune parent
      node = parent;
    }
  return node;
}

/* remove - removes a dead critter from the population
 * @param critter the critter that has died and must be removed
 */
void Population::remove (Critter* critter)
{
  assert (critter);
  Member* member = critter->getMember ();
  assert (member);
  assert (member->getCritter () == critter);
  member->setCritter (NULL);
  critter->setMember (NULL);
  contract (prune (member));
}

/* removeFounder - removes the member from the founder list
 * @param member the founder to be removed
 */
void Population::removeFounder (Member* member)
{
  for (list<Member*>::iterator i = M_founder.begin(); i != M_founder.end(); i++)
    {
      // remove this member
      if (*i == member)
	{
	  M_founder.erase (i);
	  return;
	}
    }
  assert (0); // not found
}

/* verifyBranch - recursively checks the integrity of the branch
 * @param m the head of the branch to check
 */
void Population::verifyBranch (Member* m) const
{
  assert (m);
  // check critter->member
  if (m->getCritter ())
    {
      assert (m->getCritter ()->getMember () == m);
    }
  // check children
  list<Member*> children = m->getChildren ();
  for (list<Member*>::iterator c = children.begin (); c != children.end (); c++)
    {
      Member* child = *c;
      assert (child);
      assert (child->getParent () == m);
      assert (m->getDepth () < child->getDepth ());
      verifyBranch (child);
    }
}

/* verify - checks the integrity of the tree
 */
void Population::verify () const
{
  for (list<Member*>::const_iterator f = M_founder.begin(); f != M_founder.end(); f++)
    {
      Member* founder = *f;
      assert (founder);
      assert (NULL == founder->getParent ());
      verifyBranch (founder);
    }
}

/*
//What's wrong with this code?
void Population::verify () const
{
  return;
  // check NULL <- founder pointers
  for (list<Member*>::const_iterator f = M_founder.begin(); f != M_founder.end(); f++)
    {
      Member* founder = *f;
      assert (founder);
      assert (NULL == founder->getParent ());
    }
  // start breadth-first-search with founders
  list<Member*> toVerify (M_founder);
  // do the search
  while (!toVerify.empty ())
    {
      Member* m = toVerify.front ();
      toVerify.pop_front ();
      assert (m);
      if (m->getCritter ())
	{
	  assert (m->getCritter ()->getMember () == m);
	}
      list<Member*> c (m->getChildren ());
      // check parent <- child pointer and depths
      for (list<Member*>::iterator i = c.begin (); i != c.end (); i++)
	{
	  Member* child = *i;
	  assert (child);
	  assert (child->getParent () == m);
	  assert (m->getDepth () < child->getDepth ());
	}
      // add children to the queue
      toVerify.splice (toVerify.end(), c);
    }  
}*/

/*********************************************************************
 * Member
 *********************************************************************/

/* addChild - adds the specified child
 * @param child the child to be added
 */
void Member::addChild (Member* child)
{
  assert (child);
  M_child.push_back (child);
}

/* Constructor
 * @param critter the critter represented by this family member object
 */
Member::Member (Critter* critter)
  : M_critter (critter),
    M_parent (NULL),
    M_depth (0)
{
  assert (critter);
}

/* Accessor
 * @return the number of children
 */
int Member::getChildCount () const
{
  return M_child.size();
}

/* Accessor
 * @return the member objects of the children of the critter
 */
const list<Member*> Member::getChildren () const
{
  return M_child;
}

/* Accessor
 * @return the critter represented by this member object
 */
Critter* Member::getCritter () const
{
  return M_critter;
}

/* Accessor
 * @return the object's depth in the geneology tree
 */
Uint32 Member::getDepth () const
{
  return M_depth;
}

/* Accessor
 * @return the parent's member object, or NULL if the critter is a founder
 */
Member* Member::getParent () const
{
  return M_parent;
}

/* removeChild - removes the specified child
 * @param child the child to remove
 */
void Member::removeChild (Member* child)
{
  for (list<Member*>::iterator i = M_child.begin (); i != M_child.end (); i++)
    {
      // remove this child
      if (*i == child)
	{
	  M_child.erase (i);
	  return;
	}
    }
  // child was not found
  assert (0);
}

/* setCritter - used to reset the critter to NULL after it has died
 * @param critter must be NULL
 */
void Member::setCritter (Critter* critter)
{
  assert (NULL == critter);
  M_critter = critter;
}

/* setDepth - sets the member's depth in the family tree
 * @param depth the member's depth, must be zero or positive
 */
void Member::setDepth (unsigned int depth)
{
  assert (0 <= depth);
  M_depth = depth;
}

/* setParent - sets the member's parent member
 * @param parent the parent member, may be NULL
 */
void Member::setParent (Member* parent)
{
  M_parent = parent;
}
