/* view.cpp - View class draws the simulation
 * 
 * Copyright (C) 2003-2007 Michael Leonhard
 * http://tamale.net/bluedogs
 */

#include <iostream>
#include <SDL.h>

#include "bluedogs.h"

/* drawCritter - draws a critter at the specified cell
 * @param surface the surface to draw on
 * @param x the x-coordiante in the field
 * @param y the y-coordinate in the field
 * @param energy the energy of the critter
 * @param dir the direction of the critter
 */
void View::drawCritter (SDL_Surface* surface, Critter* critter)
{
  assert (surface);
  assert (critter);
  
  int x = critter->getX ();
  int y = critter->getY ();
  int dir = critter->getDirection ();
  int energy = critter->getEnergy ();
  
  Molecule* m = critter->getMolecule ();
  assert (m);
  Uint32 color = SDL_MapRGB (surface->format, m->getR(), m->getG(), m->getB());
  
  SDL_Rect rect;
  int hMargin = M_cellWidth / 4;
  int vMargin = M_cellHeight / 4;
  
  // critter is drawn centered in the cell
  int left = M_rect.x + (M_cellWidth * x);
  int top = M_rect.y + (M_cellHeight * y);
  int right = left + M_cellWidth;
  int bottom = top + M_cellHeight;
  rect.x = left + hMargin;
  rect.y = top + vMargin;
  rect.w = M_cellWidth - 2*hMargin;
  rect.h = M_cellHeight - 2*vMargin;
  
  // draw the body
  SDL_FillRect (surface, &rect, color);
  
  // cell is too small to draw head
  if (rect.w < 2 || rect.h < 2)
    {
      return;
    }
  // cell is narrow, remove margin
  if (rect.w == 3)
    {
      hMargin = 0;
    }
  // cell is shallow, remove margin
  if (rect.h == 3)
    {
      vMargin = 0;
    }
  int hEdge = hMargin / 3;
  int vEdge = vMargin / 3;
  
  // construct the "head" pointing in right direction
  switch (dir)
    {
    case NORTH:
      rect.x += hEdge;
      rect.w -= hEdge * 2;
      rect.y += vEdge;
      rect.h = (vEdge)?vEdge:1;
      break;
    case SOUTH:
      rect.x += hEdge;
      rect.w -= hEdge * 2;
      rect.y += rect.h;
      rect.h = (vEdge)?vEdge:1;
      rect.y -= rect.h;
      rect.y -= vEdge;
      break;
    case EAST:
      rect.y += vEdge;
      rect.h -= vEdge * 2;
      rect.x += rect.w;
      rect.w = (hEdge)?hEdge:1;
      rect.x -= rect.w;
      rect.x -= hEdge;
      break;
    case WEST:
      rect.y += vEdge;
      rect.h -= vEdge * 2;
      rect.x += hEdge;
      rect.w = (hEdge)?hEdge:1;
      break;
    }
  // draw the head
  SDL_FillRect (surface, &rect, M_headColor[energy]);
}

/* draw - draws the simulation
 * @param surface the surface to draw on
 * @returns the region that was updated
 */
SDL_Rect const* View::draw (SDL_Surface* surface)
{
  int fieldWidth = M_field.getWidth ();
  int fieldHeight = M_field.getHeight ();
  assert (fieldWidth > 0);
  assert (fieldHeight > 0);
  assert (surface);
  
  // is not visible
  if (!M_visible)
    {
      return NULL;
    }
  
  // window is too small to display every cell, draw a blue background
  if (M_tooSmall)
    {
      Uint32 blueColor = SDL_MapRGB (surface->format, 0, 0, 0xFF);
      SDL_FillRect (surface, &M_rect, blueColor);
      return &M_rect;
    }
  
  // needs optimization
  if (M_needsOptimize)
    {
      optimize (surface);
    }
  
  // draw the field
  SDL_Rect cell;
  cell.w = (Uint16) M_cellWidth;
  cell.h = (Uint16) M_cellHeight;
  cell.y = M_rect.y;
  for (int y = 0; y < fieldHeight; y++)
    {
      cell.x = M_rect.x;
      for (int x = 0; x < fieldWidth; x++)
	{
	  Uint8 greenness = M_field.getFood (x, y);
	  SDL_FillRect (surface, &cell, M_greenColor[greenness]);
	  cell.x += cell.w;
	}
      // move down one row
      cell.y += cell.h;
    }
  
  // draw the critters
  for (int y = 0; y < fieldHeight; y++)
    {
      for (int x = 0; x < fieldWidth; x++)
	{
	  Critter* critter = M_field.getCritter (x, y);
	  if (critter)
	    {
	      drawCritter (surface, critter);
	    }
	}
    }
  
  // return update region
  return &M_rect;
}

/* optimize - recalculates display dimensions and positions
 * @param surface the display surface where we will draw
 */
void View::optimize (SDL_Surface* surface)
{
  assert (surface);
  int fieldWidth = M_field.getWidth ();
  int fieldHeight = M_field.getHeight ();
  assert (fieldWidth);
  assert (fieldHeight);
  
  // window is too small to display each fieldulation cell
  if (fieldWidth >= surface->w || fieldHeight >= surface->h)
    {
      // fill screen
      move (0, 0);
      resize (surface->w, surface->h);
      M_needsOptimize = false;
      M_tooSmall = true;
      return;
    }
  else
    {
      M_tooSmall = false;
    }
  
  M_cellWidth = surface->w / fieldWidth;
  M_cellHeight = surface->h / fieldHeight;
  
  int viewWidth = M_cellWidth * fieldWidth;
  int viewHeight = M_cellHeight * fieldHeight;
  int viewX = (surface->w - viewWidth) / 2;
  int viewY = (surface->h - viewHeight) / 2;
  move (viewX, viewY);
  resize (viewWidth, viewHeight);
  
  // recalculate shades of green
  for (int i = 0; i < 256; i++)
    {
      Uint8 r = (Uint8) (i >> 3);
      Uint8 g = (Uint8) i >> 1;
      Uint8 b = (Uint8) (i >> 3);
      M_greenColor[i] = SDL_MapRGB (surface->format, r, g, b);
    }
  
  // recalculate critter head colors
  for (int i = 0; i < 256; i++)
    {
      int brightness = i;
      if (brightness < 64)
	{
	  brightness = 64 + (3 * brightness);
	}
      else if (brightness < 128)
	{
	  brightness = 447 - (3 * brightness);
	}
      else
	{
	  brightness = 107 - (brightness / 3);
	}
      Uint8 brt = (Uint8) brightness;
      M_headColor[i] = SDL_MapRGB (surface->format, brt, brt, brt);
    }
  
  M_needsOptimize = false;
}

/* Constructor
 * @param field the simulation field that is drawn by this view
 */
View::View (Field& field)
  : M_field (field),
    M_cellWidth (-1),
    M_cellHeight (-1),
    M_tooSmall (true),
    Displayable ()
{
  M_visible = true;
  M_needsOptimize = true;
}
