/* bluedogs.cpp
 * 
 * Copyright (C) 2003-2007 Michael Leonhard
 * http://tamale.net/bluedogs
 */

#include "bluedogs.h"
#include "SDL_gfxPrimitives.h"

#define USAGE "bluedogs - Copyright (C) 2003-2007 Mike Leonhard http://tamale.net\n"

/* DrawColorSim - shows the colorsim
 */
class DrawColorSim : public Displayable
{
private:
  ColorSim& M_col;
  int M_radius;
  DrawColorSim (const DrawColorSim& rhs);
  DrawColorSim& operator= (const DrawColorSim& rhs);
public:
  DrawColorSim (ColorSim& col, int left, int top, int width, int height)
    : M_col (col)
  {
    assert (0 < width);
    assert (0 < height);
    move (left, top);
    resize (width, height);
    M_radius = ((width < height) ? width : height) / 2;
  }
  
  /* draw - draws background and molecules
   * @param screen the display surface on which to draw
   * @return the region updated
   */
  SDL_Rect const* draw (SDL_Surface *screen)
  {
    // background
    int x = M_rect.x + M_radius;
    int y = M_rect.y + M_radius;
    filledCircleRGBA(screen, x, y, M_radius, 32, 32, 32, 255);
    
    // molecules
    Uint32 color;
    float diameter = M_radius * 2;
    SDL_Rect drawRect = {0, 0, 1, 1};
    const map<Critter*,Molecule*>& molecules = M_col.getMolecules ();
    map<Critter*,Molecule*>::const_iterator i = molecules.begin();
    for (; i != molecules.end(); i++)
      {
	Molecule* m = i->second;
	assert (m);
	drawRect.x = M_rect.x + (Sint16)(diameter*(m->getX ()));
	drawRect.y = M_rect.y + (Sint16)(diameter*(m->getY ()));
	color = SDL_MapRGB (screen->format, m->getR(), m->getG(), m->getB());
	SDL_FillRect (screen, &drawRect, color);
      }
    return &M_rect;
  }
};

/* DrawCheck - shows checkbox option to draw in realtime or not
*/
class DrawCheck : public Check
{
public:
  /* event - process an event
   * @param event the event
   * @param display the Display object where the widget is shown
   */
  void event (SDL_Event& event, Display& display)
  {
    cout << "event!" << endl;
    switch (event.type)
      {
      case SDL_MOUSEBUTTONDOWN:
	cout << "BUTTONDOWN ";
	toggle();
	break;
      }
  };

  /* inRegion - tests if the specified coordinates lie in the widget's area
   * @param x the x-coordinate
   * @param y the y-coordinate
   * @return true if the coordinates lie in the widget's area, otherwise false
   */
  bool inRegion (int x, int y)
  {
    return (x >= M_rect.x) && (x < M_rect.x + M_rect.w)
      && (y >= M_rect.y) && (y < M_rect.y + M_rect.h);
  };

  /* Constructor
   * @param left x-coordinate of the widget's left edge
   * @param top y-coordinate of the widget's top edge
   */
  DrawCheck (int left, int top)
    : Check (left, top, true, "draw every day")
  {
  };
};

/* RateCount - shows the number of simulation iterations per second.
*/
class RateCount : public Number
{
private:
  Uint32 M_cyclesThisSecond;
  Uint32 M_nextUpdateTime;
  bool M_needDraw;
public:

  /* countDay - counts a simulation day, updates number
   */
  void countDay ()
  {
    Uint32 now = SDL_GetTicks();
    // time to update count
    if (now >= M_nextUpdateTime)
      {
	setNumber(M_cyclesThisSecond);
	render();
	M_needDraw = true;
	M_cyclesThisSecond = 0;
	M_nextUpdateTime = now + 1000;
      }
    M_cyclesThisSecond++;
  };
  
  /* isTimeToDraw - checks if it's time to update the screen
   * @return true if the screen should be updated now, otherwise false
   */
  bool isTimeToDraw ()
  {
    bool needDraw = M_needDraw;
    M_needDraw = false;
    return needDraw;
  }
  
  /* Constructor
   * @param left x-coordinate of the widget's left edge
   * @param top y-coordinate of the widget's top edge
   */
  RateCount (int left, int top)
    : Number (left, top, 0, "days/second:")
  {
    M_cyclesThisSecond = 0;
    M_nextUpdateTime = 0;
    M_needDraw = true;
  };
};

class DayCount : public Number
{
private:
  Sim& M_sim;
public:
  /* draw - draws the widget, displaying the current simulation date
   * @param surface the surface to draw on
   * @returns the screen region that was updated
   */
  SDL_Rect const* draw (SDL_Surface* surface)
  {
    setNumber (M_sim.getDate());
    return Number::draw (surface);
  };
  
  /* Constructor
   * @param sim the sim whose population is to be displayed
   * @param left x-coordinate of the widget's left edge
   * @param top y-coordinate of the widget's top edge
   */
  DayCount (Sim& sim, int left, int top) 
    : Number (left, top, 0, "day:"), M_sim (sim)
  {
    setNumber (M_sim.getDate());
  };
};

class PopulationCount : public Number
{
private:
  Sim& M_sim;
public:
  /* draw - draws the widget, displaying the number of critters in the sim
   * @param surface the surface to draw on
   * @returns the screen region that was updated
   */
  SDL_Rect const* draw (SDL_Surface* surface)
  {
    setNumber(M_sim.getNumCritters());
    return Number::draw (surface);
  };
  
  /* Constructor
   * @param sim the sim whose population is to be displayed
   * @param left x-coordinate of the widget's left edge
   * @param top y-coordinate of the widget's top edge
   */
  PopulationCount (Sim& sim, int left, int top) 
    : Number (left, top, 0, "population:"), M_sim (sim)
  {
    setNumber (M_sim.getNumCritters());
  };
};

int main (int argc, char *argv[])
{
  // check command line
  if (argc != 1)
    {
      cerr << USAGE << endl;
      return 1;
    }
  
  Config config;
  config.field_width = 100;
  config.field_height = 75;
  config.initial_food = config.field_width * config.field_height * 32;
  config.growth_rate = 50;
  config.sprout_rate = 4;
  config.minimum_critters = 50;
  config.genotype_length = 256;
  config.initial_energy = 64;
  config.max_energy = 255; // must be < 256
  config.think_cycles = 32;
  config.food_potency = 4;
  config.min_split_energy = 96;
  config.split_energy_loss = 32;
  config.num_mutations = 4;
  
  // initialize
  try {
    srand ((unsigned int)time (NULL));
    //srand ((unsigned int)1);
    
    Display display (600, 400, "bluedogs");
    Sim sim (&config);
    View view (sim.field);
    display.addWidget (&view);
    DayCount day (sim, 20, 20);
    display.addWidget (&day);
    PopulationCount pop (sim, 20, 45);
    display.addWidget (&pop);
    RateCount rate (20, 70);
    display.addWidget (&rate);
    DrawCheck check (20, 95);
    display.addWidget (&check);
    DrawColorSim colview (sim.col, 20, 120, 150, 150);
    display.addWidget (&colview);
    
    // run the simulation
    SDL_Event event;
    while (1)
      {
	// dispatch all messages on event queue
	while (SDL_PollEvent (&event))
	  {
	    if (SDL_KEYDOWN == event.type & SDLK_ESCAPE == event.key.keysym.sym)
	      {
		throw new DisplayQuit ();
	      }
	    else
	      {
		display.dispatch (event);
	      }
	  }
	
	// keep the population above minimum
	for (int c = sim.getNumCritters (); c < config.minimum_critters; c++)
	  {
	    sim.add (new Bacteria (&config));
	    // these objects will be deleted by Sim when the bacteria die
	  }
	
	// update the simulation
	sim.update ();
	rate.countDay ();
	if (rate.isTimeToDraw () || check.getIsChecked() )
	  {
	    display.draw ();
	  }
      }
  }
  
  // normal exit
  catch (DisplayQuit)
    {
      return 0;
    }
  // graphics system had an error
  catch (GraphicsError e)
    {
      e.printStdErr();
      return 1;
    }
  
  // program should never reach here
  assert (0);
  return 1;
}
