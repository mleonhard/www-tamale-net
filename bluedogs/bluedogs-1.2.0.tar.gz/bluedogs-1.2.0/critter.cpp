/* critter.cpp
 * 
 * Copyright (C) 2003-2007 Michael Leonhard
 * http://tamale.net/bluedogs
 */

#include "bluedogs.h"

// vm registers
#define REG_RESULT    0
#define REG_A         1
#define REG_B         2
#define REG_C         3
#define REG_DIRECTION 4
#define REG_ENERGY    5
#define REG_RESERVED  6
#define REG_NW        7
#define REG_N         8
#define REG_NE        9
#define REG_W        10
#define REG_SELF     11
#define REG_E        12
#define REG_SW       13
#define REG_S        14
#define REG_SE       15

// vm instructions
#define I_SET        0
#define I_COPYA      1
#define I_COPYB      2
#define I_COPYC      3
#define I_ADD        4
#define I_SUBTRACT   5
#define I_MUL        6
#define I_DIV        7
#define I_INC        8
#define I_EQUAL      9
#define I_GREATER   10
#define I_LESS      11
#define I_JUMP      12
#define I_REPRODUCE 13
#define I_MOVE      14
#define I_EAT       15

// exceptions for program flow control
class IgnoreInstruction {};
class ActionPerformed {};

/* Constructor - creates a new critter
 * @param x the x-coordinate
 * @param y the y-coordinate
 * @param dir the direction it is facing
 * @param energy its initial energy
 * @param genotype its genes
 * @param config the simulation parameters
 */
Critter::Critter (int x, int y, int dir, int energy, vector<Uint8> genotype, const Config* config)
  : M_sim (NULL),
    M_x (x),
    M_y (y),
    M_dir (dir),
    M_energy (energy),
    M_ip (0),
    M_result (0),
    M_A (0), M_B (0), M_C (0),
    M_genotype (genotype),
    M_config (config),
    M_member (NULL),
    M_molecule (NULL)
{
  assert (-1 <= M_x);
  assert (-1 <= M_y);
  assert (EAST == M_dir || NORTH == M_dir || WEST == M_dir || SOUTH == M_dir);
  assert (0 <= M_energy);
  assert (genotype.size());
  assert (M_config);
  assert (M_config->max_energy);
  assert (255 >= M_config->max_energy);
  assert (M_config->think_cycles);
}

/* Constructor - creates a random critter with no location
 * @param config the simulation parameters
 */
Critter::Critter (const Config* config)
  : M_sim (NULL),
    M_x (-1),
    M_y (-1),
    M_ip (0),
    M_result (0),
    M_A (0), M_B (0), M_C (0),
    M_config (config),
    M_member (NULL),
    M_molecule (NULL)
{
  assert (M_config);
  M_energy = M_config->initial_energy;
  assert (0 <= M_energy);
  M_dir = RANDINT (4);
  assert (EAST == M_dir || NORTH == M_dir || WEST == M_dir || SOUTH == M_dir);
  
  // initialize genotype with random instructions
  assert (M_config->genotype_length);
  for (int i = 0; i < M_config->genotype_length; i++)
    {
      M_genotype.push_back((Uint8) RANDINT (256));
    }
}

/* Destructor
 */
Critter::~Critter()
{
  //cout << "~Critter" << endl;
  //printState();
  //printGenotype();
}

/* getAppearance - returns the way the critter appears to other critters
 * @return the critter's appearance
 */
unsigned char Critter::getAppearance () const
{
  return 64;
}

/* accessor
 * @return the critter's current direction
 */
int Critter::getDirection () const
{
  assert (EAST == M_dir || NORTH == M_dir || WEST == M_dir || SOUTH == M_dir);
  return M_dir;
}

/* accessor
 * @return the amount of energy in the critter
 */
int Critter::getEnergy () const
{
  assert (0 <= M_energy);
  assert (M_config);
  assert (M_config->max_energy >= M_energy);
  return M_energy;
}

/* accessor
 * @return the geneology member object of the critter, may be NULL
 */
Member* Critter::getMember () const
{
  return M_member;
}

/* accessor
 * @return the geneology molecule object of the critter, may be NULL
 */
Molecule* Critter::getMolecule () const
{
  return M_molecule;
}

/* getReg - get the value of a VM register
 * @param reg the register to read
 * @return the value of the specified register
 * @throws IgnoreInstruction when an invalid register is specified
 */
unsigned char Critter::getReg (int reg) const
{
  switch (reg)
    {
    case REG_RESULT:
      return M_result;
    case REG_A:
      return M_A;
    case REG_B:
      return M_B;
    case REG_C:
      return M_C;
    case REG_DIRECTION:
      return (Uint8) M_dir;
    case REG_ENERGY:
      return (Uint8) M_energy;
    case REG_RESERVED:
      throw IgnoreInstruction();
    case REG_NW:
      return (Uint8) M_sim->field.look (M_x - 1, M_y - 1);
    case REG_N:
      return (Uint8) M_sim->field.look (M_x, M_y - 1);
    case REG_NE:
      return (Uint8) M_sim->field.look (M_x + 1, M_y - 1);
    case REG_W:
      return (Uint8) M_sim->field.look (M_x - 1, M_y);
    case REG_SELF:
      return (Uint8) M_sim->field.look (M_x, M_y);
    case REG_E:
      return (Uint8) M_sim->field.look (M_x + 1, M_y);
    case REG_SW:
      return (Uint8) M_sim->field.look (M_x - 1, M_y + 1);
    case REG_S:
      return (Uint8) M_sim->field.look (M_x, M_y + 1);
    case REG_SE:
      return (Uint8) M_sim->field.look (M_x + 1, M_y + 1);
    default:
      // program should never reach this point
      assert (0);
    }
  return 0;
}

/* accessor
 * @return the critter's x-coordinate in the simulation sim, or -1
 */
int Critter::getX () const
{
  return M_x;
}

/* accessor
 * @return the critter's y-coordinate in the simulation sim, or -1
 */
int Critter::getY () const
{
  return M_y;
}

/* printGenotype - prints out the critter's id, age, and genotype to stdout
 /
void Critter::printGenotype()
{
  assert (M_id);
  
  cout << "CRITTER[" << M_id << "](" << getAge() << "):";
  for (int i = 0; i < M_genotype.size(); i++)
    {
      cout << hex << setfill('0') << setw(2) << (int)M_genotype[i];
    }
  cout << dec << endl;
}

/* printStates - prints out the critter's ID and position to stdout
 /
void Critter::printState()
{
  cout << "CRITTER[" << M_id << "]:" << M_x << "," << M_y << endl;
}

/* reproduce - reproduce the critter. NOT IMPLEMENTED IN BASE CLASS.
 */
void Critter::reproduce ()
{
};

/* setId - sets the critter's ID number, can be called only once
 * @param id the critter's id number
 /
void Critter::setId (int id)
{
  assert (M_id == -1);// allow id to be set only once
  M_id = id;
}

/* setMember - sets the critter's geneology member object
 * @param member the member object, may be NULL
 */
void Critter::setMember (Member* member)
{
  M_member = member;
}

/* setMolecule - sets the critter's geneology molecule object
 * @param molecule the molecule object, may be NULL
 */
void Critter::setMolecule (Molecule* molecule)
{
  M_molecule = molecule;
}

/* setPosition - sets the critter's position in the sim
 * @param x the critter's new x-coordinate
 * @param y the critter's new y-coordinate
 */
void Critter::setPosition (int x, int y)
{
  assert (0 <= x);
  assert (0 <= y);
  M_x = x;
  M_y = y;
}

/* setReg - sets the value in a VM register
 * @param reg the register to set
 * @param val the value to assign to the register
 * @throws IgnoreInstruction when an invalid register is specified
 */
void Critter::setReg (int reg, Uint8 val)
{
  switch (reg)
    {
    case REG_RESULT:
      M_result = val;
    case REG_A:
      M_A = val; return;
    case REG_B:
      M_B = val; return;
    case REG_C:
      M_C = val; return;
    case REG_DIRECTION:
      M_dir = val & 0x03;
      return;
    case REG_RESERVED:
      throw IgnoreInstruction();
    default:
      throw IgnoreInstruction();
    }
}

/* setSim - informs the critter that it is being added to the simulation
 * @param sim the simulation
 */
void Critter::setSim (Sim* sim)
{
  assert (sim);
  M_sim = sim;
}

/* think - performs one thought or action
 * @throws ActionPeformed when a turn-ending action was performed
 */
void Critter::think ()
{
  // instruction code
  assert (M_ip < M_genotype.size ());
  int opcode = M_genotype[M_ip];
  M_ip = (M_ip + 1) % M_genotype.size ();
  
  // register is upper 4 bits of opcode
  int reg = (opcode & 0xF0) >> 4;
  
  // instruction is lower 4 bits of opcode
  int i = opcode & 0x0F;
  
  // interpret the instruction
  try {
    Uint8 immediate;
    int x, y;
    switch (i)
      {
      case I_SET:
	immediate = M_genotype[M_ip];
	M_ip = (M_ip + 1) % M_genotype.size ();
	setReg (reg, immediate);
	break;
      case I_COPYA:
	M_A = getReg (reg);
	break;
      case I_COPYB:
	M_B = getReg (reg);
	break;
      case I_COPYC:
	M_C = getReg (reg);
	break;
      case I_ADD:
	M_result = M_result + getReg (reg);
	break;
      case I_SUBTRACT:
	M_result = M_result - getReg (reg);
	break;
      case I_MUL:
	M_result = M_result * getReg (reg);
	break;
      case I_DIV:
	// denominator
	x = getReg (reg);
	// div by zero
	if (x == 0)
	  {
	    M_result = 255;
	  }
	else
	  {
	    M_result = (Uint8) (M_result / x);
	  }
	break;
      case I_INC:
	M_result++;
	break;
      case I_EQUAL:
	M_result = (getReg (reg) == M_result);
	break;
      case I_GREATER:
	M_result = (getReg (reg) > M_result);
	break;
      case I_LESS:
	M_result = (getReg (reg) < M_result);
	break;
      case I_JUMP:
	M_ip = getReg (reg) % M_genotype.size();
	break;
      case I_REPRODUCE:
	// cout "I_REPRODUCE(" << M_id << ") "
	reproduce ();
	throw ActionPerformed();
      case I_MOVE:
	// current position
	x = M_x;
	y = M_y;
	
	// forward position
	switch (M_dir)
	  {
	  case EAST:
	    x++;
	    break;
	  case NORTH:
	    y--;
	    break;
	  case WEST:
	    x--;
	    break;
	  case SOUTH:
	    y++;
	    break;
	  }
	
	M_result = M_sim->field.moveCritter (this, x, y);
	if (M_result)
	  {
	    // successful move ends turn
	    throw ActionPerformed();
	  }
	// move unsuccessful
	break;
      case I_EAT:
	// don't try to eat if it would waste
	if ((int) M_energy + M_config->food_potency > M_config->max_energy)
	  {
	    M_result = 0;
	    throw ActionPerformed();
	  }
	
	// no food
	if (!M_sim->field.getFood (M_x, M_y))
	  {
	    M_result = 0;
	    throw ActionPerformed();
	  }
	
	// eat, end turn
	M_energy += M_config->food_potency;
	M_sim->field.foodEaten (M_x, M_y);
	M_result = 1;
	throw ActionPerformed();
      default:
	// program should never reach here
	assert (0);
      }
  }
  catch (IgnoreInstruction) {};
}

/* update - lets the critter think and move
 */
void Critter::update ()
{
  // sanity checks
  assert (M_sim);
  assert (M_sim->field.getCritter (M_x, M_y) == this);
  assert (EAST == M_dir || NORTH == M_dir || WEST == M_dir || SOUTH == M_dir);
  assert (0 <= M_energy);
  assert (M_config->max_energy >= M_energy);
  
  if (!M_energy) // dead
    {
      return;
    }
  
  try {
    for (int n = 0; n < M_config->think_cycles && M_energy; n++)
      {
	// execute genotype instruction
	think ();
      }
  }
  // turn-ending instruction was executed
  catch (ActionPerformed)
    {
    };
  // thinking takes energy
  M_energy --;
}
