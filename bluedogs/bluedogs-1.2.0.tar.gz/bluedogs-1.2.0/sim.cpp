/* sim.cpp - Sim class holds field and critters, performs simulation
 * 
 * Copyright (C) 2003-2007 Michael Leonhard
 * http://tamale.net/bluedogs
 */

#include <iostream>
#include "bluedogs.h"

/* add - adds a founder critter to the simulation
 * @param critter the critter object to add
 */
void Sim::add (Critter* critter)
{
  assert (critter);
  critter->setSim (this);
  M_critters.push_front (critter);
  field.add (critter);
  col.add (critter);
  pop.add (critter);
  M_numCritters++;
}

/* add - adds a descendent critter to the simulation
 * @param critter the critter object to add
 * @param parent the critter's parent object
 */
void Sim::add (Critter* critter, Critter* parent)
{
  assert (critter);
  assert (parent);
  critter->setSim (this);
  M_critters.push_front (critter);
  field.add (critter);
  col.add (critter, parent);
  pop.add (critter, parent);
  M_numCritters++;
}

/* accessor
 * @return the current date of the simulation
 */
int Sim::getDate () const
{
  return M_date;
}

/* accessor
 * @return the number of critters in the simulation
 */
int Sim::getNumCritters () const
{
  return M_numCritters;
}

/* Constructor
 * @param config configuration options
 */
Sim::Sim (const Config* config)
  : M_date (1),
    M_numCritters (0),
    col (config),
    pop (config),
    field (config)
{
}

/* Destructor
 */
Sim::~Sim()
{
}

/* update - updates the simulation, removed dead critters
 */
void Sim::update()
{
  M_date++;
  field.update();
  
  list<Critter*>::iterator i = M_critters.begin();
  while (i != M_critters.end())
    {
      Critter* critter = *i;
      assert (critter);
      // critter is alive, give it a turn to think and act
      if (critter->getEnergy())
	{
	  critter->update();
	  i++;
	}
      // remove dead critter
      else
	{
	  i = M_critters.erase(i);
	  field.remove (critter);
	  col.remove (critter);
	  pop.remove (critter);
	  delete critter;
	  M_numCritters--;
	}
    }
  pop.verify();
}
