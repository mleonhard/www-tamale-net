/* bluedogs.h
 * 
 * Copyright (C) 2003-2007 Michael Leonhard
 * http://tamale.net/bluedogs
 */

#ifndef BLUEDOGS_H

#include <cassert>
#include <iomanip>
#include <iostream>
#include <list>
#include <map>
#include <cmath>
#include <SDL.h>
#include <vector>
#include "graphics.h"

using namespace std;

// macros
#define RANDINT(n) ((int)((float)(n) * rand() / (RAND_MAX + 1.0)))

#define EAST 0
#define NORTH 1
#define WEST 2
#define SOUTH 3

// class declarations
class Bacteria;
struct Config;
class ColorSim;
class Critter;
class Field;
class Member;
class Molecule;
class Population;
class Sim;
class View;

class ColorSim
{
private:
  map<Critter*,Molecule*> M_molecules;
  const Config* M_config;
public:
  void add (Critter* critter);
  void add (Critter* critter, Critter* parent);
  ColorSim (const Config* config);
  const map<Critter*,Molecule*>& getMolecules () const;
  void remove (Critter* critter);
};

class Molecule
{
private:
  float M_x, M_y;
  //float M_h, M_s;
  float M_r, M_g, M_b;
  Critter* M_critter;
  const Config* M_config;
public:
  Molecule (const Config* config, Critter* critter);
  Critter* getCritter () const;
  Uint8 getR () const;
  Uint8 getG () const;
  Uint8 getB () const;
  float getX () const;
  float getY () const;
  void setPos (float x, float y);
};

struct Config
{
  int field_width;
  int field_height;
  int initial_food;
  int growth_rate;
  int sprout_rate;
  int minimum_critters;
  int genotype_length;
  int initial_energy;
  int max_energy;
  int think_cycles;
  int food_potency;
  int min_split_energy;
  int split_energy_loss;
  int num_mutations;
};

class Critter
{
private:
  Critter (const Critter& rhs); // copy constructor
  const Critter& operator= (const Critter& rhs); // copy assignment operator
  
protected:
  Critter (int x, int y, int dir, int energy, vector<Uint8> genotype, const Config* config);
  Critter (const Config* config);
  Sim* M_sim;
  int M_x, M_y, M_dir, M_energy;
  unsigned int M_ip;
  Uint8 M_result, M_A, M_B, M_C;
  vector<Uint8> M_genotype;
  const Config* M_config;
  Member* M_member;
  Molecule* M_molecule;
  Uint8 getReg (int reg) const;
  void setReg (int reg, Uint8 val);
public:
  Critter (int energy, const Config* config);
  ~Critter ();
  virtual Uint8 getAppearance () const;
  int getDirection () const;
  int getEnergy () const;
  Member* getMember () const;
  Molecule* getMolecule () const;
  int getX () const;
  int getY () const;
  virtual void reproduce ();
  void setMember (Member* member);
  void setMolecule (Molecule* molecule);
  void setPosition (int x, int y);
  void setSim (Sim* sim);
  void think ();
  void update ();
  //void printGenotype () const;
  //void printState () const;
};

class Field
{
private:
  int M_width, M_height;
  int M_sproutCounter;
  Uint8* M_food;
  Critter** M_critter;
  const Config* M_config;
  Field (const Field& rhs); // disabled copy constructor
  const Field& operator= (const Field& rhs);//disabled copy assignment operator
public:
  void add (Critter* critter);
  void addFood (int amount);
  Field (const Config* config);
  ~Field ();
  void foodEaten (int x, int y);
  Critter* getCritter (int x, int y) const;
  Uint8 getFood (int x, int y) const;
  int getHeight () const;
  int getWidth () const;
  void growFood ();
  int look (int x, int y) const;
  bool moveCritter (Critter* critter, int newX, int newY);
  int randX () const;
  int randY () const;
  void remove (Critter* criter);
  void update ();
  void verify () const;
  //void printGenotypes ();
};

class Member
{
private:
  Critter* M_critter;
  Member* M_parent;
  list<Member*> M_child;
  Uint32 M_depth;
public:
  void addChild (Member* child);
  Member (Critter* critter);
  int getChildCount () const;
  const list<Member*> getChildren () const;
  Critter* getCritter () const;
  Uint32 getDepth () const;
  Member* getParent () const;
  void removeChild (Member* child);
  void setCritter (Critter* critter);
  void setDepth (unsigned int depth);
  void setParent (Member* parent);
};

class Population
{
private:
  list<Member*> M_founder;
public:
  void add (Critter* critter);
  void add (Critter* critter, Critter* parent);
  void contract (Member* node);
  double getDistance (Critter* critA, Critter* critB);
  Population (const Config* config);
  Member* prune (Member* node);
  void remove (Critter* criter);
  void removeFounder (Member* member);
  void verify () const;
  void verifyBranch (Member* member) const;
};

class Sim
{
private:
  int M_date, M_numCritters;
  list<Critter*> M_critters;
  
  // disabled copy constructor
  Sim (const Sim& rhs);
  // disabled copy assignment operator
  const Sim& operator= (const Sim& rhs);

public:
  Field field;
  Population pop;
  ColorSim col;
  
  void add (Critter* critter);
  void add (Critter* critter, Critter* parent);
  int getDate () const;
  int getNumCritters () const;
  Sim (const Config* config);
  ~Sim ();
  void update ();
};

class Bacteria : public Critter
{
private:
  // disabled copy constructor
  Bacteria (const Bacteria& rhs);
  // disabled copy assignment operator
  const Bacteria& operator= (const Bacteria& rhs);
  
public:
  Bacteria (const Config* config);
  Bacteria (int x, int y, int dir, int energy, vector<Uint8> genotype, const Config* config);
  void reproduce ();
};

class View : public Displayable
{
private:
  Field& M_field;
  int M_cellWidth, M_cellHeight;
  Uint32 M_greenColor[256], M_headColor[256];
  bool M_tooSmall;
  
  View (const View& rhs);// disabled copy constructor
  const View& operator= (const View& rhs);// disabled copy assignment operator
  
  void drawCritter (SDL_Surface* surface, Critter* critter);
  
public:
  SDL_Rect const* draw (SDL_Surface* surface);
  void optimize (SDL_Surface* surface);
  View (Field& field);
};

#define BLUEDOGS_H
#endif
