/* bacteria.cpp
 * 
 * Copyright (C) 2003-2007 Michael Leonhard
 * http://tamale.net/bluedogs
*/

#include "bluedogs.h"

/* Constructor - creates a bacteria with random genes, random position
 * @param config the simulation parameters
 */
Bacteria::Bacteria (const Config* config)
  : Critter (config)
{
}

/* Constructor - creates a new bacteria with the specified genes, etc.
 * @param x the x-coordinate
 * @param y the y-coordinate
 * @param dir the direction it is facing
 * @param energy its initial energy
 * @param genotype its genes
 * @param config the simulation parameters
 */
Bacteria::Bacteria (int x, int y, int dir, int energy, vector<Uint8> genotype, const Config* config)
  : Critter(x, y, dir, energy, genotype, config)
{
}

/* reproduce - the animal tries to reproduce
 */
void Bacteria::reproduce ()  {
  // sanity checks
  //assert (M_sim.in (M_x, M_y) );
  assert (M_config);
  assert (M_genotype.size());
  assert (M_ip < M_genotype.size());
  
  // not enough energy
  if (M_energy < M_config->min_split_energy)
    {
      M_result = 0;
      return;
    }
  
  // child will occupy mother's old position
  int child_x = M_x;
  int child_y = M_y;
  
  // mother moves forward
  int x = M_x;
  int y = M_y;
  switch (M_dir)
    {
    case EAST:
      x++;
      break;
    case NORTH:
      y--;
      break;
    case WEST:
      x--;
      break;
    case SOUTH:
      y++;
      break;
    default:
      assert (0);
    }
  if (!M_sim->field.moveCritter (this, x, y))
    {
      // mother cannot move forward
      M_result = 0;
      return;
    }
  
  // child points in opposite direction from mother
  int child_dir = M_dir ^ 2;
  
  // child gets a copy of mother's genes, with a few randomized
  vector<Uint8> child_genes = M_genotype;
  for (int r = 0; r < M_config->num_mutations; r++) 
    {
      int i = RANDINT (child_genes.size ());
      child_genes[i] = (Uint8) RANDINT (256);
    }
  
  // energy
  M_energy -= M_config->split_energy_loss;
  int child_energy = M_energy / 2;
  M_energy /= 2;
  
  Bacteria* child = new Bacteria (child_x, child_y, child_dir, child_energy, child_genes, M_config);
  M_sim->add (child, this); // child will be deleted by Sim when dead
  
  // success!
  M_result = 1;
}
