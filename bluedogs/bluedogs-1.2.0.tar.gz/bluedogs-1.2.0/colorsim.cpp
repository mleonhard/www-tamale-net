/* colorsim.cpp
 * 
 * Copyright (C) 2003-2007 Michael Leonhard
 * http://tamale.net/bluedogs
*/

#include "bluedogs.h"

#define PI 6.28318530718
#define RANDFLOAT() (((float)rand()) / (RAND_MAX+1.0))
#define INCIRCLE(x,y) (pow(x - 0.5, 2) + pow(y - 0.5, 2) <= 0.25)
#define INSQUARE(x,y) ((0 <= x) && (1.0 >= x) && (0 <= y) && (1.0 >= y))

/* add - adds the critter to the simulation
 * @param critter the critter object to add
 */
void ColorSim::add (Critter* critter)
{
  assert (M_config);
  assert (critter);
  Molecule* molecule = new Molecule (M_config, critter);
  critter->setMolecule (molecule);
  M_molecules[critter] = molecule;
  /* choose a random position */
  float x, y;
  do
    {
      x = RANDFLOAT();
      y = RANDFLOAT();
    } while (!INCIRCLE(x,y));
  
  molecule->setPos (x, y);
}

/* add - adds the critter to the simulation
 * @param critter the critter object to add
 * @param parent the parent's critter
 */
void ColorSim::add (Critter* critter, Critter* parent)
{
  assert (M_config);
  assert (critter);
  assert (parent);
  Molecule* molecule = new Molecule (M_config, critter);
  critter->setMolecule (molecule);
  M_molecules[critter] = molecule;
  Molecule* parentMolecule = parent->getMolecule ();
  assert (parentMolecule);
  /* choose a random position next to parent */
  float px = parentMolecule->getX ();
  float py = parentMolecule->getY ();
  float x, y;
  do
    {
      float dir = PI * RANDFLOAT();
      x = px + 0.03 * cos (dir);
      y = py + 0.03 * sin (dir);
    } while (!INCIRCLE(x,y));
  molecule->setPos (x, y);
}

/* Constructor - creates empty color simulation
 * @param config the simulation parameters
 */
ColorSim::ColorSim (const Config* config)
  : M_config (config)
{
  assert (config);
}

/* Accessor
 * @return a reference to the map of critters
 */
const map<Critter*,Molecule*>& ColorSim::getMolecules () const
{
  return M_molecules;
}

/* remove - removes a dead critter from the simulation
 * @param critter the critter that has died and must be removed
 */
void ColorSim::remove (Critter* critter)
{
  assert (critter);
  Molecule* molecule = critter->getMolecule ();
  assert (molecule);
  assert (molecule->getCritter () == critter);
  critter->setMolecule (NULL);
  M_molecules.erase(critter);
  delete molecule;
}

/*********************************************************************
 * Molecule
 *********************************************************************/

/* Constructor
 * @param critter the critter represented by this molecule
 */
Molecule::Molecule (const Config* config, Critter* critter)
  : M_x (0.0),
    M_y (0.0),
    M_critter (critter),
    M_config (config)
{
  assert (critter);
  assert (config);
}

#define CLRCOMP(c,v) (63 + (Uint8)(c * v * 0.75))

/* Accessor
 * @return the red component of the molecule's color
 */
Uint8 Molecule::getR () const
{
  float energy = (float)M_critter->getEnergy ();
  return CLRCOMP(M_r, energy);
  //return 127 + (Uint8)(M_r * 128 * energy / ((float)M_config->max_energy));
}

/* Accessor
 * @return the green component of the molecule's color
 */
Uint8 Molecule::getG () const
{
  float energy = (float)M_critter->getEnergy ();
  return CLRCOMP(M_g, energy);
}

/* Accessor
 * @return the blue component of the molecule's color
 */
Uint8 Molecule::getB () const
{
  float energy = (float)M_critter->getEnergy ();
  return CLRCOMP(M_b, energy);
}

/* Accessor
 * @return the x-coordinate
 */
float Molecule::getX () const
{
  return M_x;
}

/* Accessor
 * @return the y-coordinate
 */
float Molecule::getY () const
{
  return M_y;
}

/* Accessor
 * @return the critter represented by this molecule
 */
Critter* Molecule::getCritter () const
{
  return M_critter;
}

/* setPos - sets the molecule's position in the sim
 * @param x the x-coordinate
 * @param y the y-coordinate
 */
void Molecule::setPos (float x, float y)
{
  assert (0.0 <= x);
  assert (1.0 >= x);
  assert (0.0 <= y);
  assert (1.0 >= y);
  M_x = x;
  M_y = y;
  // translate from cartesian (x,y) to polar (H,S)
  float S = 2*sqrt (pow (x - 0.5, 2) + pow (y - 0.5, 2));
  float H = (atan2 (x - 0.5, y - 0.5) * 360.0 / PI) + 180.0;
  // treat (H,S) polar as HSV color values, convert to RGB with V=1.0
  // See http://en.wikipedia.org/wiki/HSV_color_space
  float Hi = fmod(floor(H / 60), 6);
  float f = H/60 - Hi;
  float p = 1.0 - S;
  float q = 1.0 - f*S;
  float t = 1 - (1-f)*S;
  float R, G, B;
  switch ((int)Hi)
    {
    case 0: M_r = 1.0; M_g = t; M_b = p; break;
    case 1: M_r = q; M_g = 1.0; M_b = p; break;
    case 2: M_r = p; M_g = 1.0; M_b = t; break;
    case 3: M_r = p; M_g = q; M_b = 1.0; break;
    case 4: M_r = t; M_g = p; M_b = 1.0; break;
    case 5: M_r = 1.0; M_g = p; M_b = q; break;
    default: assert (0);
    }
}
