<?php
/*
Plugin Name: Random Password Generator
Plugin URI: http://tamale.net/wp-pwdgen/
Description: This plugin replaces user-chosen passwords with randomly generated passwords.
Version: 0.1
Author: Michael Leonhard
Author URI: http://tamale.net/
*/

/* TODO: add license
*/

class pwdgen
{
  // This function returns false to indicate that the password fields should be hidden
  function filter_show_password_fields ($current_val)
  {
    return false;
  }

  function action_check_passwords ($user_login, $pass1, $pass2)
  {
    global $pwdgen_newpass;
    
    # check that password fields were removed from form (or left empty)
    if ($pass1 != '' || $pass2 != '')
      {
	die(__('ERROR: The pwdgen plugin found a non-empty password field.'));
      }
    
    if (isset($_POST['request_new_pwd_checkbox_present']))
      $checkbox_present = True;
    
    if (isset($_POST['request_new_pwd']))
      $checkbox_checked = True;
    
    # checkbox not present on form -> this is new user page -> new pwd
    # checkbox present and unchecked -> this is update -> no change
    # checkbox present and checked -> this is update -> new pwd
    
    if (!$checkbox_present or ($checkbox_present and $checkbox_checked))
      $newpass = 'pwdgen8';
    else $newpass = '';
    
    $pass1 = $pass2 = $pwdgen_newpass = $newpass;
  }

  function action_show_user_profile ()
  {
    # CSS to fix the width of the checkbox, 
    # overrides #your-profile fieldset input {width: 100%;}
    echo "<style type='text/css'>#request_new_pwd { width: auto !important; margin-right: 0.5em; } </style>";
    # add 'request new random password' checkbox to options page
    echo "<fieldset>";
    echo "<legend>", _e('Get New Random Password'), "</legend>";
    echo "<p class='desc'>", _e('Check the box below to get a new password.  The software will generate a random password and send it to your email address.  Remember to press the Update Profile button below.'), "</p>";
    echo "<p><label for='request_new_pwd'><input name='request_new_pwd' type='checkbox' id='request_new_pwd' value='true'/>", _e('Send my new password by email'), "</label></p>";
    echo "</fieldset>";
    echo "<input name='request_new_pwd_checkbox_present' type='hidden' value='true'/>";
  }

  function action_profile_update($user_id)
  {
    global $pwdgen_newpass;
    if ($pwdgen_newpass != '')
      {
	$user = new WP_User($user_id);
	
	$user_login = stripslashes($user->user_login);
	$user_email = stripslashes($user->user_email);
	
	#$message  = sprintf(__('User requested new password on your blog %s:'), get_settings('blogname')) . "\r\n\r\n";
	#$message .= sprintf(__('Username: %s'), $user_login) . "\r\n\r\n";
	#$message .= sprintf(__('E-mail: %s'), $user_email) . "\r\n";
	#@wp_mail(get_settings('admin_email'), sprintf(__('[%s] User got new password'), get_settings('blogname')), $message);
	
	$message  = sprintf(__('Username: %s'), $user_login) . "\r\n";
	$message .= sprintf(__('Password: %s'), $pwdgen_newpass) . "\r\n";
	$message .= get_settings('siteurl') . "/wp-login.php\r\n";
	
	wp_mail($user_email, sprintf(__('[%s] Your username and password'), get_settings('blogname')), $message);
      }
  }
}

# overrides wp-includes/pluggable-functions.php:wp_new_user_notification()
# this is a modified version of that function, taken from WP v2.0.4
# This version retrieves th password from global $pwdgen_newpass and includes it in the email.
function wp_new_user_notification($user_id, $plaintext_pass = '') {
  # begin modifications
  global $pwdgen_newpass;
  $plaintext_pass = $pwdgen_newpass;
  # end modifications
  
  $user = new WP_User($user_id);
  
  $user_login = stripslashes($user->user_login);
  $user_email = stripslashes($user->user_email);
  
  $message  = sprintf(__('New user registration on your blog %s:'), get_settings('blogname')) . "\r\n\r\n";
  $message .= sprintf(__('Username: %s'), $user_login) . "\r\n\r\n";
  $message .= sprintf(__('E-mail: %s'), $user_email) . "\r\n";
  
  @wp_mail(get_settings('admin_email'), sprintf(__('[%s] New User Registration'), get_settings('blogname')), $message);
  
  if ( empty($plaintext_pass) )
    return;
  
  $message  = sprintf(__('Username: %s'), $user_login) . "\r\n";
  $message .= sprintf(__('Password: %s'), $plaintext_pass) . "\r\n";
  $message .= get_settings('siteurl') . "/wp-login.php\r\n";
  
  wp_mail($user_email, sprintf(__('[%s] Your username and password'), get_settings('blogname')), $message);
}

// register the function so it's called to filter the show_password_fields variable
add_filter('show_password_fields', array('pwdgen', 'filter_show_password_fields'));

// register the action so it's called when the password form is processed
add_action('check_passwords', array('pwdgen', 'action_check_passwords'));

// register addition to user profile page
add_action('show_user_profile', array('pwdgen', 'action_show_user_profile'));

add_action('profile_update', array('pwdgen', 'action_profile_update'));
?>